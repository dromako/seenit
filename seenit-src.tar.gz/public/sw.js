/**
 * SeenIt Service Worker — v2 (network-first)
 *
 * Strategy:
 *  - HTML/navigation: ALWAYS network-first. Never serve stale app shells.
 *  - Hashed JS/CSS assets: cache-first (hash in filename = immutable).
 *  - TMDB images: cache-first (they never change).
 *  - API calls: network-only (data must be fresh).
 *  - Everything else: network-first with cache fallback.
 */

const CACHE_NAME = 'seenit-v2';

// Install — skip waiting to activate immediately
self.addEventListener('install', () => self.skipWaiting());

// Activate — claim clients + purge old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET
  if (request.method !== 'GET') return;

  // API calls — always network, no caching
  if (url.hostname.includes('api.trakt.tv') ||
      url.hostname.includes('api.themoviedb.org') ||
      url.hostname.includes('omdbapi.com')) {
    return; // let the browser handle it normally
  }

  // TMDB images — cache-first (immutable content)
  if (url.hostname.includes('image.tmdb.org')) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached;
        return fetch(request).then((res) => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(CACHE_NAME).then((c) => c.put(request, clone));
          }
          return res;
        }).catch(() => new Response('', { status: 408 }));
      })
    );
    return;
  }

  // Hashed assets (JS/CSS with content hash in filename) — cache-first
  if (url.pathname.match(/\/assets\/.*\.[a-f0-9]{8,}\.(js|css)$/)) {
    event.respondWith(
      caches.match(request).then((cached) => {
        if (cached) return cached;
        return fetch(request).then((res) => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(CACHE_NAME).then((c) => c.put(request, clone));
          }
          return res;
        });
      })
    );
    return;
  }

  // Everything else (HTML, manifest, icons) — network-first
  event.respondWith(
    fetch(request).then((res) => {
      if (res.ok) {
        const clone = res.clone();
        caches.open(CACHE_NAME).then((c) => c.put(request, clone));
      }
      return res;
    }).catch(() => caches.match(request))
  );
});
