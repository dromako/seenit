#!/usr/bin/env node
/**
 * SeenIt Ratings Sync Script
 *
 * Pulls ratings from Trakt (SeenIt's source of truth) and exports them
 * as CSV files compatible with IMDB and Letterboxd import formats.
 * Also pulls IMDB ratings CSV and imports new ratings into Trakt
 * (SeenIt ratings override — if a rating exists in Trakt, it wins).
 *
 * Usage:
 *   node scripts/ratings-sync.mjs --push    # Export Trakt → IMDB/Letterboxd CSVs
 *   node scripts/ratings-sync.mjs --pull    # Import IMDB CSV → Trakt (Trakt wins conflicts)
 *   node scripts/ratings-sync.mjs --check   # Check staleness (alert if >7 days)
 *   node scripts/ratings-sync.mjs --all     # Do everything
 *
 * Environment:
 *   TRAKT_ACCESS_TOKEN   — OAuth bearer token from the PWA
 *   TRAKT_CLIENT_ID      — Trakt API client ID
 *   IMDB_RATINGS_CSV     — Path to downloaded IMDB ratings CSV (for --pull)
 *   OUTPUT_DIR            — Where to write export CSVs (default: ./ratings-export/)
 */

import fs from 'fs';
import path from 'path';

const TRAKT_BASE = 'https://api.trakt.tv';
const CLIENT_ID = process.env.TRAKT_CLIENT_ID || '63f699ae904e235385e08c4027c6ddc11fd3787d739b88383741cdea05e78638';
const ACCESS_TOKEN = process.env.TRAKT_ACCESS_TOKEN || '';
const OUTPUT_DIR = process.env.OUTPUT_DIR || './ratings-export';
const IMDB_CSV = process.env.IMDB_RATINGS_CSV || '';
const SYNC_LOG = path.join(OUTPUT_DIR, '.last-sync');

function traktHeaders() {
  return {
    'trakt-api-version': '2',
    'trakt-api-key': CLIENT_ID,
    'Content-Type': 'application/json',
    ...(ACCESS_TOKEN ? { Authorization: `Bearer ${ACCESS_TOKEN}` } : {}),
  };
}

async function fetchTraktRatings() {
  const movieRes = await fetch(`${TRAKT_BASE}/sync/ratings/movies`, { headers: traktHeaders() });
  const showRes = await fetch(`${TRAKT_BASE}/sync/ratings/shows`, { headers: traktHeaders() });
  if (!movieRes.ok || !showRes.ok) throw new Error('Failed to fetch Trakt ratings');
  const movies = await movieRes.json();
  const shows = await showRes.json();
  return { movies, shows };
}

// ── PUSH: Export Trakt ratings to IMDB and Letterboxd CSV formats ──

function toIMDBCsv(movies, shows) {
  // IMDB CSV format: Const,Your Rating,Date Rated,Title,URL,Title Type,IMDb Rating,Runtime (mins),Year,Genres,Num Votes,Release Date,Directors
  const header = 'Const,Your Rating,Date Rated,Title,URL,Title Type,IMDb Rating,Runtime (mins),Year,Genres,Num Votes,Release Date,Directors';
  const rows = [];

  for (const item of movies) {
    const imdbId = item.movie?.ids?.imdb;
    if (!imdbId) continue;
    const title = (item.movie?.title || '').replace(/"/g, '""');
    const year = item.movie?.year || '';
    const rating = item.rating;
    const ratedAt = item.rated_at ? new Date(item.rated_at).toISOString().split('T')[0] : '';
    rows.push(`${imdbId},${rating},${ratedAt},"${title}",https://www.imdb.com/title/${imdbId}/,movie,,, ${year},,,,`);
  }

  for (const item of shows) {
    const imdbId = item.show?.ids?.imdb;
    if (!imdbId) continue;
    const title = (item.show?.title || '').replace(/"/g, '""');
    const year = item.show?.year || '';
    const rating = item.rating;
    const ratedAt = item.rated_at ? new Date(item.rated_at).toISOString().split('T')[0] : '';
    rows.push(`${imdbId},${rating},${ratedAt},"${title}",https://www.imdb.com/title/${imdbId}/,tvSeries,,,${year},,,,`);
  }

  return header + '\n' + rows.join('\n') + '\n';
}

function toLetterboxdCsv(movies) {
  // Letterboxd import format: imdbID,Title,Year,Rating10,WatchedDate
  const header = 'imdbID,Title,Year,Rating10,WatchedDate';
  const rows = [];

  for (const item of movies) {
    const imdbId = item.movie?.ids?.imdb;
    if (!imdbId) continue;
    const title = (item.movie?.title || '').replace(/"/g, '""');
    const year = item.movie?.year || '';
    const rating = item.rating;
    const ratedAt = item.rated_at ? new Date(item.rated_at).toISOString().split('T')[0] : '';
    rows.push(`${imdbId},"${title}",${year},${rating},${ratedAt}`);
  }

  return header + '\n' + rows.join('\n') + '\n';
}

async function pushRatings() {
  console.log('📤 Pulling ratings from Trakt...');
  const { movies, shows } = await fetchTraktRatings();
  console.log(`   Found ${movies.length} movie ratings, ${shows.length} show ratings`);

  fs.mkdirSync(OUTPUT_DIR, { recursive: true });

  const imdbCsv = toIMDBCsv(movies, shows);
  const imdbPath = path.join(OUTPUT_DIR, 'imdb_ratings_export.csv');
  fs.writeFileSync(imdbPath, imdbCsv);
  console.log(`   ✅ IMDB CSV written: ${imdbPath}`);

  const lbCsv = toLetterboxdCsv(movies);
  const lbPath = path.join(OUTPUT_DIR, 'letterboxd_ratings_export.csv');
  fs.writeFileSync(lbPath, lbCsv);
  console.log(`   ✅ Letterboxd CSV written: ${lbPath}`);

  // Update sync timestamp
  fs.writeFileSync(SYNC_LOG, JSON.stringify({ lastPush: new Date().toISOString() }));
  console.log('   📋 Sync timestamp updated');

  return { imdbPath, lbPath, movieCount: movies.length, showCount: shows.length };
}

// ── PULL: Import IMDB ratings CSV into Trakt (Trakt/SeenIt wins conflicts) ──

function parseIMDBCsv(csvContent) {
  const lines = csvContent.trim().split('\n');
  if (lines.length < 2) return [];

  // Parse header to find column indices
  const header = lines[0].split(',');
  const constIdx = header.indexOf('Const');
  const ratingIdx = header.indexOf('Your Rating');
  const titleIdx = header.indexOf('Title');
  const yearIdx = header.indexOf('Year');

  const ratings = [];
  for (let i = 1; i < lines.length; i++) {
    // Simple CSV parse (handles quoted fields)
    const parts = [];
    let current = '';
    let inQuotes = false;
    for (const ch of lines[i]) {
      if (ch === '"') { inQuotes = !inQuotes; continue; }
      if (ch === ',' && !inQuotes) { parts.push(current); current = ''; continue; }
      current += ch;
    }
    parts.push(current);

    const imdbId = parts[constIdx]?.trim();
    const rating = parseInt(parts[ratingIdx]?.trim());
    const title = parts[titleIdx]?.trim();
    const year = parseInt(parts[yearIdx]?.trim());

    if (imdbId && !isNaN(rating) && rating >= 1 && rating <= 10) {
      ratings.push({ imdbId, rating, title: title || '', year: year || 0 });
    }
  }
  return ratings;
}

async function pullRatings() {
  if (!IMDB_CSV) {
    console.log('⚠️  No IMDB_RATINGS_CSV path set. Download your ratings from:');
    console.log('   https://www.imdb.com/list/ratings → Export');
    return;
  }

  if (!fs.existsSync(IMDB_CSV)) {
    console.log(`⚠️  IMDB CSV not found at: ${IMDB_CSV}`);
    return;
  }

  console.log('📥 Reading IMDB ratings CSV...');
  const csvContent = fs.readFileSync(IMDB_CSV, 'utf-8');
  const imdbRatings = parseIMDBCsv(csvContent);
  console.log(`   Found ${imdbRatings.length} IMDB ratings`);

  // Get existing Trakt ratings to check for conflicts
  const { movies: traktMovies } = await fetchTraktRatings();
  const traktImdbMap = new Map();
  for (const item of traktMovies) {
    const imdbId = item.movie?.ids?.imdb;
    if (imdbId) traktImdbMap.set(imdbId, item.rating);
  }

  // Only import ratings that don't exist in Trakt (SeenIt ratings win)
  const toImport = imdbRatings.filter(r => !traktImdbMap.has(r.imdbId));
  const skipped = imdbRatings.length - toImport.length;
  console.log(`   Importing ${toImport.length} new ratings (skipping ${skipped} — already in Trakt/SeenIt)`);

  if (toImport.length === 0) {
    console.log('   ✅ Nothing new to import');
  } else {
    // Batch import ratings to Trakt
    const ratingBatch = toImport.map(r => ({
      title: r.title,
      year: r.year,
      ids: { imdb: r.imdbId },
      rating: r.rating,
      rated_at: new Date().toISOString(),
    }));

    const res = await fetch(`${TRAKT_BASE}/sync/ratings`, {
      method: 'POST',
      headers: traktHeaders(),
      body: JSON.stringify({ movies: ratingBatch }),
    });

    if (res.ok) {
      const result = await res.json();
      console.log(`   ✅ Imported ${result.added?.movies || toImport.length} ratings to Trakt`);
    } else {
      console.log(`   ❌ Rating import failed: ${res.status} ${res.statusText}`);
    }
  }

  // ── Also mark ALL IMDB-rated items as watched in Trakt history ──
  // A rated movie was watched. Without this, BrowsePage (which checks
  // /sync/watched) won't know you've seen it — the "seen" badge and
  // fade-out won't trigger even though you rated it on IMDB years ago.
  // We send the full list every time; Trakt deduplicates server-side.
  console.log('   📺 Syncing watch history for all IMDB-rated items...');
  const historyBatch = imdbRatings.map(r => ({
    title: r.title,
    year: r.year,
    ids: { imdb: r.imdbId },
    watched_at: new Date().toISOString(),
  }));

  // Trakt accepts up to 500 items per request — batch in chunks
  const CHUNK = 500;
  let historyAdded = 0;
  for (let i = 0; i < historyBatch.length; i += CHUNK) {
    const chunk = historyBatch.slice(i, i + CHUNK);
    const hRes = await fetch(`${TRAKT_BASE}/sync/history`, {
      method: 'POST',
      headers: traktHeaders(),
      body: JSON.stringify({ movies: chunk }),
    });
    if (hRes.ok) {
      const hResult = await hRes.json();
      historyAdded += hResult.added?.movies || chunk.length;
    } else {
      console.log(`   ⚠️  History chunk ${i / CHUNK + 1} failed: ${hRes.status}`);
    }
  }
  console.log(`   ✅ Marked ${historyAdded} items as watched in Trakt history`);

  // Update sync timestamp
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  const existing = fs.existsSync(SYNC_LOG) ? JSON.parse(fs.readFileSync(SYNC_LOG, 'utf-8')) : {};
  existing.lastPull = new Date().toISOString();
  fs.writeFileSync(SYNC_LOG, JSON.stringify(existing));
}

// ── CHECK: Alert if sync is stale ──

function checkStaleness() {
  if (!fs.existsSync(SYNC_LOG)) {
    console.log('🚨 ALERT: Ratings have NEVER been synced!');
    console.log('   Run: node scripts/ratings-sync.mjs --all');
    return { stale: true, daysSincePush: Infinity, daysSincePull: Infinity };
  }

  const log = JSON.parse(fs.readFileSync(SYNC_LOG, 'utf-8'));
  const now = Date.now();
  const WEEK_MS = 7 * 24 * 60 * 60 * 1000;

  const pushAge = log.lastPush ? (now - new Date(log.lastPush).getTime()) : Infinity;
  const pullAge = log.lastPull ? (now - new Date(log.lastPull).getTime()) : Infinity;
  const daysSincePush = Math.round(pushAge / (24 * 60 * 60 * 1000));
  const daysSincePull = Math.round(pullAge / (24 * 60 * 60 * 1000));

  let stale = false;

  if (pushAge > WEEK_MS) {
    console.log(`🚨 ALERT: Ratings haven't been PUSHED to IMDB/Letterboxd in ${daysSincePush} days!`);
    stale = true;
  } else {
    console.log(`✅ Last push: ${daysSincePush} day(s) ago (${log.lastPush})`);
  }

  if (pullAge > WEEK_MS) {
    console.log(`🚨 ALERT: Ratings haven't been PULLED from IMDB in ${daysSincePull} days!`);
    stale = true;
  } else if (log.lastPull) {
    console.log(`✅ Last pull: ${daysSincePull} day(s) ago (${log.lastPull})`);
  } else {
    console.log(`⚠️  IMDB pull has never been run`);
  }

  if (!stale) console.log('👍 All syncs are current');

  return { stale, daysSincePush, daysSincePull };
}

// ── CLI ──

const args = process.argv.slice(2);
const doAll = args.includes('--all') || args.length === 0;
const doPush = doAll || args.includes('--push');
const doPull = doAll || args.includes('--pull');
const doCheck = doAll || args.includes('--check');

console.log('═══════════════════════════════════════');
console.log('  SeenIt Ratings Sync');
console.log('═══════════════════════════════════════\n');

try {
  if (doCheck) checkStaleness();
  if (doPush) await pushRatings();
  if (doPull) await pullRatings();
  console.log('\n✅ Done!');
} catch (err) {
  console.error('\n❌ Error:', err.message);
  process.exit(1);
}
