/**
 * Local Storage and Caching
 * Manages localStorage caching, lookups, and OAuth tokens
 */

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttlMinutes: number;
}

interface LookupData {
  tmdbId: number;
  title: string;
  year?: number;
  posterPath?: string;
  mediaType: 'movie' | 'tv';
  searchedAt: number;
}

// RecentLookup type imported from types
import type { RecentLookup } from '../types';

interface TraktToken {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  token_type: string;
}

const CACHE_PREFIX = 'seenit_cache_';
const LOOKUP_PREFIX = 'seenit_lookup_';
const RECENT_LOOKUPS_KEY = 'seenit_recent_lookups';
const NOTES_PREFIX = 'seenit_notes_';
const TRAKT_TOKEN_KEY = 'seenit_trakt_token';

// ── Storage budget ──
// localStorage is typically 5-10 MB. We budget 3 MB for SeenIt to leave
// headroom for other origins sharing the same limit on some browsers.
const STORAGE_BUDGET_BYTES = 3 * 1024 * 1024;   // 3 MB
const MAX_LOOKUPS = 150;   // cap lookup entries (LRU eviction)
const MAX_ENGAGEMENT_GENRES = 40; // cap genre tally keys

/**
 * Get a value from cache (with TTL checking)
 */
export function cacheGet<T>(key: string): T | null {
  try {
    const stored = localStorage.getItem(`${CACHE_PREFIX}${key}`);
    if (!stored) return null;

    const entry = JSON.parse(stored) as CacheEntry<T>;
    const now = Date.now();
    const ageMinutes = (now - entry.timestamp) / 1000 / 60;

    // Check if expired
    if (ageMinutes > entry.ttlMinutes) {
      localStorage.removeItem(`${CACHE_PREFIX}${key}`);
      return null;
    }

    return entry.data;
  } catch (error) {
    console.error('Error reading cache:', error);
    return null;
  }
}

/**
 * Set a value in cache with TTL.
 * On quota error, evicts expired entries + oldest lookups, then retries once.
 */
export function cacheSet<T>(key: string, value: T, ttlMinutes = 60): void {
  const entry: CacheEntry<T> = {
    data: value,
    timestamp: Date.now(),
    ttlMinutes,
  };
  const raw = JSON.stringify(entry);

  try {
    localStorage.setItem(`${CACHE_PREFIX}${key}`, raw);
  } catch {
    // Likely QuotaExceededError — free space and retry
    console.warn('[storage] write failed, evicting to free space...');
    pruneExpiredCache();
    evictOldestLookups(Math.max(20, MAX_LOOKUPS / 2)); // drop oldest half
    try {
      localStorage.setItem(`${CACHE_PREFIX}${key}`, raw);
    } catch (err2) {
      console.error('[storage] write still failed after eviction:', err2);
    }
  }
}

/**
 * Get cached lookup data for a TMDB ID
 */
export function getCachedLookup(tmdbId: number): LookupData | null {
  try {
    const stored = localStorage.getItem(`${LOOKUP_PREFIX}${tmdbId}`);
    if (!stored) return null;

    return JSON.parse(stored) as LookupData;
  } catch (error) {
    console.error('Error reading cached lookup:', error);
    return null;
  }
}

/**
 * Cache lookup data for a TMDB ID.
 * Enforces MAX_LOOKUPS cap — evicts oldest entries when full.
 */
export function setCachedLookup(tmdbId: number, data: LookupData): void {
  try {
    // Enforce cap before writing
    evictOldestLookups(MAX_LOOKUPS - 1); // make room for this one
    localStorage.setItem(`${LOOKUP_PREFIX}${tmdbId}`, JSON.stringify(data));
  } catch {
    // Quota error — drop half the lookups and retry
    evictOldestLookups(Math.max(20, MAX_LOOKUPS / 2));
    try {
      localStorage.setItem(`${LOOKUP_PREFIX}${tmdbId}`, JSON.stringify(data));
    } catch { /* give up silently */ }
  }
}

/**
 * Get list of recent lookups (last 20)
 */
export function getRecentLookups(): RecentLookup[] {
  try {
    const stored = localStorage.getItem(RECENT_LOOKUPS_KEY);
    if (!stored) return [];

    return JSON.parse(stored) as RecentLookup[];
  } catch (error) {
    console.error('Error reading recent lookups:', error);
    return [];
  }
}

/**
 * Add item to recent lookups
 */
export function addRecentLookup(item: {
  tmdbId: number;
  title: string;
  posterPath?: string;
  mediaType: 'movie' | 'tv';
}): void {
  try {
    const recent = getRecentLookups();

    // Remove if already exists (to move to front)
    const filtered = recent.filter((r) => r.tmdbId !== item.tmdbId);

    // Add new item at front
    const updated: RecentLookup[] = [
      {
        ...item,
        lastViewed: Date.now(),
      },
      ...filtered,
    ];

    // Keep only last 20
    const limited = updated.slice(0, 20);

    localStorage.setItem(RECENT_LOOKUPS_KEY, JSON.stringify(limited));
  } catch (error) {
    console.error('Error adding to recent lookups:', error);
  }
}

/**
 * Get personal notes for a title
 */
export function getNotes(tmdbId: number): string {
  try {
    const stored = localStorage.getItem(`${NOTES_PREFIX}${tmdbId}`);
    return stored || '';
  } catch (error) {
    console.error('Error reading notes:', error);
    return '';
  }
}

/**
 * Set personal notes for a title
 */
export function setNotes(tmdbId: number, notes: string): void {
  try {
    if (notes.trim()) {
      localStorage.setItem(`${NOTES_PREFIX}${tmdbId}`, notes);
    } else {
      localStorage.removeItem(`${NOTES_PREFIX}${tmdbId}`);
    }
  } catch (error) {
    console.error('Error writing notes:', error);
  }
}

/**
 * Get Trakt OAuth tokens
 */
export function getTraktToken(): TraktToken | null {
  try {
    const stored = localStorage.getItem(TRAKT_TOKEN_KEY);
    if (!stored) return null;

    return JSON.parse(stored) as TraktToken;
  } catch (error) {
    console.error('Error reading Trakt token:', error);
    return null;
  }
}

/**
 * Set Trakt OAuth tokens
 */
export function setTraktToken(token: TraktToken): void {
  try {
    localStorage.setItem(TRAKT_TOKEN_KEY, JSON.stringify(token));
  } catch (error) {
    console.error('Error writing Trakt token:', error);
  }
}

/**
 * Clear all SeenIt cache
 */
export function clearAllCache(): void {
  try {
    const keys = Object.keys(localStorage);
    keys.forEach((key) => {
      if (key.startsWith('seenit_')) {
        localStorage.removeItem(key);
      }
    });
  } catch (error) {
    console.error('Error clearing cache:', error);
  }
}

/**
 * Invalidate browse-related caches so the next BrowsePage load
 * re-fetches Trakt status. Call after marking items watched/hidden/watchlisted.
 */
export function invalidateBrowseCaches(): void {
  try {
    localStorage.removeItem(`${CACHE_PREFIX}browse_hidden`);
    localStorage.removeItem(`${CACHE_PREFIX}browse_watched`);
    localStorage.removeItem(`${CACHE_PREFIX}browse_watchlist`);
    localStorage.removeItem(`${CACHE_PREFIX}curated_feed`);
    // Also clear library caches so My Picks reflects changes immediately
    localStorage.removeItem(`${CACHE_PREFIX}library_full`);
    localStorage.removeItem(`${CACHE_PREFIX}library_critics`);
  } catch { /* ignore */ }
}

// ── OMDB daily quota tracking ──
const OMDB_QUOTA_KEY = 'seenit_omdb_quota';
const OMDB_DAILY_LIMIT = 1000;

interface OmdbQuota { count: number; date: string }

function getOmdbQuota(): OmdbQuota {
  try {
    const raw = localStorage.getItem(OMDB_QUOTA_KEY);
    if (raw) {
      const q = JSON.parse(raw) as OmdbQuota;
      const today = new Date().toISOString().slice(0, 10);
      if (q.date === today) return q;
    }
  } catch { /* ignore */ }
  return { count: 0, date: new Date().toISOString().slice(0, 10) };
}

/** Increment the daily OMDB request counter. Returns false if quota exhausted. */
export function trackOmdbRequest(): boolean {
  const q = getOmdbQuota();
  if (q.count >= OMDB_DAILY_LIMIT) return false;
  q.count++;
  try { localStorage.setItem(OMDB_QUOTA_KEY, JSON.stringify(q)); } catch { /* ignore */ }
  return true;
}

/** Get remaining OMDB requests for today. */
export function getOmdbRemaining(): number {
  const q = getOmdbQuota();
  return Math.max(0, OMDB_DAILY_LIMIT - q.count);
}

/**
 * Prune expired cache entries + orphaned keys to free localStorage space.
 * Call this on app startup to prevent unbounded growth.
 */
export function pruneExpiredCache(): number {
  let removed = 0;
  try {
    const keys = Object.keys(localStorage);
    const now = Date.now();

    // 1. Remove expired TTL-based cache entries
    for (const key of keys) {
      if (!key.startsWith(CACHE_PREFIX)) continue;
      try {
        const raw = localStorage.getItem(key);
        if (!raw) continue;
        const entry = JSON.parse(raw) as CacheEntry<unknown>;
        const ageMin = (now - entry.timestamp) / 60000;
        if (ageMin > entry.ttlMinutes) {
          localStorage.removeItem(key);
          removed++;
        }
      } catch {
        // Corrupted entry — remove it
        localStorage.removeItem(key);
        removed++;
      }
    }

    // 2. Cap lookup entries (LRU by searchedAt)
    removed += evictOldestLookups(MAX_LOOKUPS);

    // 3. Cap engagement genre keys
    removed += trimEngagementGenres();

  } catch { /* ignore */ }
  return removed;
}

/**
 * Evict oldest lookup entries until count <= maxKeep.
 * Returns number of entries removed.
 */
function evictOldestLookups(maxKeep: number): number {
  let removed = 0;
  try {
    const keys = Object.keys(localStorage).filter(k => k.startsWith(LOOKUP_PREFIX));
    if (keys.length <= maxKeep) return 0;

    // Parse and sort by searchedAt (oldest first)
    const entries: { key: string; ts: number }[] = [];
    for (const key of keys) {
      try {
        const raw = localStorage.getItem(key);
        if (!raw) { localStorage.removeItem(key); removed++; continue; }
        const data = JSON.parse(raw) as LookupData;
        entries.push({ key, ts: data.searchedAt || 0 });
      } catch {
        localStorage.removeItem(key); removed++;
      }
    }

    entries.sort((a, b) => a.ts - b.ts); // oldest first
    const toRemove = entries.length - maxKeep;
    for (let i = 0; i < toRemove && i < entries.length; i++) {
      localStorage.removeItem(entries[i].key);
      removed++;
    }
  } catch { /* ignore */ }
  return removed;
}

/**
 * Trim genre engagement data to keep only the top N genres by count.
 * Prevents the tally object from growing unbounded.
 */
function trimEngagementGenres(): number {
  try {
    const raw = localStorage.getItem('seenit_genre_engagement');
    if (!raw) return 0;
    const data = JSON.parse(raw) as { genres: Record<string, number>; decades: Record<string, number>; updated: number };
    const genreEntries = Object.entries(data.genres);
    if (genreEntries.length <= MAX_ENGAGEMENT_GENRES) return 0;

    // Keep only the top N by count
    genreEntries.sort(([, a], [, b]) => b - a);
    const kept = Object.fromEntries(genreEntries.slice(0, MAX_ENGAGEMENT_GENRES));
    const trimmed = genreEntries.length - MAX_ENGAGEMENT_GENRES;
    data.genres = kept;
    localStorage.setItem('seenit_genre_engagement', JSON.stringify(data));
    return trimmed;
  } catch { return 0; }
}

/**
 * Get total bytes used by all SeenIt keys in localStorage.
 */
export function getStorageBytes(): number {
  try {
    let total = 0;
    for (const key of Object.keys(localStorage)) {
      if (!key.startsWith('seenit_')) continue;
      const val = localStorage.getItem(key);
      // Each char is ~2 bytes in JS strings (UTF-16)
      total += (key.length + (val?.length || 0)) * 2;
    }
    return total;
  } catch { return 0; }
}

// ── Personal vibe keywords ──
// Thematic clusters of TMDB keyword IDs that reflect the viewer's specific
// interests beyond genre. Each load picks 1-2 clusters for a "Your Vibes" row.

const VIBES_KEY = 'seenit_vibes';

export interface VibeCluster {
  label: string;           // human-readable name for the cluster
  subtitle: string;        // what shows under the row title
  keywordIds: number[];    // TMDB keyword IDs (OR-combined in discover)
}

/**
 * Each vibe has an optional `group` — pickVibes won't select two vibes
 * from the same group in the same feed load (e.g. no "Queer Cinema" AND
 * "Queer History" on the same screen).
 */
interface VibeWithGroup extends VibeCluster { group?: string }

const DEFAULT_VIBES: VibeWithGroup[] = [
  { label: 'Queer Cinema', subtitle: 'Stories that see you', keywordIds: [158718, 264384, 300642, 824, 1886], group: 'queer' },
  { label: 'Camp & Kink', subtitle: 'Over the top and proud of it', keywordIds: [155493, 158713, 199817], group: 'queer' },
  { label: 'Road Trip', subtitle: 'Windows down, nowhere to be', keywordIds: [7312] },
  { label: 'DC & Politics', subtitle: 'Power, scandal, and sharp suits', keywordIds: [521, 169086] },
  { label: 'Indie & Physical', subtitle: 'Small studios, big presence', keywordIds: [281237, 14666, 208135] },
  { label: 'Queer History', subtitle: 'The relationships they tried to erase', keywordIds: [158718, 300642, 1886], group: 'queer' },
];

/**
 * Get the viewer's personal vibe clusters.
 * Returns stored vibes or defaults.
 */
export function getVibes(): VibeCluster[] {
  try {
    const raw = localStorage.getItem(VIBES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as VibeCluster[];
      if (parsed.length > 0) return parsed;
    }
  } catch { /* ignore */ }
  return DEFAULT_VIBES;
}

/**
 * Save custom vibe clusters (for future UI where users can edit).
 */
export function setVibes(vibes: VibeCluster[]): void {
  try {
    localStorage.setItem(VIBES_KEY, JSON.stringify(vibes));
  } catch { /* ignore */ }
}

/**
 * Pick 1-2 random vibe clusters, never two from the same group.
 * E.g. you'll get "Queer Cinema" OR "Queer History" — never both.
 */
export function pickVibes(count = 2): VibeCluster[] {
  const all: VibeWithGroup[] = getVibes() as VibeWithGroup[];
  const shuffled = [...all].sort(() => Math.random() - 0.5);
  const picked: VibeCluster[] = [];
  const usedGroups = new Set<string>();

  for (const v of shuffled) {
    if (picked.length >= count) break;
    if (v.group && usedGroups.has(v.group)) continue; // skip same-group dupe
    picked.push(v);
    if (v.group) usedGroups.add(v.group);
  }
  return picked;
}

// ── Viewer engagement tracking (powers smart shuffle) ──
//
// Three-signal feedback loop:
//   Taps   (1×)  — interest: you clicked to learn more
//   Watches (3×) — commitment: you sat through the whole thing
//   Ratings (5×) — opinion: you cared enough to score it
//
// All signals decay over time so the algorithm follows where you're going,
// not where you've been. Half-life: ~90 days. The decay is applied at read
// time (getWeightedGenres / getWeightedDecade) so writes stay cheap.

const ENGAGEMENT_KEY = 'seenit_genre_engagement';

/** Signal weight multipliers */
const TAP_WEIGHT = 1;
const WATCH_WEIGHT = 3;
const RATING_WEIGHT = 5;

/** Half-life in milliseconds (~90 days). After 90 days a signal is worth
 *  half as much; after 180 days a quarter, etc. */
const HALF_LIFE_MS = 90 * 24 * 60 * 60 * 1000;

interface EngagementEvent {
  weight: number;  // TAP / WATCH / RATING multiplied by count
  ts: number;      // when it happened
}

interface EngagementData {
  genres: Record<number, number>;   // genre_id → raw weighted score
  decades: Record<string, number>;  // "80s" → raw weighted score
  updated: number;
  /** Per-signal event log — kept small (last 200 events max) for decay calc */
  events?: EngagementEvent[];
  /** Per-genre timestamped events for time-decay scoring */
  genreEvents?: Record<number, EngagementEvent[]>;
  /** Per-decade timestamped events */
  decadeEvents?: Record<string, EngagementEvent[]>;
}

function getEngagementData(): EngagementData {
  try {
    const raw = localStorage.getItem(ENGAGEMENT_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return { genres: {}, decades: {}, updated: Date.now(), genreEvents: {}, decadeEvents: {} };
}

function saveEngagementData(data: EngagementData): void {
  try {
    // Cap event lists to prevent unbounded growth (keep newest 60 per genre/decade)
    if (data.genreEvents) {
      for (const gid of Object.keys(data.genreEvents)) {
        const evts = data.genreEvents[Number(gid)];
        if (evts && evts.length > 60) data.genreEvents[Number(gid)] = evts.slice(0, 60);
      }
    }
    if (data.decadeEvents) {
      for (const dec of Object.keys(data.decadeEvents)) {
        const evts = data.decadeEvents[dec];
        if (evts && evts.length > 60) data.decadeEvents[dec] = evts.slice(0, 60);
      }
    }
    localStorage.setItem(ENGAGEMENT_KEY, JSON.stringify(data));
  } catch { /* ignore */ }
}

const RECENT_TAPS_KEY = 'seenit_recent_taps';
const MAX_RECENT_TAPS = 8;

interface RecentTap {
  genreIds: number[];
  ts: number;
}

/** Compute a year → decade label */
function yearToDecade(year: number): string {
  if (year < 1970) return '60s';
  if (year < 1980) return '70s';
  if (year < 1990) return '80s';
  if (year < 2000) return '90s';
  if (year < 2010) return '2000s';
  if (year < 2020) return '2010s';
  return '2020s';
}

/**
 * Internal: record an engagement event with a given weight.
 */
function recordEngagement(genreIds: number[], year: number | null, weight: number): void {
  try {
    const data = getEngagementData();
    const now = Date.now();
    const evt: EngagementEvent = { weight, ts: now };

    // Update genre tallies + event logs
    if (!data.genreEvents) data.genreEvents = {};
    for (const g of genreIds) {
      data.genres[g] = (data.genres[g] || 0) + weight;
      if (!data.genreEvents[g]) data.genreEvents[g] = [];
      data.genreEvents[g].unshift(evt);
    }

    // Update decade tallies + event logs
    if (year) {
      if (!data.decadeEvents) data.decadeEvents = {};
      const dec = yearToDecade(year);
      data.decades[dec] = (data.decades[dec] || 0) + weight;
      if (!data.decadeEvents[dec]) data.decadeEvents[dec] = [];
      data.decadeEvents[dec].unshift(evt);
    }

    data.updated = now;
    saveEngagementData(data);
  } catch { /* ignore */ }
}

/**
 * Track a poster tap — lightweight interest signal (1×).
 * Call on every poster tap. Also records recent taps for mood detection.
 */
export function trackEngagement(genreIds: number[], year: number | null): void {
  recordEngagement(genreIds, year, TAP_WEIGHT);

  // Recent taps (rolling window for mood detection)
  try {
    let recent: RecentTap[] = [];
    try {
      const raw = localStorage.getItem(RECENT_TAPS_KEY);
      if (raw) recent = JSON.parse(raw);
    } catch { /* ignore */ }
    recent.unshift({ genreIds, ts: Date.now() });
    if (recent.length > MAX_RECENT_TAPS) recent = recent.slice(0, MAX_RECENT_TAPS);
    localStorage.setItem(RECENT_TAPS_KEY, JSON.stringify(recent));
  } catch { /* ignore */ }
}

/**
 * Track a watch — commitment signal (3×).
 * Call when the user marks something as watched.
 */
export function trackWatch(genreIds: number[], year: number | null): void {
  recordEngagement(genreIds, year, WATCH_WEIGHT);
}

/**
 * Track a rating — opinion signal (5×).
 * Call when the user rates something. Higher ratings boost more.
 * A 10/10 = 5× weight, a 1/10 = 1× weight (they still watched it).
 */
export function trackRating(genreIds: number[], year: number | null, rating: number): void {
  // Scale: rating 1-10 maps to weight 1-5 (RATING_WEIGHT)
  const scaled = Math.max(1, Math.round((rating / 10) * RATING_WEIGHT));
  recordEngagement(genreIds, year, scaled);
}

/**
 * Apply time-decay to a list of engagement events and return a weighted score.
 * Uses exponential decay with the configured half-life.
 */
function decayScore(events: EngagementEvent[] | undefined): number {
  if (!events || events.length === 0) return 0;
  const now = Date.now();
  let score = 0;
  for (const evt of events) {
    const age = now - evt.ts;
    // Exponential decay: weight × 0.5^(age / halfLife)
    const decay = Math.pow(0.5, age / HALF_LIFE_MS);
    score += evt.weight * decay;
  }
  return score;
}

/**
 * Get the viewer's top genre IDs by time-decayed weighted engagement.
 * Taps count 1×, watches 3×, ratings up to 5× — all decaying over ~90 days.
 * Returns up to `limit` genre IDs sorted by decayed score.
 */
export function getTopGenres(limit = 5): number[] {
  const data = getEngagementData();

  // If we have timestamped events, use decay scoring
  if (data.genreEvents && Object.keys(data.genreEvents).length > 0) {
    const scored: [number, number][] = [];
    for (const [gid, events] of Object.entries(data.genreEvents)) {
      const s = decayScore(events);
      if (s > 0.01) scored.push([Number(gid), s]);
    }
    return scored
      .sort(([, a], [, b]) => b - a)
      .slice(0, limit)
      .map(([id]) => id);
  }

  // Fallback: raw tallies (pre-upgrade data)
  return Object.entries(data.genres)
    .sort(([, a], [, b]) => b - a)
    .slice(0, limit)
    .map(([id]) => Number(id));
}

/**
 * Get the viewer's most-engaged decade label (e.g. "80s") by decayed score.
 */
export function getTopDecade(): string | null {
  const data = getEngagementData();

  // If we have timestamped events, use decay scoring
  if (data.decadeEvents && Object.keys(data.decadeEvents).length > 0) {
    let best: string | null = null;
    let bestScore = 0;
    for (const [dec, events] of Object.entries(data.decadeEvents)) {
      const s = decayScore(events);
      if (s > bestScore) { best = dec; bestScore = s; }
    }
    return best;
  }

  // Fallback: raw tallies
  const entries = Object.entries(data.decades);
  if (entries.length === 0) return null;
  entries.sort(([, a], [, b]) => b - a);
  return entries[0][0];
}

// ── Mood context engine ──
// Reads the clock, the calendar, and the viewer's recent emotional trajectory
// to generate a sense of *what kind of night this is*.

/**
 * Genre IDs by emotional register — NOT by darkness or scariness.
 * "Heavy" = slow, emotional, slow burn (the kind of film you sit with).
 * "Light" = fun, fast, energetic.
 * "Intense" = gripping tension, edge-of-seat.
 * Horror is intense, not heavy. Foreign films aren't inherently heavy.
 */
const HEAVY_GENRES = new Set([18, 36, 99]);       // Drama, History, Documentary — slow burn
const LIGHT_GENRES = new Set([35, 16, 10402, 28, 12]); // Comedy, Animation, Music, Action, Adventure
const INTENSE_GENRES = new Set([27, 53, 878, 80, 9648, 10752]); // Horror, Thriller, Sci-Fi, Crime, Mystery, War

export interface MoodContext {
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'latenight';
  dayName: string;
  isWeekend: boolean;
  recentTone: 'heavy' | 'light' | 'intense' | 'mixed' | 'unknown';
  hasHistory: boolean; // have they used the app enough for us to read them
}

export function getMoodContext(): MoodContext {
  const now = new Date();
  const hour = now.getHours();
  const day = now.getDay(); // 0=Sun, 6=Sat

  const timeOfDay: MoodContext['timeOfDay'] =
    hour < 12 ? 'morning'
    : hour < 17 ? 'afternoon'
    : hour < 21 ? 'evening'
    : 'latenight';

  const dayName = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][day];
  const isWeekend = day === 0 || day === 5 || day === 6; // Fri-Sun

  // Read recent taps to detect emotional trajectory
  let recentTone: MoodContext['recentTone'] = 'unknown';
  let hasHistory = false;
  try {
    const raw = localStorage.getItem(RECENT_TAPS_KEY);
    if (raw) {
      const taps: RecentTap[] = JSON.parse(raw);
      // Only consider taps from the last 7 days
      const recent = taps.filter(t => Date.now() - t.ts < 7 * 24 * 60 * 60 * 1000);
      if (recent.length >= 3) {
        hasHistory = true;
        const allGenres = recent.flatMap(t => t.genreIds);
        const heavyCount = allGenres.filter(g => HEAVY_GENRES.has(g)).length;
        const lightCount = allGenres.filter(g => LIGHT_GENRES.has(g)).length;
        const intenseCount = allGenres.filter(g => INTENSE_GENRES.has(g)).length;
        const total = allGenres.length || 1;

        if (heavyCount / total > 0.4) recentTone = 'heavy';
        else if (lightCount / total > 0.4) recentTone = 'light';
        else if (intenseCount / total > 0.4) recentTone = 'intense';
        else recentTone = 'mixed';
      }
    }
  } catch { /* ignore */ }

  return { timeOfDay, dayName, isWeekend, recentTone, hasHistory };
}

/**
 * Get cache statistics (includes byte-level size tracking).
 */
export function getCacheStats(): {
  cacheEntries: number;
  lookupEntries: number;
  totalSize: number;
  totalBytes: number;
  budgetBytes: number;
  budgetPct: number;
} {
  try {
    const keys = Object.keys(localStorage);
    const cacheKeys = keys.filter((k) => k.startsWith(CACHE_PREFIX));
    const lookupKeys = keys.filter((k) => k.startsWith(LOOKUP_PREFIX));

    let totalSize = 0;
    keys.forEach((key) => {
      if (key.startsWith('seenit_')) {
        const item = localStorage.getItem(key);
        totalSize += item ? item.length : 0;
      }
    });

    const totalBytes = getStorageBytes();

    return {
      cacheEntries: cacheKeys.length,
      lookupEntries: lookupKeys.length,
      totalSize,
      totalBytes,
      budgetBytes: STORAGE_BUDGET_BYTES,
      budgetPct: Math.round((totalBytes / STORAGE_BUDGET_BYTES) * 100),
    };
  } catch (error) {
    console.error('Error getting cache stats:', error);
    return { cacheEntries: 0, lookupEntries: 0, totalSize: 0, totalBytes: 0, budgetBytes: STORAGE_BUDGET_BYTES, budgetPct: 0 };
  }
}
