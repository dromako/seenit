/**
 * TMDB Discover API Client
 * Powers the Browse Mode — continuous movie/TV discovery feed
 */

const TMDB_BASE = 'https://api.themoviedb.org/3';
const API_KEY = import.meta.env.VITE_TMDB_API_KEY;

export interface DiscoverItem {
  id: number;
  title: string;
  poster_path: string | null;
  backdrop_path: string | null;
  media_type: 'movie' | 'tv';
  year: number | null;
  vote_average: number;
  vote_count: number;
  overview: string;
  genre_ids: number[];
}

export interface DiscoverResponse {
  results: DiscoverItem[];
  page: number;
  total_pages: number;
  total_results: number;
}

/** Genre maps for quick lookup */
export const MOVIE_GENRES: Record<number, string> = {
  28: 'Action', 12: 'Adventure', 16: 'Animation', 35: 'Comedy',
  80: 'Crime', 99: 'Documentary', 18: 'Drama', 10751: 'Family',
  14: 'Fantasy', 36: 'History', 27: 'Horror', 10402: 'Music',
  9648: 'Mystery', 10749: 'Romance', 878: 'Sci-Fi', 10770: 'TV Movie',
  53: 'Thriller', 10752: 'War', 37: 'Western',
};

export const TV_GENRES: Record<number, string> = {
  10759: 'Action & Adventure', 16: 'Animation', 35: 'Comedy',
  80: 'Crime', 99: 'Documentary', 18: 'Drama', 10751: 'Family',
  10762: 'Kids', 9648: 'Mystery', 10763: 'News', 10764: 'Reality',
  10765: 'Sci-Fi & Fantasy', 10766: 'Soap', 10767: 'Talk',
  10768: 'War & Politics', 37: 'Western',
};

/** Mood-based browse tabs — cinephile picks by feeling, not genre label */
export const BROWSE_GENRES = [
  { id: 0, name: 'Trending' },
  { id: 27, name: 'Get Scared' },
  { id: 35, name: 'Make Me Laugh' },
  { id: 18, name: 'Feel Something' },
  { id: 878, name: 'Mind-Bending' },
  { id: 99, name: 'Learn Something' },
  { id: 28, name: 'Adrenaline' },
  { id: 53, name: 'On the Edge' },
  { id: 10749, name: 'Fall in Love' },
  { id: -1, name: 'So Bad It\'s Good' },
];

// US free/ad-supported provider IDs (TMDB watch_provider IDs)
// Tubi=73, Pluto=300, Peacock(free)=386, Crackle=12, Plex=538, Kanopy=191, Hoopla=212
const FREE_PROVIDER_IDS = '73|300|386|12|538|191|212';

export type MediaFilter = 'all' | 'movie' | 'tv';
export type SourceFilter = 'all' | 'free';

interface DiscoverParams {
  mediaType: MediaFilter;
  genre: number;         // 0 = trending, -1 = bad movies
  sourceFilter: SourceFilter;
  page: number;
}

/**
 * Fetch trending content from TMDB
 */
async function fetchTrending(
  mediaType: 'movie' | 'tv' | 'all',
  page: number,
): Promise<DiscoverResponse> {
  const type = mediaType === 'all' ? 'all' : mediaType;
  const url = `${TMDB_BASE}/trending/${type}/week?api_key=${API_KEY}&page=${page}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Trending fetch failed: ${res.status}`);
  const data = await res.json();

  const results: DiscoverItem[] = data.results.map((r: any) => ({
    id: r.id,
    title: r.title || r.name || '',
    poster_path: r.poster_path,
    backdrop_path: r.backdrop_path,
    media_type: r.media_type || mediaType,
    year: r.release_date
      ? parseInt(r.release_date.substring(0, 4))
      : r.first_air_date
        ? parseInt(r.first_air_date.substring(0, 4))
        : null,
    vote_average: r.vote_average || 0,
    vote_count: r.vote_count || 0,
    overview: r.overview || '',
    genre_ids: r.genre_ids || [],
  }));

  // If free-only, we'll filter client-side after fetching providers
  return {
    results,
    page: data.page,
    total_pages: Math.min(data.total_pages, 500),
    total_results: data.total_results,
  };
}

/**
 * Fetch from TMDB Discover endpoint (movies or TV)
 */
async function fetchDiscover(
  type: 'movie' | 'tv',
  page: number,
  genreId: number | null,
  badMovies: boolean,
  freeOnly: boolean
): Promise<DiscoverResponse> {
  // For genre tabs: sort by quality (vote_average) with a vote floor so we
  // surface great catalog films, not just whatever's in theaters this week.
  // For trending (genreId=null, !badMovies): keep popularity for recency.
  const defaultSort = genreId ? 'vote_average.desc' : 'popularity.desc';

  const params = new URLSearchParams({
    api_key: API_KEY,
    language: 'en-US',
    watch_region: 'US',
    page: String(page),
    sort_by: badMovies ? 'vote_average.asc' : defaultSort,
    include_adult: 'false',
  });

  if (genreId && genreId > 0) {
    params.set('with_genres', String(genreId));
    // Quality floor: enough votes to be credible, high enough rating to be worth watching
    params.set('vote_count.gte', '150');
    params.set('vote_average.gte', '6.0');
  }

  if (badMovies) {
    params.set('vote_average.lte', '4.5');
    params.set('vote_count.gte', '50');     // enough votes to be "known bad"
    params.set('sort_by', 'vote_count.desc'); // popular bad movies first
  }

  if (freeOnly) {
    params.set('with_watch_monetization_types', 'free|ads');
    params.set('with_watch_providers', FREE_PROVIDER_IDS);
  }

  // Ensure we get things with posters
  params.set('with_poster', 'true');

  const url = `${TMDB_BASE}/discover/${type}?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Discover fetch failed: ${res.status}`);
  const data = await res.json();

  const results: DiscoverItem[] = data.results.map((r: any) => ({
    id: r.id,
    title: r.title || r.name || '',
    poster_path: r.poster_path,
    backdrop_path: r.backdrop_path,
    media_type: type,
    year: r.release_date
      ? parseInt(r.release_date.substring(0, 4))
      : r.first_air_date
        ? parseInt(r.first_air_date.substring(0, 4))
        : null,
    vote_average: r.vote_average || 0,
    vote_count: r.vote_count || 0,
    overview: r.overview || '',
    genre_ids: r.genre_ids || [],
  }));

  return {
    results: results.filter(r => r.poster_path), // only show items with posters
    page: data.page,
    total_pages: Math.min(data.total_pages, 500),
    total_results: data.total_results,
  };
}

// ── Curated feed helpers for the homepage rows ──

/** Pick a random element from an array */
function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export interface CuratedRow {
  id: string;
  title: string;
  subtitle: string;
  reasonTaste: string;  // why this aligns with their viewing history
  reasonMood: string;   // why this feels right for them *right now*
  items: DiscoverItem[];
}

const DECADES = [
  { label: '60s', start: '1960-01-01', end: '1969-12-31' },
  { label: '70s', start: '1970-01-01', end: '1979-12-31' },
  { label: '80s', start: '1980-01-01', end: '1989-12-31' },
  { label: '90s', start: '1990-01-01', end: '1999-12-31' },
  { label: '2000s', start: '2000-01-01', end: '2009-12-31' },
  { label: '2010s', start: '2010-01-01', end: '2019-12-31' },
];

const SPOTLIGHT_GENRES = [
  { id: 99, name: 'Documentary' },
  { id: 878, name: 'Sci-Fi' },
  { id: 27, name: 'Horror' },
  { id: 80, name: 'Crime' },
  { id: 10752, name: 'War' },
  { id: 36, name: 'History' },
  { id: 16, name: 'Animation' },
  { id: 37, name: 'Western' },
  { id: 9648, name: 'Mystery' },
  { id: 14, name: 'Fantasy' },
  { id: 10749, name: 'Romance' },
  { id: 53, name: 'Thriller' },
];

/** Language codes for "world cinema" row — non-English standouts */
const WORLD_LANGUAGES = ['ko', 'ja', 'fr', 'es', 'de', 'it', 'pt', 'zh', 'hi', 'sv', 'da', 'pl', 'tr', 'th'];

/**
 * Fetch a single curated discover row
 */
async function fetchCuratedRow(
  sortBy: string,
  extraParams: Record<string, string>,
  limit = 12,
): Promise<DiscoverItem[]> {
  const params = new URLSearchParams({
    api_key: API_KEY,
    language: 'en-US',
    watch_region: 'US',
    page: String(1 + Math.floor(Math.random() * 5)), // randomise deeper for variety
    sort_by: sortBy,
    include_adult: 'false',
    with_poster: 'true',
    ...extraParams,
  });

  const url = `${TMDB_BASE}/discover/movie?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) return [];
  const data = await res.json();

  return (data.results || [])
    .filter((r: any) => r.poster_path)
    .slice(0, limit)
    .map((r: any): DiscoverItem => ({
      id: r.id,
      title: r.title || r.name || '',
      poster_path: r.poster_path,
      backdrop_path: r.backdrop_path,
      media_type: 'movie',
      year: r.release_date ? parseInt(r.release_date.substring(0, 4)) : null,
      vote_average: r.vote_average || 0,
      vote_count: r.vote_count || 0,
      overview: r.overview || '',
      genre_ids: r.genre_ids || [],
    }));
}

/**
 * Build the full curated homepage feed.
 * Returns up to 9 themed rows, each with ~12 posters.
 * Randomises decade, genre, language, and genre-mash combos each load
 * so it never feels stale. Rows are shuffled (first row pinned).
 */
export interface ViewerAffinities {
  topGenres?: number[];   // genre IDs the viewer taps most
  topDecade?: string;     // e.g. "80s"
}

export interface MoodInput {
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'latenight';
  dayName: string;
  isWeekend: boolean;
  recentTone: 'heavy' | 'light' | 'intense' | 'mixed' | 'unknown';
  hasHistory: boolean;
}

export async function getCuratedFeed(affinities?: ViewerAffinities, mood?: MoodInput): Promise<CuratedRow[]> {
  const hasAffinities = affinities && (affinities.topGenres?.length || affinities.topDecade);

  // When we know the viewer: one slot is their favourite genre, one is a
  // surprise genre they haven't explored. The decade leans toward theirs
  // but the rest stays random. The feed should feel like a friend who knows
  // you picked it — not an algorithm narrowing your world.
  let decade: typeof DECADES[number];
  let genre: typeof SPOTLIGHT_GENRES[number];
  let genreIsPersonal = false;
  let decadeIsPersonal = false;

  if (hasAffinities && affinities?.topDecade) {
    const match = DECADES.find(d => d.label === affinities.topDecade);
    // 60% chance we use their decade, 40% surprise
    decade = match && Math.random() < 0.6 ? match : pickRandom(DECADES);
    decadeIsPersonal = decade === match;
  } else {
    decade = pickRandom(DECADES);
  }

  if (hasAffinities && affinities?.topGenres?.length) {
    const match = SPOTLIGHT_GENRES.find(g => affinities.topGenres!.includes(g.id));
    // 60% chance we use a genre they love
    genre = match && Math.random() < 0.6 ? match : pickRandom(SPOTLIGHT_GENRES);
    genreIsPersonal = genre === match;
  } else {
    genre = pickRandom(SPOTLIGHT_GENRES);
  }

  const worldLang = pickRandom(WORLD_LANGUAGES);

  // Second genre for mash: prefer something they HAVEN'T explored
  const genre2candidates = SPOTLIGHT_GENRES.filter(g => g.id !== genre.id);
  const unexplored = hasAffinities && affinities?.topGenres?.length
    ? genre2candidates.filter(g => !affinities.topGenres!.includes(g.id))
    : genre2candidates;
  const genre2 = unexplored.length > 0 ? pickRandom(unexplored) : pickRandom(genre2candidates);

  const results = await Promise.allSettled([
    // Certified Fresh — high rating, lots of votes, any era
    fetchCuratedRow('vote_average.desc', {
      'vote_count.gte': '2000',
      'vote_average.gte': '7.5',
    }),
    // Hidden Gems — genuinely obscure: good but under-the-radar
    fetchCuratedRow('vote_average.desc', {
      'vote_count.gte': '30',
      'vote_count.lte': '400',
      'vote_average.gte': '7.0',
      without_genres: '10402',  // exclude Music genre (concert films, BTS, etc.)
    }),
    // Decade Classics
    fetchCuratedRow('vote_average.desc', {
      'primary_release_date.gte': decade.start,
      'primary_release_date.lte': decade.end,
      'vote_count.gte': '200',
      'vote_average.gte': '6.8',
    }),
    // Genre Essentials — wider net
    fetchCuratedRow('vote_average.desc', {
      with_genres: String(genre.id),
      'vote_count.gte': '200',
      'vote_average.gte': '6.8',
    }),
    // Free Right Now
    fetchCuratedRow('vote_average.desc', {
      with_watch_monetization_types: 'free|ads',
      with_watch_providers: FREE_PROVIDER_IDS,
      'vote_count.gte': '50',
    }),
    // Recent Critical Darlings — last 3 years
    fetchCuratedRow('vote_average.desc', {
      'primary_release_date.gte': `${new Date().getFullYear() - 3}-01-01`,
      'vote_count.gte': '200',
      'vote_average.gte': '7.0',
    }),
    // World Cinema — non-English standouts
    fetchCuratedRow('vote_average.desc', {
      with_original_language: worldLang,
      'vote_count.gte': '100',
      'vote_average.gte': '7.0',
    }),
    // Deep Cuts — critically excellent but barely known (the true rabbit hole)
    fetchCuratedRow('vote_average.desc', {
      'vote_count.gte': '20',
      'vote_count.lte': '150',
      'vote_average.gte': '7.5',
      without_genres: '10402,10770',  // no music films or TV movies
    }),
    // Genre Mash — two genres combined for unexpected discoveries
    fetchCuratedRow('vote_average.desc', {
      with_genres: `${genre.id},${genre2.id}`,
      'vote_count.gte': '100',
      'vote_average.gte': '6.5',
    }),
  ]);

  // Unwrap settled results — failed fetches become empty arrays instead of crashing the feed
  const unwrap = (r: PromiseSettledResult<DiscoverItem[]>): DiscoverItem[] =>
    r.status === 'fulfilled' ? r.value : [];
  const [certified, hidden, decadeRow, genreRow, freeRow, recentCritical, worldCinema, deepCuts, genreMash] =
    results.map(unwrap);

  const langNames: Record<string, string> = {
    ko: 'Korean', ja: 'Japanese', fr: 'French', es: 'Spanish',
    de: 'German', it: 'Italian', pt: 'Portuguese', zh: 'Chinese',
    hi: 'Hindi', sv: 'Swedish', da: 'Danish', pl: 'Polish',
    tr: 'Turkish', th: 'Thai',
  };

  // ── Build mood-aware reason text ──
  // "reasonTaste" = why this matches their viewing identity
  // "reasonMood"  = why this feels right for who they are *tonight*
  const t = mood?.timeOfDay || 'evening';
  const tone = mood?.recentTone || 'unknown';
  const dayN = mood?.dayName || '';
  const wknd = mood?.isWeekend ?? false;
  const knows = mood?.hasHistory ?? false;

  // Helper: a gentle time-aware line
  function timeFeel(evening: string, late: string, afternoon: string, fallback: string): string {
    if (t === 'latenight') return late;
    if (t === 'evening') return evening;
    if (t === 'afternoon') return afternoon;
    return fallback;
  }

  // Helper: reads the viewer's recent emotional trajectory
  function toneAware(
    afterHeavy: string,
    afterIntense: string,
    afterLight: string,
    neutral: string,
  ): string {
    if (!knows) return neutral;
    if (tone === 'heavy') return afterHeavy;
    if (tone === 'intense') return afterIntense;
    if (tone === 'light') return afterLight;
    return neutral;
  }

  const pool: CuratedRow[] = [];

  if (recentCritical.length > 0) {
    pool.push({
      id: 'recent-critical',
      title: 'Recent Critical Darlings',
      subtitle: 'The films critics can\'t stop talking about',
      reasonTaste: 'New and acclaimed',
      reasonMood: timeFeel(
        'Something fresh for tonight',
        'Still buzzing from this year',
        'Catch up on what everyone\'s talking about',
        'The best of right now',
      ),
      items: recentCritical,
    });
  }
  if (certified.length > 0) {
    pool.push({
      id: 'certified',
      title: 'Certified Fresh',
      subtitle: 'All-time greats that earned every star',
      reasonTaste: 'Universally loved',
      reasonMood: toneAware(
        'Something uplifting after all that heaviness',
        'A sure thing — you\'ve earned a classic',
        'Keep the good energy going',
        'You can\'t go wrong here',
      ),
      items: certified,
    });
  }
  if (hidden.length > 0) {
    pool.push({
      id: 'hidden',
      title: 'Hidden Gems',
      subtitle: 'Films most people haven\'t found yet',
      reasonTaste: 'Almost nobody knows these',
      reasonMood: timeFeel(
        'Perfect for a quiet night — discover something new',
        'A rabbit hole for the night owl in you',
        wknd ? 'A lazy weekend find' : 'Something to look forward to tonight',
        'For the curious',
      ),
      items: hidden,
    });
  }
  if (freeRow.length > 0) {
    pool.push({
      id: 'free',
      title: 'Free Right Now',
      subtitle: 'No subscription needed',
      reasonTaste: 'Free to watch tonight',
      reasonMood: timeFeel(
        'Zero commitment — just press play',
        'Free and ready when you are',
        'Browse now, watch later — all free',
        'No account needed, no strings',
      ),
      items: freeRow,
    });
  }
  if (decadeRow.length > 0) {
    pool.push({
      id: 'decade',
      title: `Best of the ${decade.label}`,
      subtitle: decadeIsPersonal
        ? `We noticed you love the ${decade.label}`
        : `A time capsule of the decade's best`,
      reasonTaste: decadeIsPersonal
        ? `You keep gravitating toward the ${decade.label}`
        : `Great films from the ${decade.label}`,
      reasonMood: decadeIsPersonal
        ? timeFeel(
            `A ${decade.label} film feels right tonight`,
            `Late-night ${decade.label} — your comfort zone`,
            `Revisit the ${decade.label} this ${dayN}`,
            `Back to the ${decade.label}`,
          )
        : timeFeel(
            `Travel back to the ${decade.label} tonight`,
            `The ${decade.label} hit different late at night`,
            `Time-travel for a ${dayN} afternoon`,
            `A different era, a different feel`,
          ),
      items: decadeRow,
    });
  }
  if (genreRow.length > 0) {
    const gn = genre.name.toLowerCase();
    pool.push({
      id: 'genre',
      title: genreIsPersonal ? `More ${genre.name}` : `${genre.name} Essentials`,
      subtitle: genreIsPersonal
        ? `Because you keep coming back to ${gn}`
        : 'The definitive collection',
      reasonTaste: genreIsPersonal
        ? `You love ${gn}`
        : `Exploring ${gn}`,
      reasonMood: genreIsPersonal
        ? toneAware(
            `You\'ve been in a heavy place — ${gn} might be the shift you need`,
            `After all that intensity, more ${gn} could hit right`,
            `You\'re in a ${gn} mood — lean into it`,
            `More of what you love`,
          )
        : timeFeel(
            `A ${gn} night`,
            `Late-night ${gn}`,
            `${genre.name} for a ${dayN}`,
            `Try some ${gn}`,
          ),
      items: genreRow,
    });
  }
  if (worldCinema.length > 0) {
    const ln = langNames[worldLang] || 'world';
    pool.push({
      id: 'world',
      title: `${langNames[worldLang] || 'World'} Cinema`,
      subtitle: 'Subtitles on, phones down',
      reasonTaste: `Something different — ${ln} storytelling`,
      reasonMood: toneAware(
        `After all that drama, a change of perspective`,
        `Step outside the familiar for a bit`,
        `Keep exploring — ${ln} cinema has range`,
        timeFeel(
          `Give your evening to a ${ln} film`,
          `The world looks different after midnight`,
          `A ${dayN} afternoon trip — no passport needed`,
          `Broaden the view`,
        ),
      ),
      items: worldCinema,
    });
  }
  if (deepCuts.length > 0) {
    pool.push({
      id: 'deep-cuts',
      title: 'Deep Cuts',
      subtitle: 'Films only cinephiles know',
      reasonTaste: 'The rabbit hole',
      reasonMood: timeFeel(
        'The kind of film you tell people about tomorrow',
        'Deep cuts hit hardest late at night',
        wknd ? 'Weekend discovery mode' : 'Save one for tonight',
        'For when you want to find something nobody else has seen',
      ),
      items: deepCuts,
    });
  }
  if (genreMash.length > 0) {
    pool.push({
      id: 'genre-mash',
      title: `${genre.name} × ${genre2.name}`,
      subtitle: 'When two worlds collide',
      reasonTaste: `What happens when ${genre.name.toLowerCase()} meets ${genre2.name.toLowerCase()}`,
      reasonMood: timeFeel(
        'Something you wouldn\'t think to search for',
        'The weird stuff finds you late at night',
        'Feeling adventurous?',
        'Trust the unexpected',
      ),
      items: genreMash,
    });
  }

  // Deduplicate across rows — a title should only appear in its first row
  const seen = new Set<number>();
  for (const row of pool) {
    row.items = row.items.filter((item) => {
      if (seen.has(item.id)) return false;
      seen.add(item.id);
      return true;
    });
  }

  // Keep first row stable (recent darlings), shuffle the rest for freshness
  const first = pool.length > 0 ? [pool[0]] : [];
  const rest = pool.slice(1);
  for (let i = rest.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [rest[i], rest[j]] = [rest[j], rest[i]];
  }

  return [...first, ...rest];
}

/**
 * Keyword-based discover — lets users type unusual terms and find matching films
 */
export async function discoverByKeyword(
  keywordIds: number[],
  page = 1,
): Promise<DiscoverResponse> {
  if (keywordIds.length === 0) return { results: [], page: 1, total_pages: 0, total_results: 0 };

  const params = new URLSearchParams({
    api_key: API_KEY,
    language: 'en-US',
    watch_region: 'US',
    page: String(page),
    sort_by: 'vote_average.desc',
    include_adult: 'false',
    with_poster: 'true',
    with_keywords: keywordIds.join('|'),
    'vote_count.gte': '30',
  });

  const url = `${TMDB_BASE}/discover/movie?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) return { results: [], page: 1, total_pages: 0, total_results: 0 };
  const data = await res.json();

  const results: DiscoverItem[] = (data.results || [])
    .filter((r: any) => r.poster_path)
    .map((r: any): DiscoverItem => ({
      id: r.id,
      title: r.title || r.name || '',
      poster_path: r.poster_path,
      backdrop_path: r.backdrop_path,
      media_type: 'movie',
      year: r.release_date ? parseInt(r.release_date.substring(0, 4)) : null,
      vote_average: r.vote_average || 0,
      vote_count: r.vote_count || 0,
      overview: r.overview || '',
      genre_ids: r.genre_ids || [],
    }));

  return {
    results,
    page: data.page,
    total_pages: Math.min(data.total_pages || 0, 500),
    total_results: data.total_results || 0,
  };
}

/**
 * Main discover function — routes to trending or discover based on params
 */
export async function discoverContent(params: DiscoverParams): Promise<DiscoverResponse> {
  const { mediaType, genre, sourceFilter, page } = params;
  const freeOnly = sourceFilter === 'free';
  const isBadMovies = genre === -1;
  const isTrending = genre === 0;

  if (isTrending) {
    // On first page, occasionally pull from deeper pages (2-3) so it's
    // not always the same 20 theatrical releases dominating the view
    const effectivePage = page === 1 && Math.random() < 0.3
      ? 1 + Math.floor(Math.random() * 3)
      : page;
    return fetchTrending(mediaType === 'all' ? 'all' : mediaType, effectivePage);
  }

  // For "all" media type, fetch both and merge
  if (mediaType === 'all') {
    const [movies, tv] = await Promise.all([
      fetchDiscover('movie', page, isBadMovies ? null : genre, isBadMovies, freeOnly),
      fetchDiscover('tv', page, isBadMovies ? null : genre, isBadMovies, freeOnly),
    ]);

    const merged = [...movies.results, ...tv.results]
      .sort((a, b) => {
        if (isBadMovies) return a.vote_average - b.vote_average;
        return b.vote_average - a.vote_average;
      })
      .slice(0, 20);

    return {
      results: merged,
      page,
      total_pages: Math.min(movies.total_pages, tv.total_pages, 500),
      total_results: movies.total_results + tv.total_results,
    };
  }

  return fetchDiscover(mediaType, page, isBadMovies ? null : genre, isBadMovies, freeOnly);
}
