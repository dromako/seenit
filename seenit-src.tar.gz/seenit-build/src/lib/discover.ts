/**
 * TMDB Discover API Client
 * Powers the Browse Mode — continuous movie/TV discovery feed
 */

const TMDB_BASE = 'https://api.themoviedb.org/3';
const API_KEY = import.meta.env.VITE_TMDB_API_KEY;

export interface DiscoverItem {
  id: number;
  title: string;
  poster_path: string | null;
  backdrop_path: string | null;
  media_type: 'movie' | 'tv';
  year: number | null;
  vote_average: number;
  vote_count: number;
  overview: string;
  genre_ids: number[];
}

export interface DiscoverResponse {
  results: DiscoverItem[];
  page: number;
  total_pages: number;
  total_results: number;
}

/** Mood-based browse tabs — cinephile picks by feeling, not genre label */
export const BROWSE_GENRES = [
  { id: 0, name: 'Trending' },
  { id: 27, name: 'Get Scared' },
  { id: 35, name: 'Make Me Laugh' },
  { id: 18, name: 'Feel Something' },
  { id: 878, name: 'Mind-Bending' },
  { id: 99, name: 'Learn Something' },
  { id: 28, name: 'Adrenaline' },
  { id: 53, name: 'On the Edge' },
  { id: 10749, name: 'Fall in Love' },
  { id: -1, name: 'So Bad It\'s Good' },
];

// US free/ad-supported provider IDs (TMDB watch_provider IDs)
// Tubi=73, Pluto=300, Peacock(free)=386, Plex=538, Kanopy=191
const FREE_PROVIDER_IDS = '73|300|386|538|191';

export type MediaFilter = 'all' | 'movie' | 'tv';
export type SourceFilter = 'all' | 'free';

interface DiscoverParams {
  mediaType: MediaFilter;
  genre: number;         // 0 = trending, -1 = bad movies
  sourceFilter: SourceFilter;
  page: number;
}

// Family (10751) and Kids (10762) genre IDs — not blocked, but held to a
// higher bar. Spirited Away / Inside Out / Fantastic Mr. Fox belong in the
// feed; Paw Patrol: The Movie does not. The test: would a childless adult
// cinephile enjoy this? High vote count + high rating = yes.
const FAMILY_GENRE = 10751;
const KIDS_GENRE = 10762;
const KIDS_VOTE_FLOOR = 500;   // Must be widely seen, not just well-rated by parents
const KIDS_RATING_FLOOR = 7.5; // Must be genuinely excellent, not just "good for kids"

/** Returns true if the item should be kept in the feed */
function passesKidFilter(genreIds: number[], voteCount: number, voteAvg: number): boolean {
  const isKidsFamily = genreIds.includes(FAMILY_GENRE) || genreIds.includes(KIDS_GENRE);
  if (!isKidsFamily) return true; // not kids content — always keep
  // Kids/family content must clear a higher bar to earn its spot
  return voteCount >= KIDS_VOTE_FLOOR && voteAvg >= KIDS_RATING_FLOOR;
}

/**
 * Fetch trending content from TMDB
 */
async function fetchTrending(
  mediaType: 'movie' | 'tv' | 'all',
  page: number,
): Promise<DiscoverResponse> {
  const type = mediaType === 'all' ? 'all' : mediaType;
  const url = `${TMDB_BASE}/trending/${type}/week?api_key=${API_KEY}&page=${page}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Trending fetch failed: ${res.status}`);
  const data = await res.json();

  const results: DiscoverItem[] = data.results.map((r: any) => ({
    id: r.id,
    title: r.title || r.name || '',
    poster_path: r.poster_path,
    backdrop_path: r.backdrop_path,
    media_type: r.media_type || mediaType,
    year: r.release_date
      ? parseInt(r.release_date.substring(0, 4))
      : r.first_air_date
        ? parseInt(r.first_air_date.substring(0, 4))
        : null,
    vote_average: r.vote_average || 0,
    vote_count: r.vote_count || 0,
    overview: r.overview || '',
    genre_ids: r.genre_ids || [],
  }));

  // Smart kids/family filter — keeps genuinely great films (Ghibli, Pixar best),
  // filters out narrow-audience kids content that inflates ratings
  const filtered = results.filter(r =>
    passesKidFilter(r.genre_ids, r.vote_count, r.vote_average)
  );

  return {
    results: filtered,
    page: data.page,
    total_pages: Math.min(data.total_pages, 500),
    total_results: data.total_results,
  };
}

/**
 * Fetch from TMDB Discover endpoint (movies or TV)
 */
async function fetchDiscover(
  type: 'movie' | 'tv',
  page: number,
  genreId: number | null,
  badMovies: boolean,
  freeOnly: boolean
): Promise<DiscoverResponse> {
  // For genre tabs: sort by quality (vote_average) with a vote floor so we
  // surface great catalog films, not just whatever's in theaters this week.
  // For trending (genreId=null, !badMovies): keep popularity for recency.
  const defaultSort = genreId ? 'vote_average.desc' : 'popularity.desc';

  const params = new URLSearchParams({
    api_key: API_KEY,
    language: 'en-US',
    watch_region: 'US',
    page: String(page),
    sort_by: badMovies ? 'vote_average.asc' : defaultSort,
    include_adult: 'false',
  });

  if (genreId && genreId > 0) {
    params.set('with_genres', String(genreId));
    // Quality floor: enough votes to be credible, high enough rating to be worth watching
    params.set('vote_count.gte', '150');
    params.set('vote_average.gte', '6.0');
  }

  if (badMovies) {
    params.set('vote_average.lte', '4.5');
    params.set('vote_count.gte', '50');     // enough votes to be "known bad"
    params.set('sort_by', 'vote_count.desc'); // popular bad movies first
  }

  if (freeOnly) {
    params.set('with_watch_monetization_types', 'free|ads');
    params.set('with_watch_providers', FREE_PROVIDER_IDS);
  }

  // Ensure we get things with posters
  params.set('with_poster', 'true');

  const url = `${TMDB_BASE}/discover/${type}?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Discover fetch failed: ${res.status}`);
  const data = await res.json();

  const results: DiscoverItem[] = data.results.map((r: any) => ({
    id: r.id,
    title: r.title || r.name || '',
    poster_path: r.poster_path,
    backdrop_path: r.backdrop_path,
    media_type: type,
    year: r.release_date
      ? parseInt(r.release_date.substring(0, 4))
      : r.first_air_date
        ? parseInt(r.first_air_date.substring(0, 4))
        : null,
    vote_average: r.vote_average || 0,
    vote_count: r.vote_count || 0,
    overview: r.overview || '',
    genre_ids: r.genre_ids || [],
  }));

  return {
    results: results
      .filter(r => r.poster_path)
      .filter(r => passesKidFilter(r.genre_ids, r.vote_count, r.vote_average)),
    page: data.page,
    total_pages: Math.min(data.total_pages, 500),
    total_results: data.total_results,
  };
}

// ── Curated feed helpers for the homepage rows ──

/** Pick a random element from an array */
function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

// ── Curated TMDB list integration ──
// Hand-picked TMDB list IDs from well-known curators: Letterboxd popular,
// critics' annual best-of, essential viewing, and niche gems. Each load
// picks one list at random so the feed stays fresh without repeating.
const CURATED_LIST_IDS = [
  { id: 10, name: 'Top 250', subtitle: 'The consensus canon' },
  { id: 28, name: 'Best Films of the 2020s', subtitle: 'This decade\'s defining cinema' },
  { id: 138, name: 'Cult Classics', subtitle: 'Films that found their tribe' },
  { id: 4480, name: 'Oscar Winners', subtitle: 'Best Picture — the full list' },
  { id: 522, name: 'A24 Films', subtitle: 'The studio that defined indie' },
  { id: 7104730, name: 'Criterion Collection', subtitle: 'Curated for serious film lovers' },
  { id: 7108693, name: 'Sight & Sound 250', subtitle: 'What critics consider the greatest' },
];

// Track which lists were recently shown to avoid repeats across sessions
const CURATED_SHOWN_KEY = 'seenit_curated_shown';
const CURATED_SHOWN_MAX = 5; // remember last 5 shown lists

function pickCuratedList(): typeof CURATED_LIST_IDS[0] {
  let recentIds: number[] = [];
  try {
    const raw = localStorage.getItem(CURATED_SHOWN_KEY);
    if (raw) recentIds = JSON.parse(raw);
  } catch { /* ignore */ }

  // Prefer lists not recently shown
  const fresh = CURATED_LIST_IDS.filter(l => !recentIds.includes(l.id));
  const picked = fresh.length > 0 ? pickRandom(fresh) : pickRandom(CURATED_LIST_IDS);

  // Update shown tracker
  recentIds.unshift(picked.id);
  if (recentIds.length > CURATED_SHOWN_MAX) recentIds = recentIds.slice(0, CURATED_SHOWN_MAX);
  try { localStorage.setItem(CURATED_SHOWN_KEY, JSON.stringify(recentIds)); } catch { /* ignore */ }

  return picked;
}

/**
 * Fetch items from a TMDB list. Returns DiscoverItems from a random page
 * of the list for variety. Falls back gracefully on failure.
 */
async function fetchCuratedList(listId: number, limit = 12): Promise<DiscoverItem[]> {
  try {
    // Random page for variety within larger lists
    const page = 1 + Math.floor(Math.random() * 5);
    const url = `${TMDB_BASE}/list/${listId}?api_key=${API_KEY}&language=en-US&page=${page}`;
    const res = await fetch(url);
    if (!res.ok) return [];
    const data = await res.json();

    const items: DiscoverItem[] = (data.items || [])
      .filter((r: any) => r.poster_path)
      .map((r: any): DiscoverItem => ({
        id: r.id,
        title: r.title || r.name || '',
        poster_path: r.poster_path,
        backdrop_path: r.backdrop_path,
        media_type: r.media_type || 'movie',
        year: r.release_date
          ? parseInt(r.release_date.substring(0, 4))
          : r.first_air_date
            ? parseInt(r.first_air_date.substring(0, 4))
            : null,
        vote_average: r.vote_average || 0,
        vote_count: r.vote_count || 0,
        overview: r.overview || '',
        genre_ids: r.genre_ids || [],
      }))
      .filter((r: DiscoverItem) => passesKidFilter(r.genre_ids, r.vote_count, r.vote_average));

    // Shuffle and limit
    return items.sort(() => Math.random() - 0.5).slice(0, limit);
  } catch {
    return [];
  }
}

export interface CuratedRow {
  id: string;
  title: string;
  subtitle: string;
  reasonTaste: string;  // why this aligns with their viewing history
  reasonMood: string;   // why this feels right for them *right now*
  items: DiscoverItem[];
}

const DECADES = [
  { label: '60s', start: '1960-01-01', end: '1969-12-31' },
  { label: '70s', start: '1970-01-01', end: '1979-12-31' },
  { label: '80s', start: '1980-01-01', end: '1989-12-31' },
  { label: '90s', start: '1990-01-01', end: '1999-12-31' },
  { label: '2000s', start: '2000-01-01', end: '2009-12-31' },
  { label: '2010s', start: '2010-01-01', end: '2019-12-31' },
];

const SPOTLIGHT_GENRES = [
  { id: 99, name: 'Documentary' },
  { id: 878, name: 'Sci-Fi' },
  { id: 27, name: 'Horror' },
  { id: 80, name: 'Crime' },
  { id: 10752, name: 'War' },
  { id: 36, name: 'History' },
  { id: 16, name: 'Animation' },
  { id: 37, name: 'Western' },
  { id: 9648, name: 'Mystery' },
  { id: 14, name: 'Fantasy' },
  { id: 10749, name: 'Romance' },
  { id: 53, name: 'Thriller' },
];

/** Language codes for "world cinema" row — non-English standouts */
const WORLD_LANGUAGES = ['ko', 'ja', 'fr', 'es', 'de', 'it', 'pt', 'zh', 'hi', 'sv', 'da', 'pl', 'tr', 'th'];

/**
 * Fetch a single curated discover row
 */
async function fetchCuratedRow(
  sortBy: string,
  extraParams: Record<string, string>,
  limit = 12,
): Promise<DiscoverItem[]> {
  // Randomise across pages 1-10 for deep variety — never the same feed twice
  const page = 1 + Math.floor(Math.random() * 10);

  const params = new URLSearchParams({
    api_key: API_KEY,
    language: 'en-US',
    watch_region: 'US',
    page: String(page),
    sort_by: sortBy,
    include_adult: 'false',
    with_poster: 'true',
    ...extraParams,
  });

  const url = `${TMDB_BASE}/discover/movie?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) return [];
  const data = await res.json();

  const items = (data.results || [])
    .filter((r: any) => r.poster_path)
    .map((r: any): DiscoverItem => ({
      id: r.id,
      title: r.title || r.name || '',
      poster_path: r.poster_path,
      backdrop_path: r.backdrop_path,
      media_type: 'movie',
      year: r.release_date ? parseInt(r.release_date.substring(0, 4)) : null,
      vote_average: r.vote_average || 0,
      vote_count: r.vote_count || 0,
      overview: r.overview || '',
      genre_ids: r.genre_ids || [],
    }))
    // Smart kids/family filter — keeps genuinely great films (Ghibli, Pixar best),
    // filters out narrow-audience kids content that inflates ratings
    .filter(r => passesKidFilter(r.genre_ids, r.vote_count, r.vote_average))
    .slice(0, limit);

  // Shuffle results within the row for extra unpredictability
  return items.sort(() => Math.random() - 0.5);
}

/**
 * Build the full curated homepage feed.
 * Returns up to 9 themed rows, each with ~12 posters.
 * Randomises decade, genre, language, and genre-mash combos each load
 * so it never feels stale. Rows are shuffled (first row pinned).
 */
export interface VibeClusterInput {
  label: string;
  subtitle: string;
  keywordIds: number[];
}

export interface ViewerAffinities {
  topGenres?: number[];   // genre IDs the viewer taps most
  topDecade?: string;     // e.g. "80s"
  vibes?: VibeClusterInput[];  // personal keyword clusters to surface
}

export interface MoodInput {
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'latenight';
  dayName: string;
  isWeekend: boolean;
  recentTone: 'heavy' | 'light' | 'intense' | 'mixed' | 'unknown';
  hasHistory: boolean;
}

export async function getCuratedFeed(affinities?: ViewerAffinities, mood?: MoodInput): Promise<CuratedRow[]> {
  const hasAffinities = affinities && (affinities.topGenres?.length || affinities.topDecade);

  // When we know the viewer: one slot is their favourite genre, one is a
  // surprise genre they haven't explored. The decade leans toward theirs
  // but the rest stays random. The feed should feel like a friend who knows
  // you picked it — not an algorithm narrowing your world.
  let decade: typeof DECADES[number];
  let genre: typeof SPOTLIGHT_GENRES[number];
  let genreIsPersonal = false;
  let decadeIsPersonal = false;

  if (hasAffinities && affinities?.topDecade) {
    const match = DECADES.find(d => d.label === affinities.topDecade);
    // 60% lean toward their decade, 40% surprise — familiar enough to trust, wild enough to grow
    decade = match && Math.random() < 0.6 ? match : pickRandom(DECADES);
    decadeIsPersonal = decade === match;
  } else {
    decade = pickRandom(DECADES);
  }

  if (hasAffinities && affinities?.topGenres?.length) {
    const match = SPOTLIGHT_GENRES.find(g => affinities.topGenres!.includes(g.id));
    // 60% lean toward a genre they love, 40% surprise
    genre = match && Math.random() < 0.6 ? match : pickRandom(SPOTLIGHT_GENRES);
    genreIsPersonal = genre === match;
  } else {
    genre = pickRandom(SPOTLIGHT_GENRES);
  }

  const worldLang = pickRandom(WORLD_LANGUAGES);

  // Second genre for mash: must be from a different thematic family than genre.
  // Group similar genres so we never get "Western Essentials" + "Western × Animation".
  const GENRE_FAMILIES: Record<number, string> = {
    27: 'tension', 53: 'tension', 9648: 'tension',   // horror, thriller, mystery
    878: 'speculative', 14: 'speculative',             // sci-fi, fantasy
    80: 'crime', 10752: 'conflict', 36: 'history',
    99: 'nonfiction', 16: 'animation',
    37: 'western', 10749: 'romance',
  };
  const genreFamily = GENRE_FAMILIES[genre.id];
  const genre2candidates = SPOTLIGHT_GENRES.filter(g =>
    g.id !== genre.id && GENRE_FAMILIES[g.id] !== genreFamily
  );
  const unexplored = hasAffinities && affinities?.topGenres?.length
    ? genre2candidates.filter(g => !affinities.topGenres!.includes(g.id))
    : genre2candidates;
  const genre2 = unexplored.length > 0 ? pickRandom(unexplored) : pickRandom(genre2candidates.length > 0 ? genre2candidates : SPOTLIGHT_GENRES.filter(g => g.id !== genre.id));

  // Build a "Viewers Like You" query from top genres — but keep it loose.
  // Use only 1-2 genres (not 3) to avoid over-narrowing, and 30% of the time
  // go fully random so the feed always has surprises.
  let tasteGenres: string | null = null;
  if (hasAffinities && affinities?.topGenres?.length && Math.random() > 0.3) {
    // Use 1 or 2 genres, randomly chosen from their top 5
    const shuffledTaste = [...affinities.topGenres].sort(() => Math.random() - 0.5);
    tasteGenres = shuffledTaste.slice(0, 1 + Math.floor(Math.random() * 2)).join(',');
  }

  // Personal vibes — keyword clusters that reflect the viewer's specific world
  const vibes = affinities?.vibes || [];

  // Pick a curated TMDB list for this load (rotates, avoids recent repeats)
  const curatedList = pickCuratedList();

  // ── Enhanced category discovery ──
  // TMDB keyword IDs for targeted categories
  // Festival favorites: Cannes (3601), Sundance (2467), Venice (7484), Berlin (4069), TIFF (11476)
  // Classic cinema: film noir (1564), criterion collection (179431), new hollywood (155477)
  // Queer/camp/adult: lgbt (158718), drag (264384), camp (155493), bdsm (158713)
  // Horror deep: folk horror (261178), body horror (224636), cosmic horror (316173), giallo (163053)
  const FESTIVAL_KEYWORDS = '3601|2467|7484|4069|11476';
  const CLASSIC_KEYWORDS = '1564|179431|155477|10683'; // noir + criterion + new hollywood + golden age
  const HORROR_DEEP_KEYWORDS = '261178|224636|316173|163053|6152'; // folk, body, cosmic, giallo, slasher

  // Pick one enhanced category per load to keep feed fresh (rotate 2 of 5)
  const enhancedCategories = [
    { id: 'festival', label: 'Festival Circuit', subtitle: 'Cannes, Sundance, Venice — the films that made the festivals', kw: FESTIVAL_KEYWORDS },
    { id: 'critics', label: 'Critics\' Obsessions', subtitle: 'The films critics won\'t shut up about', kw: null },
    { id: 'classic', label: 'Classic Cinema', subtitle: 'Noir, New Hollywood, golden age — the canon and the forgotten', kw: CLASSIC_KEYWORDS },
    { id: 'queer-deep', label: 'Queer Deep Cuts', subtitle: 'Beyond the obvious — the films that found their audience', kw: '158718|264384|155493|158713|300642' },
    { id: 'horror-deep', label: 'Horror Rabbit Hole', subtitle: 'Folk horror, body horror, giallo — the dark corners', kw: HORROR_DEEP_KEYWORDS },
  ];
  // Shuffle and pick 2
  const shuffledCats = [...enhancedCategories].sort(() => Math.random() - 0.5);
  const pickedCats = shuffledCats.slice(0, 2);

  const results = await Promise.allSettled([
    // Viewers Like You — uses actual taste profile, or falls back to acclaimed-but-overlooked
    tasteGenres
      ? fetchCuratedRow('vote_average.desc', {
          with_genres: tasteGenres,
          'vote_count.gte': '50',
          'vote_count.lte': '1500',
          'vote_average.gte': '7.0',
        })
      : fetchCuratedRow('vote_average.desc', {
          'vote_count.gte': '300',
          'vote_count.lte': '2000',
          'vote_average.gte': '7.5',
        }),
    // Hidden Gems — good films with a real audience but not blockbusters.
    // Higher vote floor than before to filter out manipulated-rating DTV.
    fetchCuratedRow('vote_average.desc', {
      'vote_count.gte': '100',
      'vote_count.lte': '1000',
      'vote_average.gte': '7.0',
      without_genres: '10402,10770',  // exclude Music, TV movies
    }),
    // Decade Classics
    fetchCuratedRow('vote_average.desc', {
      'primary_release_date.gte': decade.start,
      'primary_release_date.lte': decade.end,
      'vote_count.gte': '200',
      'vote_average.gte': '6.8',
    }),
    // Genre Essentials — wider net
    fetchCuratedRow('vote_average.desc', {
      with_genres: String(genre.id),
      'vote_count.gte': '200',
      'vote_average.gte': '6.8',
    }),
    // Recent Critical Darlings — last 3 years
    fetchCuratedRow('vote_average.desc', {
      'primary_release_date.gte': `${new Date().getFullYear() - 3}-01-01`,
      'vote_count.gte': '200',
      'vote_average.gte': '7.0',
    }),
    // World Cinema — non-English standouts that English-speaking critics actually
    // reviewed. High vote floor filters out DTV, stand-up, cheap animation, and
    // ratings-manipulated obscurities. Excluding Music (concert films), TV Movie,
    // and Documentary (stand-up specials often tagged as documentary).
    fetchCuratedRow('vote_average.desc', {
      with_original_language: worldLang,
      'vote_count.gte': '500',
      'vote_average.gte': '7.2',
      without_genres: '10402,10770,99',  // no music, TV movies, documentaries (stand-up)
    }),
    // Deep Cuts — excellent but under-known. English-language only to avoid the
    // flood of obscure foreign DTV that games low-vote-count rating thresholds.
    // The World Cinema row handles non-English properly with its own quality gates.
    fetchCuratedRow('vote_average.desc', {
      'vote_count.gte': '50',
      'vote_count.lte': '500',
      'vote_average.gte': '7.5',
      with_original_language: 'en',
      without_genres: '10402,10770',  // no music films or TV movies
    }),
    // Genre Mash — two genres combined for unexpected discoveries
    fetchCuratedRow('vote_average.desc', {
      with_genres: `${genre.id},${genre2.id}`,
      'vote_count.gte': '100',
      'vote_average.gte': '6.5',
    }),
    // Wild Card — completely ignores taste data, pure surprise from a random
    // corner of cinema. The goal: expand the world, not reinforce it.
    // Every strategy requires enough votes to prove real audience engagement.
    (() => {
      const wildGenre = pickRandom(SPOTLIGHT_GENRES);
      const wildDecade = pickRandom(DECADES);
      const strategy = Math.floor(Math.random() * 3);
      if (strategy === 0) {
        // Random genre from random decade — well-known enough to be interesting
        return fetchCuratedRow('vote_average.desc', {
          with_genres: String(wildGenre.id),
          'primary_release_date.gte': wildDecade.start,
          'primary_release_date.lte': wildDecade.end,
          'vote_count.gte': '200',
          'vote_average.gte': '6.5',
        });
      } else if (strategy === 1) {
        // Recently popular but NOT in their taste genres — genuine diversity
        const avoidGenres = hasAffinities && affinities?.topGenres?.length
          ? affinities.topGenres.join(',')
          : '';
        return fetchCuratedRow('popularity.desc', {
          ...(avoidGenres ? { without_genres: avoidGenres } : {}),
          'vote_count.gte': '200',
          'vote_average.gte': '6.0',
          without_genres: '10402,10770',
        });
      } else {
        // Acclaimed but off the beaten path — medium-vote, high-quality
        return fetchCuratedRow('vote_average.desc', {
          'vote_count.gte': '150',
          'vote_count.lte': '800',
          'vote_average.gte': '7.5',
          without_genres: '10402,10770',
        });
      }
    })(),
    // ── Enhanced category rows (2 of 5 per load) ──
    ...pickedCats.map(cat =>
      cat.id === 'critics'
        // Critics' Obsessions: high Metacritic proxy — very high TMDB rating + moderate votes
        ? fetchCuratedRow('vote_average.desc', {
            'vote_count.gte': '100',
            'vote_count.lte': '800',
            'vote_average.gte': '7.8',
            'primary_release_date.gte': `${new Date().getFullYear() - 5}-01-01`,
            without_genres: '10402,10770',  // no music, TV movies (animation kept — many adult animations)
          })
        : fetchCuratedRow('vote_average.desc', {
            with_keywords: cat.kw!,
            'vote_count.gte': cat.id === 'queer-deep' || cat.id === 'horror-deep' ? '15' : '30',
            'vote_average.gte': '6.5',
          })
    ),
    // Personal vibe keyword rows — each cluster fetched separately
    ...vibes.map(vibe =>
      fetchCuratedRow('vote_average.desc', {
        with_keywords: vibe.keywordIds.join('|'),
        'vote_count.gte': '10',
      })
    ),
    // Curated TMDB list — anchors quality with real human curation
    fetchCuratedList(curatedList.id),
  ]);

  // Unwrap settled results — failed fetches become empty arrays instead of crashing the feed
  const unwrap = (r: PromiseSettledResult<DiscoverItem[]>): DiscoverItem[] =>
    r.status === 'fulfilled' ? r.value : [];
  const allResults = results.map(unwrap);
  const [certified, hidden, decadeRow, genreRow, recentCritical, worldCinema, deepCuts, genreMash, wildCard] =
    allResults.slice(0, 9);
  const enhancedResults = allResults.slice(9, 9 + pickedCats.length);
  const vibeResults = allResults.slice(9 + pickedCats.length, 9 + pickedCats.length + vibes.length);
  const curatedListItems = allResults[9 + pickedCats.length + vibes.length] || [];

  const langNames: Record<string, string> = {
    ko: 'Korean', ja: 'Japanese', fr: 'French', es: 'Spanish',
    de: 'German', it: 'Italian', pt: 'Portuguese', zh: 'Chinese',
    hi: 'Hindi', sv: 'Swedish', da: 'Danish', pl: 'Polish',
    tr: 'Turkish', th: 'Thai',
  };

  // ── Build mood-aware reason text ──
  // "reasonTaste" = why this matches their viewing identity
  // "reasonMood"  = why this feels right for who they are *tonight*
  const t = mood?.timeOfDay || 'evening';
  const tone = mood?.recentTone || 'unknown';
  const dayN = mood?.dayName || '';
  const wknd = mood?.isWeekend ?? false;
  const knows = mood?.hasHistory ?? false;

  // Helper: a gentle time-aware line
  function timeFeel(evening: string, late: string, afternoon: string, fallback: string): string {
    if (t === 'latenight') return late;
    if (t === 'evening') return evening;
    if (t === 'afternoon') return afternoon;
    return fallback;
  }

  // Helper: reads the viewer's recent emotional trajectory
  function toneAware(
    afterHeavy: string,
    afterIntense: string,
    afterLight: string,
    neutral: string,
  ): string {
    if (!knows) return neutral;
    if (tone === 'heavy') return afterHeavy;
    if (tone === 'intense') return afterIntense;
    if (tone === 'light') return afterLight;
    return neutral;
  }

  const pool: CuratedRow[] = [];

  if (recentCritical.length > 0) {
    pool.push({
      id: 'recent-critical',
      title: 'Recent Critical Darlings',
      subtitle: 'The films critics can\'t stop talking about',
      reasonTaste: 'New and acclaimed',
      reasonMood: timeFeel(
        'Something fresh for tonight',
        'Still buzzing from this year',
        'Catch up on what everyone\'s talking about',
        'The best of right now',
      ),
      items: recentCritical,
    });
  }
  if (certified.length > 0) {
    pool.push({
      id: 'for-you',
      title: tasteGenres ? 'Picked for You' : 'Acclaimed & Overlooked',
      subtitle: tasteGenres
        ? 'Based on everything you\'ve been watching'
        : 'Great films that slipped through the cracks',
      reasonTaste: tasteGenres
        ? 'Matched to your actual taste profile'
        : 'Acclaimed but not obvious',
      reasonMood: tasteGenres
        ? toneAware(
            'Something that gets you — after a heavy stretch',
            'Tuned to your wavelength',
            'More of the energy you\'ve been chasing',
            'Films that feel like they were chosen for you',
          )
        : timeFeel(
            'A film worth discovering tonight',
            'The ones that reward late-night attention',
            'Something you haven\'t heard of — yet',
            'Quietly brilliant',
          ),
      items: certified,
    });
  }
  if (hidden.length > 0) {
    pool.push({
      id: 'hidden',
      title: 'Hidden Gems',
      subtitle: 'Films most people haven\'t found yet',
      reasonTaste: 'Almost nobody knows these',
      reasonMood: timeFeel(
        'Perfect for a quiet night — discover something new',
        'A rabbit hole for the night owl in you',
        wknd ? 'A lazy weekend find' : 'Something to look forward to tonight',
        'For the curious',
      ),
      items: hidden,
    });
  }
  if (decadeRow.length > 0) {
    pool.push({
      id: 'decade',
      title: `Best of the ${decade.label}`,
      subtitle: decadeIsPersonal
        ? `We noticed you love the ${decade.label}`
        : `A time capsule of the decade's best`,
      reasonTaste: decadeIsPersonal
        ? `You keep gravitating toward the ${decade.label}`
        : `Great films from the ${decade.label}`,
      reasonMood: decadeIsPersonal
        ? timeFeel(
            `A ${decade.label} film feels right tonight`,
            `Late-night ${decade.label} — your comfort zone`,
            `Revisit the ${decade.label} this ${dayN}`,
            `Back to the ${decade.label}`,
          )
        : timeFeel(
            `Travel back to the ${decade.label} tonight`,
            `The ${decade.label} hit different late at night`,
            `Time-travel for a ${dayN} afternoon`,
            `A different era, a different feel`,
          ),
      items: decadeRow,
    });
  }
  if (genreRow.length > 0) {
    const gn = genre.name.toLowerCase();
    pool.push({
      id: 'genre',
      title: genreIsPersonal ? `More ${genre.name}` : `${genre.name} Essentials`,
      subtitle: genreIsPersonal
        ? `Because you keep coming back to ${gn}`
        : 'The definitive collection',
      reasonTaste: genreIsPersonal
        ? `You love ${gn}`
        : `Exploring ${gn}`,
      reasonMood: genreIsPersonal
        ? toneAware(
            `You\'ve been in a heavy place — ${gn} might be the shift you need`,
            `After all that intensity, more ${gn} could hit right`,
            `You\'re in a ${gn} mood — lean into it`,
            `More of what you love`,
          )
        : timeFeel(
            `A ${gn} night`,
            `Late-night ${gn}`,
            `${genre.name} for a ${dayN}`,
            `Try some ${gn}`,
          ),
      items: genreRow,
    });
  }
  if (worldCinema.length > 0) {
    const ln = langNames[worldLang] || 'world';
    pool.push({
      id: 'world',
      title: `${langNames[worldLang] || 'World'} Cinema`,
      subtitle: 'Subtitles on, phones down',
      reasonTaste: `Something different — ${ln} storytelling`,
      reasonMood: toneAware(
        `After all that drama, a change of perspective`,
        `Step outside the familiar for a bit`,
        `Keep exploring — ${ln} cinema has range`,
        timeFeel(
          `Give your evening to a ${ln} film`,
          `The world looks different after midnight`,
          `A ${dayN} afternoon trip — no passport needed`,
          `Broaden the view`,
        ),
      ),
      items: worldCinema,
    });
  }
  if (deepCuts.length > 0) {
    pool.push({
      id: 'deep-cuts',
      title: 'Deep Cuts',
      subtitle: 'Films only cinephiles know',
      reasonTaste: 'The rabbit hole',
      reasonMood: timeFeel(
        'The kind of film you tell people about tomorrow',
        'Deep cuts hit hardest late at night',
        wknd ? 'Weekend discovery mode' : 'Save one for tonight',
        'For when you want to find something nobody else has seen',
      ),
      items: deepCuts,
    });
  }
  if (genreMash.length > 0) {
    pool.push({
      id: 'genre-mash',
      title: `${genre.name} × ${genre2.name}`,
      subtitle: 'When two worlds collide',
      reasonTaste: `What happens when ${genre.name.toLowerCase()} meets ${genre2.name.toLowerCase()}`,
      reasonMood: timeFeel(
        'Something you wouldn\'t think to search for',
        'The weird stuff finds you late at night',
        'Feeling adventurous?',
        'Trust the unexpected',
      ),
      items: genreMash,
    });
  }

  // Wild Card — pure surprise, ignores taste entirely
  if (wildCard.length > 0) {
    pool.push({
      id: 'wild-card',
      title: 'Wild Card',
      subtitle: 'Something you\'d never search for yourself',
      reasonTaste: 'No algorithm — just chance',
      reasonMood: timeFeel(
        'Let the universe pick tonight\'s movie',
        'The best late-night finds are the ones you never expected',
        wknd ? 'Weekend energy: trust the random' : 'Midweek wildcard',
        'Expand the map',
      ),
      items: wildCard,
    });
  }

  // Enhanced category rows — critics' choices, festival, classic cinema, queer deep, horror deep
  pickedCats.forEach((cat, i) => {
    const items = enhancedResults[i] || [];
    if (items.length > 0) {
      pool.push({
        id: `enhanced-${cat.id}`,
        title: cat.label,
        subtitle: cat.subtitle,
        reasonTaste: cat.id === 'queer-deep' ? 'Part of who you are'
          : cat.id === 'horror-deep' ? 'For the brave'
          : cat.id === 'festival' ? 'Award-season credibility'
          : cat.id === 'classic' ? 'The history of the medium'
          : 'What the critics see that audiences miss',
        reasonMood: timeFeel(
          cat.id === 'horror-deep' ? 'Horror hits different after dark'
            : `A ${cat.label.toLowerCase()} night`,
          cat.id === 'horror-deep' ? 'The darkest hour — perfect for this'
            : `Late-night ${cat.label.toLowerCase()}`,
          `${cat.label} for a ${dayN}`,
          cat.subtitle,
        ),
        items,
      });
    }
  });

  // Personal vibe rows — keyword-based discovery from the viewer's specific world
  vibes.forEach((vibe, i) => {
    const items = vibeResults[i] || [];
    if (items.length > 0) {
      pool.push({
        id: `vibe-${i}`,
        title: vibe.label,
        subtitle: vibe.subtitle,
        reasonTaste: `Part of who you are`,
        reasonMood: timeFeel(
          `A ${vibe.label.toLowerCase()} night`,
          `Late-night ${vibe.label.toLowerCase()}`,
          `${vibe.label} for a ${dayN}`,
          vibe.subtitle,
        ),
        items,
      });
    }
  });

  // Curated list row — quality-anchored by real human curation
  if (curatedListItems.length > 0) {
    pool.push({
      id: `curated-${curatedList.id}`,
      title: curatedList.name,
      subtitle: curatedList.subtitle,
      reasonTaste: 'Curated by humans, not algorithms',
      reasonMood: timeFeel(
        'Something from a list worth trusting',
        'Late-night list diving',
        'Browse a curated collection',
        curatedList.subtitle,
      ),
      items: curatedListItems,
    });
  }

  // Deduplicate across rows — a title should only appear in its first row
  const seen = new Set<number>();
  for (const row of pool) {
    row.items = row.items.filter((item) => {
      if (seen.has(item.id)) return false;
      seen.add(item.id);
      return true;
    });
  }

  // ── Row ordering: quality-anchored rows first, exploration rows later ──
  // Split the pool into tiers so the top of the feed is strong and the
  // discovery/deep-cut rows don't dominate.
  const qualityIds = new Set(['recent-critical', 'for-you', 'genre', 'decade', 'world']);
  const explorationIds = new Set(['hidden', 'deep-cuts', 'wild-card', 'genre-mash']);

  const tierQuality = pool.filter(r => qualityIds.has(r.id));
  const tierCurated = pool.filter(r => r.id.startsWith('curated-') || r.id.startsWith('enhanced-'));
  const tierPersonal = pool.filter(r => r.id.startsWith('vibe-'));
  const tierExploration = pool.filter(r => explorationIds.has(r.id));

  // Shuffle within each tier
  const shuffle = <T,>(arr: T[]): T[] => {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  };

  // Recent Critical Darlings always first (if present), then quality, then
  // curated lists, then personal vibes, then exploration. Within each tier
  // the order is shuffled for variety.
  const pinned = pool.filter(r => r.id === 'recent-critical');
  const qualityRest = shuffle(tierQuality.filter(r => r.id !== 'recent-critical'));
  const curatedShuffled = shuffle(tierCurated);
  const personalShuffled = shuffle(tierPersonal);
  const explorationShuffled = shuffle(tierExploration);

  // Cap exploration rows to 2 max — David's feedback: deep cuts are great,
  // but not half the homepage
  const explorationCapped = explorationShuffled.slice(0, 2);

  return [
    ...pinned,
    ...qualityRest,
    ...curatedShuffled,
    ...personalShuffled,
    ...explorationCapped,
  ];
}

/**
 * Keyword-based discover — lets users type unusual terms and find matching films
 */
export async function discoverByKeyword(
  keywordIds: number[],
  page = 1,
): Promise<DiscoverResponse> {
  if (keywordIds.length === 0) return { results: [], page: 1, total_pages: 0, total_results: 0 };

  const params = new URLSearchParams({
    api_key: API_KEY,
    language: 'en-US',
    watch_region: 'US',
    page: String(page),
    sort_by: 'vote_average.desc',
    include_adult: 'false',
    with_poster: 'true',
    with_keywords: keywordIds.join('|'),
    'vote_count.gte': '30',
  });

  const url = `${TMDB_BASE}/discover/movie?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) return { results: [], page: 1, total_pages: 0, total_results: 0 };
  const data = await res.json();

  const results: DiscoverItem[] = (data.results || [])
    .filter((r: any) => r.poster_path)
    .map((r: any): DiscoverItem => ({
      id: r.id,
      title: r.title || r.name || '',
      poster_path: r.poster_path,
      backdrop_path: r.backdrop_path,
      media_type: 'movie',
      year: r.release_date ? parseInt(r.release_date.substring(0, 4)) : null,
      vote_average: r.vote_average || 0,
      vote_count: r.vote_count || 0,
      overview: r.overview || '',
      genre_ids: r.genre_ids || [],
    }));

  return {
    results,
    page: data.page,
    total_pages: Math.min(data.total_pages || 0, 500),
    total_results: data.total_results || 0,
  };
}

/**
 * Main discover function — routes to trending or discover based on params
 */
export async function discoverContent(params: DiscoverParams): Promise<DiscoverResponse> {
  const { mediaType, genre, sourceFilter, page } = params;
  const freeOnly = sourceFilter === 'free';
  const isBadMovies = genre === -1;
  const isTrending = genre === 0;

  if (isTrending) {
    // On first page, occasionally pull from deeper pages (2-3) so it's
    // not always the same 20 theatrical releases dominating the view
    const effectivePage = page === 1 && Math.random() < 0.3
      ? 1 + Math.floor(Math.random() * 3)
      : page;
    return fetchTrending(mediaType === 'all' ? 'all' : mediaType, effectivePage);
  }

  // For "all" media type, fetch both and merge
  if (mediaType === 'all') {
    const [movies, tv] = await Promise.all([
      fetchDiscover('movie', page, isBadMovies ? null : genre, isBadMovies, freeOnly),
      fetchDiscover('tv', page, isBadMovies ? null : genre, isBadMovies, freeOnly),
    ]);

    const merged = [...movies.results, ...tv.results]
      .sort((a, b) => {
        if (isBadMovies) return a.vote_average - b.vote_average;
        return b.vote_average - a.vote_average;
      })
      .slice(0, 20);

    return {
      results: merged,
      page,
      total_pages: Math.min(movies.total_pages, tv.total_pages, 500),
      total_results: movies.total_results + tv.total_results,
    };
  }

  return fetchDiscover(mediaType, page, isBadMovies ? null : genre, isBadMovies, freeOnly);
}
