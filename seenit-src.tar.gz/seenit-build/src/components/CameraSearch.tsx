/**
 * CameraSearch — point your phone at the TV, identify what's playing.
 *
 * Flow:
 *  1. Opens rear camera in a live viewfinder
 *  2. User taps capture
 *  3. Client-side OCR extracts text from the frame (Tesseract.js)
 *  4. Extracted text searches TMDB
 *  5. Results displayed inline
 *
 * Falls back to file picker on desktop or if camera permission denied.
 */
import { useState, useRef, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createWorker, type Worker as TessWorker } from 'tesseract.js';

type CameraState = 'idle' | 'streaming' | 'capturing' | 'processing' | 'error';

export default function CameraSearch() {
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const workerRef = useRef<TessWorker | null>(null);

  const [state, setState] = useState<CameraState>('idle');
  const [extractedText, setExtractedText] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Start the rear camera
  const startCamera = useCallback(async () => {
    try {
      setState('streaming');
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err: any) {
      console.warn('[Camera] Failed:', err);
      setState('error');
      setErrorMsg(err.name === 'NotAllowedError'
        ? 'Camera access denied. Check your browser permissions.'
        : 'Camera not available on this device.');
    }
  }, []);

  // Stop the camera
  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
      workerRef.current?.terminate();
    };
  }, [stopCamera]);

  // Capture a frame and run OCR
  const captureAndRecognize = useCallback(async () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    setState('capturing');

    // Draw current video frame to canvas
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0);

    // Increase contrast for better OCR on TV screens
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const data = imageData.data;
    for (let i = 0; i < data.length; i += 4) {
      // Convert to grayscale
      const gray = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
      // Boost contrast
      const contrast = gray < 128 ? Math.max(0, gray * 0.6) : Math.min(255, gray * 1.3 + 30);
      data[i] = data[i + 1] = data[i + 2] = contrast;
    }
    ctx.putImageData(imageData, 0, 0);

    setState('processing');

    try {
      // Initialize Tesseract worker (reuse if already created)
      if (!workerRef.current) {
        workerRef.current = await createWorker('eng');
      }

      const { data: { text } } = await workerRef.current.recognize(canvas);

      // Clean up OCR output — filter noise, keep likely title text
      const cleaned = cleanOCRText(text);
      setExtractedText(cleaned);

      if (cleaned.length >= 2) {
        // Stop camera and navigate to search results
        stopCamera();
        navigate(`/lookup?q=${encodeURIComponent(cleaned)}`);
      } else {
        setState('streaming');
      }
    } catch (err) {
      console.error('[OCR] Failed:', err);
      setState('streaming');
    }
  }, [navigate, stopCamera]);

  // Handle file upload fallback (desktop or denied camera)
  const handleFileUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setState('processing');

    try {
      if (!workerRef.current) {
        workerRef.current = await createWorker('eng');
      }

      const { data: { text } } = await workerRef.current.recognize(file);
      const cleaned = cleanOCRText(text);
      setExtractedText(cleaned);

      if (cleaned.length >= 2) {
        navigate(`/lookup?q=${encodeURIComponent(cleaned)}`);
      } else {
        setState('idle');
      }
    } catch (err) {
      console.error('[OCR] File upload failed:', err);
      setState('idle');
    }
  }, [navigate]);

  return (
    <div>
      {/* Viewfinder */}
      <div style={{
        position: 'relative',
        width: '100%',
        aspectRatio: '4/3',
        borderRadius: 10,
        overflow: 'hidden',
        background: '#000',
        marginBottom: 12,
      }}>
        {state === 'idle' && (
          <div
            onClick={startCamera}
            style={{
              position: 'absolute', inset: 0,
              display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', gap: 10,
            }}
          >
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--text-secondary)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z" />
              <circle cx="12" cy="13" r="4" />
            </svg>
            <span style={{ color: 'var(--text-secondary)', fontSize: 13, fontWeight: 500 }}>
              Tap to scan your TV
            </span>
          </div>
        )}

        {state === 'error' && (
          <div style={{
            position: 'absolute', inset: 0,
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center',
            padding: 20, textAlign: 'center', gap: 10,
          }}>
            <span style={{ color: 'var(--text-secondary)', fontSize: 13 }}>{errorMsg}</span>
            <label style={{
              padding: '8px 16px', background: 'var(--accent)', color: '#fff',
              borderRadius: 6, fontSize: 13, fontWeight: 500, cursor: 'pointer',
            }}>
              Upload a photo instead
              <input type="file" accept="image/*" onChange={handleFileUpload} style={{ display: 'none' }} />
            </label>
          </div>
        )}

        <video
          ref={videoRef}
          playsInline
          muted
          style={{
            width: '100%', height: '100%', objectFit: 'cover',
            display: state === 'streaming' || state === 'capturing' ? 'block' : 'none',
          }}
        />

        {/* Scanning overlay corners */}
        {(state === 'streaming' || state === 'capturing') && (
          <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
            {/* Corner markers */}
            {[
              { top: 16, left: 16 },
              { top: 16, right: 16 },
              { bottom: 16, left: 16 },
              { bottom: 16, right: 16 },
            ].map((pos, i) => (
              <div key={i} style={{
                position: 'absolute', ...pos,
                width: 24, height: 24,
                borderColor: 'var(--accent)',
                borderStyle: 'solid',
                borderWidth: 0,
                ...(pos.top !== undefined && pos.left !== undefined ? { borderTopWidth: 2, borderLeftWidth: 2 } : {}),
                ...(pos.top !== undefined && pos.right !== undefined ? { borderTopWidth: 2, borderRightWidth: 2 } : {}),
                ...(pos.bottom !== undefined && pos.left !== undefined ? { borderBottomWidth: 2, borderLeftWidth: 2 } : {}),
                ...(pos.bottom !== undefined && pos.right !== undefined ? { borderBottomWidth: 2, borderRightWidth: 2 } : {}),
              }} />
            ))}
          </div>
        )}

        {/* Processing overlay */}
        {state === 'processing' && (
          <div style={{
            position: 'absolute', inset: 0,
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center',
            background: 'rgba(0,0,0,0.7)', gap: 10,
          }}>
            <div style={{
              width: 24, height: 24,
              border: '2px solid rgba(255,255,255,0.3)',
              borderTopColor: 'var(--accent)',
              borderRadius: '50%',
              animation: 'spin 0.6s linear infinite',
            }} />
            <span style={{ color: 'rgba(255,255,255,0.7)', fontSize: 12 }}>Reading screen...</span>
          </div>
        )}

        {/* Hidden canvas for frame capture */}
        <canvas ref={canvasRef} style={{ display: 'none' }} />
      </div>

      {/* Capture button */}
      {state === 'streaming' && (
        <button
          onClick={captureAndRecognize}
          style={{
            width: '100%', padding: 14,
            background: 'var(--accent)', color: '#fff',
            border: 'none', borderRadius: 8,
            fontSize: 14, fontWeight: 600,
            cursor: 'pointer', marginBottom: 12,
          }}
        >
          Capture
        </button>
      )}

      {/* Extracted text preview (for debugging / correction) */}
      {extractedText && state !== 'processing' && (
        <div style={{
          fontSize: 12, color: 'var(--text-secondary)',
          padding: '8px 10px', background: 'var(--bg-card)',
          borderRadius: 6, marginBottom: 12,
        }}>
          Read: "{extractedText}"
        </div>
      )}

      {/* File upload fallback — always available */}
      {state === 'idle' && (
        <label style={{
          display: 'block', textAlign: 'center',
          fontSize: 12, color: 'var(--text-secondary)',
          cursor: 'pointer', marginBottom: 8,
        }}>
          Or upload a screenshot
          <input type="file" accept="image/*" onChange={handleFileUpload} style={{ display: 'none' }} />
        </label>
      )}
    </div>
  );
}

/**
 * Clean up raw OCR output:
 * - Keep lines with 3+ alpha characters (filter noise)
 * - Take the longest / most title-like line
 * - Strip common UI text (Play, Resume, Watch Now, etc.)
 */
function cleanOCRText(raw: string): string {
  const UI_NOISE = /^(play|resume|watch now|add to|my list|more info|details|episodes?|season|trailer|new|coming soon|popular|trending|search|home|browse|categories|settings|ok|cancel|skip|continue|sign in|log in|menu|back|close|rating|rated|pg|pg-13|r|tv-ma|tv-14|tv-pg|tv-y|tv-g|cc|hd|4k|uhd|dolby|atmos|subtitle|audio|original|english|spanish|french|german|min|hrs?|hours?|minutes?|s\d+\s*e\d+)$/i;

  const lines = raw.split('\n')
    .map(l => l.trim())
    .filter(l => {
      // Must have 3+ alpha characters
      const alphaCount = (l.match(/[a-zA-Z]/g) || []).length;
      if (alphaCount < 3) return false;
      // Filter out UI noise
      if (UI_NOISE.test(l)) return false;
      // Filter very short or very long lines
      if (l.length < 3 || l.length > 60) return false;
      return true;
    })
    // Sort by length descending — longer lines more likely to be titles
    .sort((a, b) => b.length - a.length);

  // Return the longest clean line (most likely the title)
  return lines[0] || '';
}
