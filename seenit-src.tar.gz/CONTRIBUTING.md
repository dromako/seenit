# SeenIt Development Process

Internal reference for maintaining SeenIt across sessions. Follow this before every tarball upload.

## Session Workflow

### 1. Pre-work evaluation

Before writing code, audit the current state:

**Quality gate check** — Open the app or read `discover.ts:passesQualityGate()` and verify these DTV categories are filtered:

| Category | Pattern | Why it's DTV | What passes the bar |
|---|---|---|---|
| Kids/Family | Genre 10751, 10762 | Parents rate 10/10 for age-group, not quality | Ghibli, Pixar best, Fantastic Mr. Fox (high votes + high avg) |
| Faith-based | Text signals in title/overview | Congregations rate en masse | Silence, Passion of Joan of Arc (broad critical engagement) |
| Music/Concerts | Genre 10402 + text signals | Stans rate 10/10 for their artist | Stop Making Sense, Amadeus, Whiplash (high votes) |
| Reality TV / Vanity | Text signals | Built-in audience from the show | Paris Is Burning (acclaimed doc about the world) |
| Sports | Text signals | ESPN highlights ≠ cinema | Hoop Dreams, 30 for 30 best (works as a film) |
| Ultra-low-vote | vote_count < 20 | Trailers, shorts, student films, DTV slop | Anything with real distribution passes |

The universal test: **Would a serious cinephile with no prior attachment to the subject enjoy this as a *film experience*?**

**Hardcoded row check** — No row title should appear on every single load. Verify:
- Personal shelves emerge from engagement data (`getEngagementShelves`) — no hardcoded themes
- Patron shelves are dynamic (`pickActivePatrons`) — spawned from engagement clusters, not archetypes
- Max 2 engagement-derived genre shelves per load (prevents echo chamber)
- Always exactly 1 contrarian shelf (anti-over-training)
- Always 1 stranger patron (minimal genre overlap with viewer)
- No row label is a literal string constant that always renders

**Tag/badge audit** — The only badges should be: star rating (top-left), TV (top-right for shows), + (top-right for watchlisted), SEEN overlay. No "trailer" tags, no genre labels, no source badges.

### 2. Code changes

Follow existing patterns:
- Quality gate logic lives in `discover.ts:passesQualityGate()`
- Engagement shelves built in `storage.ts:getEngagementShelves()` — genre×decade×keyword clusters from engagement data
- Keyword engagement tracking in `storage.ts:recordKeywordEngagement()` / `getTopKeywords()`
- Dynamic patrons in `storage.ts` — `spawnPatron()`, `pickActivePatrons()`, `recordPatronEngagement()`
- Patron → TMDB query translation in `discover.ts:vectorToTMDBParams()`
- Row assembly lives in `discover.ts:getCuratedFeed()` — 6 personal + 4 patron, interleaved
- Visual personality in `shoplife.ts` — deterministic quirks on patron shelf items
- Cache TTLs: Trakt sets 30 min, library 7 days. Curated feed is NOT cached (fresh every load)
- All TMDB discover calls should include `without_genres: '10402,10770'` unless the row specifically targets Music or TV Movies

### 3. Pre-tarball cleanup checklist

Run every item before building `seenit-src.tar.gz`:

- [ ] `npx tsc --noEmit` — zero errors
- [ ] Search for dead exports: `grep -r "export.*function\|export.*const" src/lib/ | sort` — verify each is imported somewhere
- [ ] Search for hardcoded test data or debug logs: `grep -rn "console.log\|TODO\|FIXME\|HACK" src/ | grep -v node_modules`
- [ ] Verify no API keys in committed files (they're in `.env` via `import.meta.env`, not hardcoded)
- [ ] Check `without_genres` on all `fetchCuratedRow` calls — Music (10402) and TV Movie (10770) should be excluded from all general-purpose rows
- [ ] Verify `passesQualityGate` is called on ALL content paths: `fetchTrending`, `fetchDiscover`, `fetchCuratedRow`
- [ ] Review engagement shelves: max 2 genre shelves, 1 contrarian, labels generated not hardcoded
- [ ] Review patron selection: 3 affinity + 1 stranger, keyword scoring active

### 4. Build tarball

```bash
# From Ticket/ directory
tar czf seenit-src.tar.gz --exclude='node_modules' --exclude='.git' -C seenit-build .
```

Verify size is reasonable (should be ~150-200KB without node_modules).

### 5. Update handoff doc

Add a session section to `SeenIt_Handoff.md` with:
- Bug fixes (what broke, root cause, fix)
- Feature changes (what changed, why)
- Performance changes (what improved, by how much)
- Update the "What's Next" section
- Update the "Source Code" section with new tarball size and session number

### 6. Upload

Drag `seenit-src.tar.gz` to `github.com/dromako/seenit/upload/main` and commit. GitHub Actions will build and deploy.

## Content Philosophy Quick Reference

- **60% personal / 40% patron** — 6 personal shelves + 4 patron shelves, interleaved
- **No hardcoded themes** — every shelf label emerges from engagement data or patron TasteVectors
- **No over-training** — max 2 engagement genre shelves, 1 contrarian shelf, 1 stranger patron. Shop should never feel >60% "safe"
- **Keyword absorption** — patron mood keywords flow into viewer's keyword engagement pool via `recordPatronEngagement`, crystallizing into personal shelf parameters over time
- **Queer/kink/camp** — emerges organically through keyword engagement feedback loop; not guaranteed per load but persistent over time
- **Foreign content** — quality-gated by vote count, not blocked; modern bias (last 30 years) prevents only-Kurosawa syndrome
- **"Heavy" means slow/emotional/slow-burn** — NOT dark, horror, scary, weird, foreign, or upsetting
- **No filler rows** — every row must earn its spot; if it returns <3 items, don't render it
- **Visual personality** — patron shelf items show handwritten notes, dog-ears, staff picks, well-loved marks (~18% frequency). Shopkeeper asides appear between rows ~25% of the time. Never on personal shelves.
