/**
 * TMDB API Client
 * Handles movie and TV show data, details, and watch providers
 */

const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
// TMDB v4 Read Access Token — used as Bearer auth on all v3 + v4 endpoints
const TMDB_READ_ACCESS_TOKEN = 'eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI5ZTcwNDBkMWRiNGEwNzEzN2NhM2MyOWNmMDljZmQ4MSIsIm5iZiI6MTczMzAwMTQ2Mi40MjksInN1YiI6IjY3NGI4MGY2YmIxMTAwNzNlOGFiOTJmZCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.VL_RbC6VJumby1MNrTYOCGTHZjnY-5j7DRlTB4-GBgc';

interface TMDBSearchResult {
  id: number;
  title?: string;
  name?: string;
  poster_path: string | null;
  media_type?: string;
  release_date?: string;
  first_air_date?: string;
  vote_average?: number;
  overview?: string;
}

interface TMDBSearchResponse {
  results: TMDBSearchResult[];
  total_results: number;
  total_pages: number;
}

interface MovieDetails {
  id: number;
  title: string;
  poster_path: string | null;
  backdrop_path: string | null;
  release_date: string;
  runtime: number;
  overview: string;
  genres: Array<{ id: number; name: string }>;
  imdb_id: string;
  vote_average: number;
}

interface TVDetails {
  id: number;
  name: string;
  poster_path: string | null;
  backdrop_path: string | null;
  first_air_date: string;
  number_of_seasons: number;
  number_of_episodes: number;
  episode_run_time?: number[];
  overview: string;
  genres: Array<{ id: number; name: string }>;
  vote_average: number;
  external_ids?: { imdb_id?: string; tvdb_id?: number };
}

interface WatchProvider {
  provider_id: number;
  provider_name: string;
  logo_path: string | null;
}

interface WatchProviderData {
  results: {
    [key: string]: {
      link?: string;
      flatrate?: WatchProvider[];
      free?: WatchProvider[];
      ads?: WatchProvider[];
      buy?: WatchProvider[];
      rent?: WatchProvider[];
    };
  };
}

/**
 * Get TMDB API headers — Bearer auth works on all v3 and v4 endpoints
 */
function getTMDBHeaders(): HeadersInit {
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${TMDB_READ_ACCESS_TOKEN}`,
  };
}

/**
 * Search TMDB for movies, TV shows, or both
 */
export async function searchTMDB(
  query: string,
  type: 'multi' | 'movie' | 'tv' = 'multi'
): Promise<Array<{
  id: number;
  title: string;
  poster_path: string | null;
  year: number | null;
  media_type: string;
}>> {
  try {
    const response = await fetch(
      `${TMDB_BASE_URL}/search/${type}?query=${encodeURIComponent(query)}&page=1`,
      {
        headers: getTMDBHeaders(),
      }
    );

    if (!response.ok) {
      console.error('TMDB search failed:', response.statusText);
      return [];
    }

    const data = (await response.json()) as TMDBSearchResponse;

    return data.results.map((item) => ({
      id: item.id,
      title: item.title || item.name || '',
      poster_path: item.poster_path,
      year: item.release_date
        ? parseInt(item.release_date.substring(0, 4))
        : item.first_air_date
          ? parseInt(item.first_air_date.substring(0, 4))
          : null,
      media_type: item.media_type || type,
    }));
  } catch (error) {
    console.error('Error searching TMDB:', error);
    return [];
  }
}

/**
 * Get full movie details from TMDB
 */
export async function getMovieDetails(id: number): Promise<MovieDetails | null> {
  try {
    const response = await fetch(
      `${TMDB_BASE_URL}/movie/${id}`,
      {
        headers: getTMDBHeaders(),
      }
    );

    if (!response.ok) {
      console.error('Failed to get movie details:', response.statusText);
      return null;
    }

    return (await response.json()) as MovieDetails;
  } catch (error) {
    console.error('Error getting movie details:', error);
    return null;
  }
}

/**
 * Get full TV show details from TMDB
 */
export async function getTVDetails(id: number): Promise<TVDetails | null> {
  try {
    const response = await fetch(
      `${TMDB_BASE_URL}/tv/${id}?append_to_response=external_ids`,
      {
        headers: getTMDBHeaders(),
      }
    );

    if (!response.ok) {
      console.error('Failed to get TV details:', response.statusText);
      return null;
    }

    return (await response.json()) as TVDetails;
  } catch (error) {
    console.error('Error getting TV details:', error);
    return null;
  }
}

/**
 * Get watch providers for US region
 */
export async function getWatchProviders(
  id: number,
  type: 'movie' | 'tv'
): Promise<WatchProviderData | null> {
  try {
    const response = await fetch(
      `${TMDB_BASE_URL}/${type}/${id}/watch/providers`,
      {
        headers: getTMDBHeaders(),
      }
    );

    if (!response.ok) {
      console.error('Failed to get watch providers:', response.statusText);
      return null;
    }

    return (await response.json()) as WatchProviderData;
  } catch (error) {
    console.error('Error getting watch providers:', error);
    return null;
  }
}

/**
 * Search TMDB by keyword string — returns keyword IDs for discover filtering
 */
export async function searchKeywords(
  query: string,
): Promise<Array<{ id: number; name: string }>> {
  try {
    const response = await fetch(
      `${TMDB_BASE_URL}/search/keyword?query=${encodeURIComponent(query)}&page=1`,
      { headers: getTMDBHeaders() },
    );
    if (!response.ok) return [];
    const data = await response.json();
    return (data.results || []).slice(0, 8).map((k: any) => ({ id: k.id, name: k.name }));
  } catch {
    return [];
  }
}

