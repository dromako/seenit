/**
 * TMDB Discover API Client
 * Powers the Browse Mode — continuous movie/TV discovery feed
 */

const TMDB_BASE = 'https://api.themoviedb.org/3';
const API_KEY = import.meta.env.VITE_TMDB_API_KEY;

export interface DiscoverItem {
  id: number;
  title: string;
  poster_path: string | null;
  backdrop_path: string | null;
  media_type: 'movie' | 'tv';
  year: number | null;
  vote_average: number;
  vote_count: number;
  overview: string;
  genre_ids: number[];
}

export interface DiscoverResponse {
  results: DiscoverItem[];
  page: number;
  total_pages: number;
  total_results: number;
}

/** Genre maps for quick lookup */
export const MOVIE_GENRES: Record<number, string> = {
  28: 'Action', 12: 'Adventure', 16: 'Animation', 35: 'Comedy',
  80: 'Crime', 99: 'Documentary', 18: 'Drama', 10751: 'Family',
  14: 'Fantasy', 36: 'History', 27: 'Horror', 10402: 'Music',
  9648: 'Mystery', 10749: 'Romance', 878: 'Sci-Fi', 10770: 'TV Movie',
  53: 'Thriller', 10752: 'War', 37: 'Western',
};

export const TV_GENRES: Record<number, string> = {
  10759: 'Action & Adventure', 16: 'Animation', 35: 'Comedy',
  80: 'Crime', 99: 'Documentary', 18: 'Drama', 10751: 'Family',
  10762: 'Kids', 9648: 'Mystery', 10763: 'News', 10764: 'Reality',
  10765: 'Sci-Fi & Fantasy', 10766: 'Soap', 10767: 'Talk',
  10768: 'War & Politics', 37: 'Western',
};

/** Browsable genre tabs (shared across movie & TV) */
export const BROWSE_GENRES = [
  { id: 0, name: 'Trending' },
  { id: 28, name: 'Action' },
  { id: 35, name: 'Comedy' },
  { id: 27, name: 'Horror' },
  { id: 18, name: 'Drama' },
  { id: 878, name: 'Sci-Fi' },
  { id: 99, name: 'Docs' },
  { id: 53, name: 'Thriller' },
  { id: 10749, name: 'Romance' },
  { id: -1, name: 'Bad Movies' },
];

// US free/ad-supported provider IDs (TMDB watch_provider IDs)
// Tubi=73, Pluto=300, Peacock(free)=386, Crackle=12, Plex=538, Kanopy=191, Hoopla=212
const FREE_PROVIDER_IDS = '73|300|386|12|538|191|212';

export type MediaFilter = 'all' | 'movie' | 'tv';
export type SourceFilter = 'all' | 'free';

interface DiscoverParams {
  mediaType: MediaFilter;
  genre: number;         // 0 = trending, -1 = bad movies
  sourceFilter: SourceFilter;
  page: number;
}

/**
 * Fetch trending content from TMDB
 */
async function fetchTrending(
  mediaType: 'movie' | 'tv' | 'all',
  page: number,
): Promise<DiscoverResponse> {
  const type = mediaType === 'all' ? 'all' : mediaType;
  const url = `${TMDB_BASE}/trending/${type}/week?api_key=${API_KEY}&page=${page}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Trending fetch failed: ${res.status}`);
  const data = await res.json();

  const results: DiscoverItem[] = data.results.map((r: any) => ({
    id: r.id,
    title: r.title || r.name || '',
    poster_path: r.poster_path,
    backdrop_path: r.backdrop_path,
    media_type: r.media_type || mediaType,
    year: r.release_date
      ? parseInt(r.release_date.substring(0, 4))
      : r.first_air_date
        ? parseInt(r.first_air_date.substring(0, 4))
        : null,
    vote_average: r.vote_average || 0,
    vote_count: r.vote_count || 0,
    overview: r.overview || '',
    genre_ids: r.genre_ids || [],
  }));

  // If free-only, we'll filter client-side after fetching providers
  return {
    results,
    page: data.page,
    total_pages: Math.min(data.total_pages, 500),
    total_results: data.total_results,
  };
}

/**
 * Fetch from TMDB Discover endpoint (movies or TV)
 */
async function fetchDiscover(
  type: 'movie' | 'tv',
  page: number,
  genreId: number | null,
  badMovies: boolean,
  freeOnly: boolean
): Promise<DiscoverResponse> {
  const params = new URLSearchParams({
    api_key: API_KEY,
    language: 'en-US',
    watch_region: 'US',
    page: String(page),
    sort_by: badMovies ? 'vote_average.asc' : 'popularity.desc',
    include_adult: 'false',
  });

  if (genreId && genreId > 0) {
    params.set('with_genres', String(genreId));
  }

  if (badMovies) {
    params.set('vote_average.lte', '4.5');
    params.set('vote_count.gte', '50');     // enough votes to be "known bad"
    params.set('sort_by', 'vote_count.desc'); // popular bad movies first
  }

  if (freeOnly) {
    params.set('with_watch_monetization_types', 'free|ads');
    params.set('with_watch_providers', FREE_PROVIDER_IDS);
  }

  // Ensure we get things with posters
  params.set('with_poster', 'true');

  const url = `${TMDB_BASE}/discover/${type}?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Discover fetch failed: ${res.status}`);
  const data = await res.json();

  const results: DiscoverItem[] = data.results.map((r: any) => ({
    id: r.id,
    title: r.title || r.name || '',
    poster_path: r.poster_path,
    backdrop_path: r.backdrop_path,
    media_type: type,
    year: r.release_date
      ? parseInt(r.release_date.substring(0, 4))
      : r.first_air_date
        ? parseInt(r.first_air_date.substring(0, 4))
        : null,
    vote_average: r.vote_average || 0,
    vote_count: r.vote_count || 0,
    overview: r.overview || '',
    genre_ids: r.genre_ids || [],
  }));

  return {
    results: results.filter(r => r.poster_path), // only show items with posters
    page: data.page,
    total_pages: Math.min(data.total_pages, 500),
    total_results: data.total_results,
  };
}

// ── Curated feed helpers for the homepage rows ──

/** Pick a random element from an array */
function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export interface CuratedRow {
  id: string;
  title: string;
  emoji: string;
  items: DiscoverItem[];
}

const DECADES = [
  { label: '70s', start: '1970-01-01', end: '1979-12-31' },
  { label: '80s', start: '1980-01-01', end: '1989-12-31' },
  { label: '90s', start: '1990-01-01', end: '1999-12-31' },
  { label: '2000s', start: '2000-01-01', end: '2009-12-31' },
  { label: '2010s', start: '2010-01-01', end: '2019-12-31' },
];

const SPOTLIGHT_GENRES = [
  { id: 99, name: 'Documentaries', emoji: '📽️' },
  { id: 878, name: 'Sci-Fi', emoji: '🚀' },
  { id: 27, name: 'Horror', emoji: '👻' },
  { id: 80, name: 'Crime', emoji: '🔍' },
  { id: 10752, name: 'War Films', emoji: '⚔️' },
  { id: 36, name: 'History', emoji: '📜' },
  { id: 16, name: 'Animation', emoji: '🎨' },
  { id: 37, name: 'Westerns', emoji: '🤠' },
  { id: 9648, name: 'Mystery', emoji: '🕵️' },
  { id: 14, name: 'Fantasy', emoji: '🧙' },
];

/**
 * Fetch a single curated discover row
 */
async function fetchCuratedRow(
  sortBy: string,
  extraParams: Record<string, string>,
  limit = 15,
): Promise<DiscoverItem[]> {
  const params = new URLSearchParams({
    api_key: API_KEY,
    language: 'en-US',
    watch_region: 'US',
    page: String(1 + Math.floor(Math.random() * 3)), // randomise page for variety
    sort_by: sortBy,
    include_adult: 'false',
    with_poster: 'true',
    ...extraParams,
  });

  const url = `${TMDB_BASE}/discover/movie?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) return [];
  const data = await res.json();

  return (data.results || [])
    .filter((r: any) => r.poster_path)
    .slice(0, limit)
    .map((r: any): DiscoverItem => ({
      id: r.id,
      title: r.title || r.name || '',
      poster_path: r.poster_path,
      backdrop_path: r.backdrop_path,
      media_type: 'movie',
      year: r.release_date ? parseInt(r.release_date.substring(0, 4)) : null,
      vote_average: r.vote_average || 0,
      vote_count: r.vote_count || 0,
      overview: r.overview || '',
      genre_ids: r.genre_ids || [],
    }));
}

/**
 * Build the full curated homepage feed.
 * Returns 5-6 themed rows, each with ~15 posters.
 * Randomises decade + genre each load so it never feels stale.
 */
export async function getCuratedFeed(): Promise<CuratedRow[]> {
  const decade = pickRandom(DECADES);
  const genre = pickRandom(SPOTLIGHT_GENRES);

  const [certified, hidden, decadeRow, genreRow, freeRow, recentCritical] = await Promise.all([
    // Certified Fresh — high rating, lots of votes, any era
    fetchCuratedRow('vote_average.desc', {
      'vote_count.gte': '2000',
      'vote_average.gte': '7.5',
    }),
    // Hidden Gems — good rating, low visibility
    fetchCuratedRow('vote_average.desc', {
      'vote_count.gte': '50',
      'vote_count.lte': '500',
      'vote_average.gte': '7.0',
    }),
    // Decade Classics
    fetchCuratedRow('vote_average.desc', {
      'primary_release_date.gte': decade.start,
      'primary_release_date.lte': decade.end,
      'vote_count.gte': '500',
      'vote_average.gte': '7.0',
    }),
    // Genre Essentials
    fetchCuratedRow('vote_average.desc', {
      with_genres: String(genre.id),
      'vote_count.gte': '500',
      'vote_average.gte': '7.0',
    }),
    // Free Right Now
    fetchCuratedRow('vote_average.desc', {
      with_watch_monetization_types: 'free|ads',
      with_watch_providers: FREE_PROVIDER_IDS,
      'vote_count.gte': '200',
    }),
    // Recent Critical Darlings — last 3 years, high rating
    fetchCuratedRow('vote_average.desc', {
      'primary_release_date.gte': `${new Date().getFullYear() - 3}-01-01`,
      'vote_count.gte': '500',
      'vote_average.gte': '7.0',
    }),
  ]);

  const rows: CuratedRow[] = [];

  if (recentCritical.length > 0) {
    rows.push({ id: 'recent-critical', title: 'Recent Critical Darlings', emoji: '🏆', items: recentCritical });
  }
  if (certified.length > 0) {
    rows.push({ id: 'certified', title: 'Certified Fresh', emoji: '🍅', items: certified });
  }
  if (hidden.length > 0) {
    rows.push({ id: 'hidden', title: 'Hidden Gems', emoji: '💎', items: hidden });
  }
  if (freeRow.length > 0) {
    rows.push({ id: 'free', title: 'Free Right Now', emoji: '🆓', items: freeRow });
  }
  if (decadeRow.length > 0) {
    rows.push({ id: 'decade', title: `Best of the ${decade.label}`, emoji: '📀', items: decadeRow });
  }
  if (genreRow.length > 0) {
    rows.push({ id: 'genre', title: `${genre.name} Essentials`, emoji: genre.emoji, items: genreRow });
  }

  return rows;
}

/**
 * Main discover function — routes to trending or discover based on params
 */
export async function discoverContent(params: DiscoverParams): Promise<DiscoverResponse> {
  const { mediaType, genre, sourceFilter, page } = params;
  const freeOnly = sourceFilter === 'free';
  const isBadMovies = genre === -1;
  const isTrending = genre === 0;

  if (isTrending) {
    return fetchTrending(mediaType === 'all' ? 'all' : mediaType, page);
  }

  // For "all" media type, fetch both and merge
  if (mediaType === 'all') {
    const [movies, tv] = await Promise.all([
      fetchDiscover('movie', page, isBadMovies ? null : genre, isBadMovies, freeOnly),
      fetchDiscover('tv', page, isBadMovies ? null : genre, isBadMovies, freeOnly),
    ]);

    const merged = [...movies.results, ...tv.results]
      .sort((a, b) => {
        if (isBadMovies) return a.vote_average - b.vote_average;
        return b.vote_average - a.vote_average;
      })
      .slice(0, 20);

    return {
      results: merged,
      page,
      total_pages: Math.min(movies.total_pages, tv.total_pages, 500),
      total_results: movies.total_results + tv.total_results,
    };
  }

  return fetchDiscover(mediaType, page, isBadMovies ? null : genre, isBadMovies, freeOnly);
}
