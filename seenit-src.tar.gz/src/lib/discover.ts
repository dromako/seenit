/**
 * TMDB Discover API Client
 * Powers the Browse Mode — continuous movie/TV discovery feed
 */

const TMDB_BASE = 'https://api.themoviedb.org/3';
const API_KEY = import.meta.env.VITE_TMDB_API_KEY;

export interface DiscoverItem {
  id: number;
  title: string;
  poster_path: string | null;
  backdrop_path: string | null;
  media_type: 'movie' | 'tv';
  year: number | null;
  vote_average: number;
  vote_count: number;
  overview: string;
  genre_ids: number[];
}

export interface DiscoverResponse {
  results: DiscoverItem[];
  page: number;
  total_pages: number;
  total_results: number;
}

/** Mood-based browse tabs — cinephile picks by feeling, not genre label */
export const BROWSE_GENRES = [
  { id: 0, name: 'Trending' },
  { id: 27, name: 'Get Scared' },
  { id: 35, name: 'Make Me Laugh' },
  { id: 18, name: 'Feel Something' },
  { id: 878, name: 'Mind-Bending' },
  { id: 99, name: 'Learn Something' },
  { id: 28, name: 'Adrenaline' },
  { id: 53, name: 'On the Edge' },
  { id: 10749, name: 'Fall in Love' },
  { id: -1, name: 'So Bad It\'s Good' },
];

// US free/ad-supported provider IDs (TMDB watch_provider IDs)
// Tubi=73, Pluto=300, Peacock(free)=386, Plex=538, Kanopy=191
const FREE_PROVIDER_IDS = '73|300|386|538|191';

export type MediaFilter = 'all' | 'movie' | 'tv';
export type SourceFilter = 'all' | 'free';

interface DiscoverParams {
  mediaType: MediaFilter;
  genre: number;         // 0 = trending, -1 = bad movies
  sourceFilter: SourceFilter;
  page: number;
}

// Family (10751) and Kids (10762) genre IDs — not blocked, but held to a
// higher bar. Spirited Away / Inside Out / Fantastic Mr. Fox belong in the
// feed; Paw Patrol: The Movie does not. The test: would a childless adult
// cinephile enjoy this? High vote count + high rating = yes.
const FAMILY_GENRE = 10751;
const KIDS_GENRE = 10762;
const KIDS_VOTE_FLOOR = 500;   // Must be widely seen, not just well-rated by parents
const KIDS_RATING_FLOOR = 7.5; // Must be genuinely excellent, not just "good for kids"

// Music (10402) — concerts, music documentaries, concert films. The vast
// majority are fan-service with inflated ratings from stans. Stop Making
// Sense and Amadeus pass; a random K-pop concert film does not.
const MUSIC_GENRE = 10402;
const MUSIC_VOTE_FLOOR = 800;
const MUSIC_RATING_FLOOR = 7.5;

/**
 * Quality gate: filters out content with built-in audiences that inflate
 * ratings regardless of actual quality. Every category here follows the
 * same DTV pattern: a captive audience rates en masse, making the content
 * look acclaimed when it's actually niche. We let through titles with
 * genuine broad critical engagement (high vote count + high average).
 *
 * Categories filtered:
 * - Children's/family (rated 10/10 by parents of a narrow age group)
 * - Faith-based/DTV religious (rated 10/10 by congregations)
 * - Music/concerts (rated 10/10 by fanbases of a specific artist)
 * - Reality TV / vanity projects / sports docs (low-effort, built-in audience)
 *
 * The test for all: would a serious cinephile with no prior attachment
 * to the subject enjoy this as a *film experience*?
 */
function passesQualityGate(
  genreIds: number[],
  voteCount: number,
  voteAvg: number,
  title: string,
  overview: string,
): boolean {
  // ── Kids/Family filter ──
  const isKidsFamily = genreIds.includes(FAMILY_GENRE) || genreIds.includes(KIDS_GENRE);
  if (isKidsFamily && (voteCount < KIDS_VOTE_FLOOR || voteAvg < KIDS_RATING_FLOOR)) {
    return false;
  }

  // ── Music / concert film filter ──
  // Fan-filmed concerts, K-pop docs, artist vanity projects inflate via
  // stans. Stop Making Sense, Amadeus, Whiplash pass the bar easily.
  const isMusic = genreIds.includes(MUSIC_GENRE);
  if (isMusic && (voteCount < MUSIC_VOTE_FLOOR || voteAvg < MUSIC_RATING_FLOOR)) {
    return false;
  }

  // ── Text-based signal detection ──
  const lowerTitle = title.toLowerCase();
  const lowerOverview = overview.toLowerCase();
  const text = `${lowerTitle} ${lowerOverview}`;

  // ── DTV / faith-based / religious propaganda filter ──
  const faithSignals = [
    'faith', 'prayer', 'prayers', 'praying', 'god\'s', 'gods plan',
    'christian', 'church congregation', 'gospel', 'scripture',
    'bible study', 'biblical', 'testament', 'sermon',
    'pureflix', 'pure flix', 'affirm films',
    'missionary', 'salvation', 'rapture', 'prophecy fulfil',
    'christian film', 'faith-based', 'faith based',
  ];

  const hasFaithSignal = faithSignals.some(s => text.includes(s));

  if (hasFaithSignal && voteCount < 500) {
    return false;
  }
  if (hasFaithSignal && voteAvg >= 8.5 && voteCount < 200) {
    return false;
  }

  // ── Concert / live performance filter ──
  // Catches music content even when genre tag is missing. The Talking Heads,
  // Prince, or Beyoncé concert films that genuinely move cinema forward will
  // have the vote counts to pass. A random EDM festival recording will not.
  const concertSignals = [
    'concert', 'live performance', 'live tour', 'world tour',
    'stadium tour', 'farewell tour', 'reunion tour',
    'concert film', 'concert special', 'live at',
    'music video', 'music special', 'unplugged',
  ];
  const hasConcertSignal = concertSignals.some(s => text.includes(s));
  if (hasConcertSignal && voteCount < 500) {
    return false;
  }

  // ── Reality TV / competition / vanity project filter ──
  // Reality shows and their film spinoffs have built-in audiences that
  // rate 10/10 regardless of quality. Keeping the vote floor at 300 lets
  // genuinely acclaimed docs about these worlds through (e.g. Paris Is
  // Burning) while filtering out "Real Housewives: The Movie".
  const realitySignals = [
    'reality show', 'reality tv', 'reality series', 'reality competition',
    'big brother', 'the bachelor', 'love island', 'survivor',
    'talent show', 'talent competition', 'audition',
    'vanity project', 'self-funded', 'crowdfunded film',
  ];
  const hasRealitySignal = realitySignals.some(s => text.includes(s));
  if (hasRealitySignal && voteCount < 300) {
    return false;
  }

  // ── Sports / athletic event filter ──
  // ESPN 30 for 30 and Hoop Dreams pass easily. A random MMA highlight
  // reel or bowling championship does not. The bar: it must work as a
  // *film*, not just as sports coverage.
  const sportsSignals = [
    'championship game', 'championship match', 'championship fight',
    'playoff', 'super bowl', 'world cup final',
    'boxing match', 'mma fight', 'ufc', 'wrestling event',
    'highlight reel', 'season recap', 'game highlights',
    'sports special', 'espn', 'match day',
  ];
  const hasSportsSignal = sportsSignals.some(s => text.includes(s));
  if (hasSportsSignal && voteCount < 400) {
    return false;
  }

  // ── Ultra-low-vote filter (catches trailers, shorts, and DTV slop) ──
  // Anything with <20 votes is almost certainly not a real theatrical
  // release or notable direct-to-streaming title. This catches things
  // like "AJ Zombies!" that are effectively trailers or student films
  // indexed by TMDB but not real movies anyone should discover.
  if (voteCount < 20) {
    return false;
  }

  return true;
}

/**
 * Fetch trending content from TMDB
 */
async function fetchTrending(
  mediaType: 'movie' | 'tv' | 'all',
  page: number,
): Promise<DiscoverResponse> {
  const type = mediaType === 'all' ? 'all' : mediaType;
  const url = `${TMDB_BASE}/trending/${type}/week?api_key=${API_KEY}&page=${page}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Trending fetch failed: ${res.status}`);
  const data = await res.json();

  const results: DiscoverItem[] = data.results.map((r: any) => ({
    id: r.id,
    title: r.title || r.name || '',
    poster_path: r.poster_path,
    backdrop_path: r.backdrop_path,
    media_type: r.media_type || mediaType,
    year: r.release_date
      ? parseInt(r.release_date.substring(0, 4))
      : r.first_air_date
        ? parseInt(r.first_air_date.substring(0, 4))
        : null,
    vote_average: r.vote_average || 0,
    vote_count: r.vote_count || 0,
    overview: r.overview || '',
    genre_ids: r.genre_ids || [],
  }));

  // Smart kids/family filter — keeps genuinely great films (Ghibli, Pixar best),
  // filters out narrow-audience kids content that inflates ratings
  const filtered = results.filter(r =>
    passesQualityGate(r.genre_ids, r.vote_count, r.vote_average, r.title, r.overview)
  );

  return {
    results: filtered,
    page: data.page,
    total_pages: Math.min(data.total_pages, 500),
    total_results: data.total_results,
  };
}

/**
 * Fetch from TMDB Discover endpoint (movies or TV)
 */
async function fetchDiscover(
  type: 'movie' | 'tv',
  page: number,
  genreId: number | null,
  badMovies: boolean,
  freeOnly: boolean
): Promise<DiscoverResponse> {
  // For genre tabs: sort by quality (vote_average) with a vote floor so we
  // surface great catalog films, not just whatever's in theaters this week.
  // For trending (genreId=null, !badMovies): keep popularity for recency.
  const defaultSort = genreId ? 'vote_average.desc' : 'popularity.desc';

  const params = new URLSearchParams({
    api_key: API_KEY,
    language: 'en-US',
    watch_region: 'US',
    page: String(page),
    sort_by: badMovies ? 'vote_average.asc' : defaultSort,
    include_adult: 'false',
  });

  if (genreId && genreId > 0) {
    params.set('with_genres', String(genreId));
    // Quality floor: enough votes to be credible, high enough rating to be worth watching
    params.set('vote_count.gte', '150');
    params.set('vote_average.gte', '6.0');
  }

  if (badMovies) {
    params.set('vote_average.lte', '4.5');
    params.set('vote_count.gte', '50');     // enough votes to be "known bad"
    params.set('sort_by', 'vote_count.desc'); // popular bad movies first
  }

  if (freeOnly) {
    params.set('with_watch_monetization_types', 'free|ads');
    params.set('with_watch_providers', FREE_PROVIDER_IDS);
  }

  // Ensure we get things with posters
  params.set('with_poster', 'true');

  const url = `${TMDB_BASE}/discover/${type}?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Discover fetch failed: ${res.status}`);
  const data = await res.json();

  const results: DiscoverItem[] = data.results.map((r: any) => ({
    id: r.id,
    title: r.title || r.name || '',
    poster_path: r.poster_path,
    backdrop_path: r.backdrop_path,
    media_type: type,
    year: r.release_date
      ? parseInt(r.release_date.substring(0, 4))
      : r.first_air_date
        ? parseInt(r.first_air_date.substring(0, 4))
        : null,
    vote_average: r.vote_average || 0,
    vote_count: r.vote_count || 0,
    overview: r.overview || '',
    genre_ids: r.genre_ids || [],
  }));

  return {
    results: results
      .filter(r => r.poster_path)
      .filter(r => passesQualityGate(r.genre_ids, r.vote_count, r.vote_average, r.title, r.overview)),
    page: data.page,
    total_pages: Math.min(data.total_pages, 500),
    total_results: data.total_results,
  };
}

// ── Curated feed helpers for the homepage rows ──

/** Pick a random element from an array */
function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

// ── Curated TMDB list integration ──
// Hand-picked TMDB list IDs from well-known curators: Letterboxd popular,
// critics' annual best-of, essential viewing, and niche gems. Each load
// picks one list at random so the feed stays fresh without repeating.
// Mix of broad critic lists and genre-specific / blog-celebrated collections.
// David's feedback: the old set (Top 250, Oscar Winners, etc.) was too
// mainstream. Keep a couple of canon anchors but lean into genre curation,
// niche blog favourites, and lists that celebrate films rather than rank them.
// Split curated lists into two pools so we can enforce recency balance.
// "Canon" lists inherently skew pre-2000 and foreign — they're great
// anchor rows but shouldn't dominate every load. "Modern" lists skew
// toward the last 20 years. Each load picks one from each pool.
const CURATED_CANON = [
  { id: 7104730, name: 'Criterion Collection', subtitle: 'Curated for serious film lovers' },
  { id: 7108693, name: 'Sight & Sound 250', subtitle: 'What critics consider the greatest' },
  { id: 3643, name: 'TSPDT 1000', subtitle: 'They Shoot Pictures — the deep canon' },
  { id: 113, name: 'Noir & Neo-Noir', subtitle: 'Shadow, smoke, and moral ambiguity' },
  { id: 7062850, name: 'Global South Cinema', subtitle: 'Africa, Asia, Latin America — the other canon' },
];
const CURATED_MODERN = [
  { id: 138, name: 'Cult Classics', subtitle: 'Films that found their tribe' },
  { id: 522, name: 'A24 Films', subtitle: 'The studio that defined indie' },
  { id: 8205747, name: 'Queer Palm Winners', subtitle: 'Cannes LGBTQ+ cinema at its finest' },
  { id: 8173092, name: 'Letterboxd Top 250 Narrative', subtitle: 'What cinephiles actually love' },
  { id: 7063871, name: 'Horror Canon', subtitle: 'The films horror fans insist you see' },
  { id: 7055064, name: 'Arthouse Essentials', subtitle: 'Festival and arthouse standouts' },
  { id: 8250290, name: 'Midnight Movies', subtitle: 'The transgressive, the weird, the unforgettable' },
];
// Combined for backward compat with shown-tracker
const CURATED_LIST_IDS = [...CURATED_CANON, ...CURATED_MODERN];

// Track which lists were recently shown to avoid repeats across sessions
const CURATED_SHOWN_KEY = 'seenit_curated_shown';
const CURATED_SHOWN_MAX = 5; // remember last 5 shown lists

function pickCuratedList(): typeof CURATED_LIST_IDS[0] {
  let recentIds: number[] = [];
  try {
    const raw = localStorage.getItem(CURATED_SHOWN_KEY);
    if (raw) recentIds = JSON.parse(raw);
  } catch { /* ignore */ }

  // 60% modern, 40% canon — prevents old/foreign domination while
  // keeping the canon present in the rotation
  const sourcePool = Math.random() < 0.6 ? CURATED_MODERN : CURATED_CANON;

  // Prefer lists not recently shown within the chosen pool
  const fresh = sourcePool.filter(l => !recentIds.includes(l.id));
  const picked = fresh.length > 0 ? pickRandom(fresh) : pickRandom(sourcePool);

  // Update shown tracker
  recentIds.unshift(picked.id);
  if (recentIds.length > CURATED_SHOWN_MAX) recentIds = recentIds.slice(0, CURATED_SHOWN_MAX);
  try { localStorage.setItem(CURATED_SHOWN_KEY, JSON.stringify(recentIds)); } catch { /* ignore */ }

  return picked;
}

/**
 * Fetch items from a TMDB list. Returns DiscoverItems from a random page
 * of the list for variety. Falls back gracefully on failure.
 */
async function fetchCuratedList(listId: number, limit = 12): Promise<DiscoverItem[]> {
  try {
    // Random page for variety within larger lists
    const page = 1 + Math.floor(Math.random() * 5);
    const url = `${TMDB_BASE}/list/${listId}?api_key=${API_KEY}&language=en-US&page=${page}`;
    const res = await fetch(url);
    if (!res.ok) return [];
    const data = await res.json();

    const items: DiscoverItem[] = (data.items || [])
      .filter((r: any) => r.poster_path)
      .map((r: any): DiscoverItem => ({
        id: r.id,
        title: r.title || r.name || '',
        poster_path: r.poster_path,
        backdrop_path: r.backdrop_path,
        media_type: r.media_type || 'movie',
        year: r.release_date
          ? parseInt(r.release_date.substring(0, 4))
          : r.first_air_date
            ? parseInt(r.first_air_date.substring(0, 4))
            : null,
        vote_average: r.vote_average || 0,
        vote_count: r.vote_count || 0,
        overview: r.overview || '',
        genre_ids: r.genre_ids || [],
      }))
      .filter((r: DiscoverItem) => passesQualityGate(r.genre_ids, r.vote_count, r.vote_average, r.title, r.overview));

    // Shuffle and limit
    return items.sort(() => Math.random() - 0.5).slice(0, limit);
  } catch {
    return [];
  }
}

export interface CuratedRow {
  id: string;
  title: string;
  subtitle: string;
  reasonTaste: string;  // why this aligns with their viewing history
  reasonMood: string;   // why this feels right for them *right now*
  items: DiscoverItem[];
}

const DECADES = [
  { label: '60s', start: '1960-01-01', end: '1969-12-31' },
  { label: '70s', start: '1970-01-01', end: '1979-12-31' },
  { label: '80s', start: '1980-01-01', end: '1989-12-31' },
  { label: '90s', start: '1990-01-01', end: '1999-12-31' },
  { label: '2000s', start: '2000-01-01', end: '2009-12-31' },
  { label: '2010s', start: '2010-01-01', end: '2019-12-31' },
  { label: '2020s', start: '2020-01-01', end: '2029-12-31' },
];

const SPOTLIGHT_GENRES = [
  { id: 99, name: 'Documentary' },
  { id: 878, name: 'Sci-Fi' },
  { id: 27, name: 'Horror' },
  { id: 80, name: 'Crime' },
  { id: 10752, name: 'War' },
  { id: 36, name: 'History' },
  { id: 16, name: 'Animation' },
  { id: 37, name: 'Western' },
  { id: 9648, name: 'Mystery' },
  { id: 14, name: 'Fantasy' },
  { id: 10749, name: 'Romance' },
  { id: 53, name: 'Thriller' },
];

/** Language codes for "world cinema" row — non-English standouts */
const WORLD_LANGUAGES = ['ko', 'ja', 'fr', 'es', 'de', 'it', 'pt', 'zh', 'hi', 'sv', 'da', 'pl', 'tr', 'th'];

/**
 * Fetch a single curated discover row
 */
async function fetchCuratedRow(
  sortBy: string,
  extraParams: Record<string, string>,
  limit = 12,
): Promise<DiscoverItem[]> {
  // Randomise across pages 1-10 for deep variety — never the same feed twice
  const page = 1 + Math.floor(Math.random() * 10);

  const params = new URLSearchParams({
    api_key: API_KEY,
    language: 'en-US',
    watch_region: 'US',
    page: String(page),
    sort_by: sortBy,
    include_adult: 'false',
    with_poster: 'true',
    ...extraParams,
  });

  const url = `${TMDB_BASE}/discover/movie?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) return [];
  const data = await res.json();

  const items = (data.results || [])
    .filter((r: any) => r.poster_path)
    .map((r: any): DiscoverItem => ({
      id: r.id,
      title: r.title || r.name || '',
      poster_path: r.poster_path,
      backdrop_path: r.backdrop_path,
      media_type: 'movie',
      year: r.release_date ? parseInt(r.release_date.substring(0, 4)) : null,
      vote_average: r.vote_average || 0,
      vote_count: r.vote_count || 0,
      overview: r.overview || '',
      genre_ids: r.genre_ids || [],
    }))
    // Smart kids/family filter — keeps genuinely great films (Ghibli, Pixar best),
    // filters out narrow-audience kids content that inflates ratings
    .filter((r: DiscoverItem) => passesQualityGate(r.genre_ids, r.vote_count, r.vote_average, r.title, r.overview))
    .slice(0, limit);

  // Shuffle results within the row for extra unpredictability
  return items.sort(() => Math.random() - 0.5);
}

/**
 * Build the full curated homepage feed.
 * Returns up to 9 themed rows, each with ~12 posters.
 * Randomises decade, genre, language, and genre-mash combos each load
 * so it never feels stale. Rows are shuffled (first row pinned).
 */
export interface VibeClusterInput {
  label: string;
  subtitle: string;
  keywordIds: number[];
}

export interface ViewerAffinities {
  topGenres?: number[];   // genre IDs the viewer taps most
  topDecade?: string;     // e.g. "80s"
  vibes?: VibeClusterInput[];  // personal keyword clusters to surface
}

export interface MoodInput {
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'latenight';
  dayName: string;
  isWeekend: boolean;
  recentTone: 'heavy' | 'light' | 'intense' | 'mixed' | 'unknown';
  hasHistory: boolean;
}

export async function getCuratedFeed(affinities?: ViewerAffinities, mood?: MoodInput): Promise<CuratedRow[]> {
  const hasAffinities = affinities && (affinities.topGenres?.length || affinities.topDecade);

  // When we know the viewer: one slot is their favourite genre, one is a
  // surprise genre they haven't explored. The decade leans toward theirs
  // but the rest stays random. The feed should feel like a friend who knows
  // you picked it — not an algorithm narrowing your world.
  let decade: typeof DECADES[number];
  let genre: typeof SPOTLIGHT_GENRES[number];
  let genreIsPersonal = false;
  let decadeIsPersonal = false;

  if (hasAffinities && affinities?.topDecade) {
    const match = DECADES.find(d => d.label === affinities.topDecade);
    // 60% lean toward their decade, 40% surprise — familiar enough to trust, wild enough to grow
    decade = match && Math.random() < 0.6 ? match : pickRandom(DECADES);
    decadeIsPersonal = decade === match;
  } else {
    decade = pickRandom(DECADES);
  }

  if (hasAffinities && affinities?.topGenres?.length) {
    const match = SPOTLIGHT_GENRES.find(g => affinities.topGenres!.includes(g.id));
    // 40% lean toward a genre they love, 60% surprise — prevents "More Horror"
    // from dominating every load when Horror is the top engaged genre.
    genre = match && Math.random() < 0.4 ? match : pickRandom(SPOTLIGHT_GENRES);
    genreIsPersonal = genre === match;
  } else {
    genre = pickRandom(SPOTLIGHT_GENRES);
  }

  const worldLang = pickRandom(WORLD_LANGUAGES);

  // Second genre for mash: must be from a different thematic family than genre.
  // Group similar genres so we never get "Western Essentials" + "Western × Animation".
  const GENRE_FAMILIES: Record<number, string> = {
    27: 'tension', 53: 'tension', 9648: 'tension',   // horror, thriller, mystery
    878: 'speculative', 14: 'speculative',             // sci-fi, fantasy
    80: 'crime', 10752: 'conflict', 36: 'history',
    99: 'nonfiction', 16: 'animation',
    37: 'western', 10749: 'romance',
  };
  const genreFamily = GENRE_FAMILIES[genre.id];
  const genre2candidates = SPOTLIGHT_GENRES.filter(g =>
    g.id !== genre.id && GENRE_FAMILIES[g.id] !== genreFamily
  );
  const unexplored = hasAffinities && affinities?.topGenres?.length
    ? genre2candidates.filter(g => !affinities.topGenres!.includes(g.id))
    : genre2candidates;
  const genre2 = unexplored.length > 0 ? pickRandom(unexplored) : pickRandom(genre2candidates.length > 0 ? genre2candidates : SPOTLIGHT_GENRES.filter(g => g.id !== genre.id));

  // Build a "Viewers Like You" query from top genres — but keep it loose.
  // Use only 1-2 genres (not 3) to avoid over-narrowing, and 30% of the time
  // go fully random so the feed always has surprises.
  let tasteGenres: string | null = null;
  if (hasAffinities && affinities?.topGenres?.length && Math.random() > 0.3) {
    // Use 1 or 2 genres, randomly chosen from their top 5
    const shuffledTaste = [...affinities.topGenres].sort(() => Math.random() - 0.5);
    tasteGenres = shuffledTaste.slice(0, 1 + Math.floor(Math.random() * 2)).join(',');
  }

  // Personal vibes — keyword clusters that reflect the viewer's specific world
  const vibes = affinities?.vibes || [];

  // Pick a curated TMDB list for this load (rotates, avoids recent repeats)
  const curatedList = pickCuratedList();

  // ── Enhanced category discovery ──
  // TMDB keyword IDs for targeted categories
  // Festival favorites: Cannes (3601), Sundance (2467), Venice (7484), Berlin (4069), TIFF (11476)
  // Classic cinema: film noir (1564), criterion collection (179431), new hollywood (155477)
  // Queer/camp/adult: lgbt (158718), drag (264384), camp (155493), bdsm (158713)
  // Horror deep: folk horror (261178), body horror (224636), cosmic horror (316173), giallo (163053)
  const FESTIVAL_KEYWORDS = '3601|2467|7484|4069|11476';
  const CLASSIC_KEYWORDS = '1564|179431|155477|10683'; // noir + criterion + new hollywood + golden age
  const HORROR_DEEP_KEYWORDS = '261178|224636|316173|163053|6152'; // folk, body, cosmic, giallo, slasher

  // Pick one enhanced category per load to keep feed fresh (rotate 2 of 5)
  const enhancedCategories = [
    { id: 'festival', label: 'Festival Circuit', subtitle: 'Cannes, Sundance, Venice — the films that made the festivals', kw: FESTIVAL_KEYWORDS },
    { id: 'critics', label: 'Critics\' Obsessions', subtitle: 'The films critics won\'t shut up about', kw: null },
    { id: 'classic', label: 'Classic Cinema', subtitle: 'Noir, New Hollywood, golden age — the canon and the forgotten', kw: CLASSIC_KEYWORDS },
    { id: 'queer-deep', label: 'Queer Deep Cuts', subtitle: 'Beyond the obvious — the films that found their audience', kw: '158718|264384|155493|158713|300642' },
    { id: 'horror-deep', label: 'Horror Rabbit Hole', subtitle: 'Folk horror, body horror, giallo — the dark corners', kw: HORROR_DEEP_KEYWORDS },
  ];
  // Shuffle and pick 2
  const shuffledCats = [...enhancedCategories].sort(() => Math.random() - 0.5);
  const pickedCats = shuffledCats.slice(0, 2);

  const results = await Promise.allSettled([
    // Viewers Like You — uses actual taste profile, or falls back to acclaimed-but-overlooked
    tasteGenres
      ? fetchCuratedRow('vote_average.desc', {
          with_genres: tasteGenres,
          'vote_count.gte': '50',
          'vote_count.lte': '1500',
          'vote_average.gte': '6.0',
          without_genres: '10402,10770',
        })
      : fetchCuratedRow('vote_average.desc', {
          'vote_count.gte': '300',
          'vote_count.lte': '2000',
          'vote_average.gte': '6.5',
          without_genres: '10402,10770',
        }),
    // Hidden Gems — good films with a real audience but not blockbusters.
    // Constrained to last 25 years to avoid surfacing only golden-age classics.
    fetchCuratedRow('vote_average.desc', {
      'vote_count.gte': '100',
      'vote_count.lte': '1000',
      'vote_average.gte': '6.0',
      'primary_release_date.gte': `${new Date().getFullYear() - 25}-01-01`,
      without_genres: '10402,10770',  // exclude Music, TV movies
    }),
    // Decade Classics
    fetchCuratedRow('vote_average.desc', {
      'primary_release_date.gte': decade.start,
      'primary_release_date.lte': decade.end,
      'vote_count.gte': '200',
      'vote_average.gte': '6.0',
      without_genres: '10402,10770',  // no music films or TV movies
    }),
    // Genre Essentials — wider net, biased toward last 30 years so
    // the row isn't just 1950s–1970s canon every time
    fetchCuratedRow(Math.random() < 0.6 ? 'vote_average.desc' : 'popularity.desc', {
      with_genres: String(genre.id),
      'vote_count.gte': '200',
      'vote_average.gte': '6.0',
      without_genres: '10402,10770',
      ...(Math.random() < 0.5 ? { 'primary_release_date.gte': `${new Date().getFullYear() - 30}-01-01` } : {}),
    }),
    // Recent Critical Darlings — last 3 years
    fetchCuratedRow('vote_average.desc', {
      'primary_release_date.gte': `${new Date().getFullYear() - 3}-01-01`,
      'vote_count.gte': '200',
      'vote_average.gte': '6.0',
      without_genres: '10402,10770',  // no music films or TV movies
    }),
    // World Cinema — non-English standouts. Constrained to last 30 years
    // so the row surfaces modern world cinema, not just Kurosawa and
    // Bergman every load. The curated lists already cover the classics.
    fetchCuratedRow('vote_average.desc', {
      with_original_language: worldLang,
      'vote_count.gte': '500',
      'vote_average.gte': '6.5',
      'primary_release_date.gte': `${new Date().getFullYear() - 30}-01-01`,
      without_genres: '10402,10770,99',  // no music, TV movies, documentaries (stand-up)
    }),
    // Deep Cuts — excellent but under-known. English-language, last 20 years
    // to keep these genuinely fresh and discoverable.
    fetchCuratedRow('vote_average.desc', {
      'vote_count.gte': '50',
      'vote_count.lte': '500',
      'vote_average.gte': '6.5',
      with_original_language: 'en',
      'primary_release_date.gte': `${new Date().getFullYear() - 20}-01-01`,
      without_genres: '10402,10770',  // no music films or TV movies
    }),
    // Genre Mash — two genres combined for unexpected discoveries
    fetchCuratedRow('vote_average.desc', {
      with_genres: `${genre.id},${genre2.id}`,
      'vote_count.gte': '100',
      'vote_average.gte': '6.5',
      without_genres: '10402,10770',
    }),
    // Wild Card — completely ignores taste data, pure surprise from a random
    // corner of cinema. The goal: expand the world, not reinforce it.
    // Every strategy requires enough votes to prove real audience engagement.
    (() => {
      const wildGenre = pickRandom(SPOTLIGHT_GENRES);
      const wildDecade = pickRandom(DECADES);
      const strategy = Math.floor(Math.random() * 3);
      if (strategy === 0) {
        // Random genre from random decade — well-known enough to be interesting
        return fetchCuratedRow('vote_average.desc', {
          with_genres: String(wildGenre.id),
          'primary_release_date.gte': wildDecade.start,
          'primary_release_date.lte': wildDecade.end,
          'vote_count.gte': '200',
          'vote_average.gte': '6.5',
        });
      } else if (strategy === 1) {
        // Recently popular but NOT in their taste genres — genuine diversity
        const avoidGenres = hasAffinities && affinities?.topGenres?.length
          ? affinities.topGenres.join(',')
          : '';
        return fetchCuratedRow('popularity.desc', {
          ...(avoidGenres ? { without_genres: avoidGenres } : {}),
          'vote_count.gte': '200',
          'vote_average.gte': '6.0',
          without_genres: '10402,10770',
        });
      } else {
        // Acclaimed but off the beaten path — medium-vote, high-quality
        return fetchCuratedRow('vote_average.desc', {
          'vote_count.gte': '150',
          'vote_count.lte': '800',
          'vote_average.gte': '7.5',
          without_genres: '10402,10770',
        });
      }
    })(),
    // ── Enhanced category rows (2 of 5 per load) ──
    ...pickedCats.map(cat => {
      if (cat.id === 'critics') {
        // Critics' Obsessions: recent films critics love
        return fetchCuratedRow('vote_average.desc', {
          'vote_count.gte': '100',
          'vote_count.lte': '800',
          'vote_average.gte': '7.0',
          'primary_release_date.gte': `${new Date().getFullYear() - 5}-01-01`,
          without_genres: '10402,10770',
        });
      }
      // For keyword-based categories, add recency guardrails to
      // "classic" and "festival" which otherwise surface only pre-1990 films.
      const recencyParams: Record<string, string> = {};
      if (cat.id === 'classic') {
        // Classic Cinema row intentionally reaches back — no recency cap
      } else if (cat.id === 'festival') {
        // Festival Circuit: bias toward last 20 years of festival cinema
        recencyParams['primary_release_date.gte'] = `${new Date().getFullYear() - 20}-01-01`;
      }
      return fetchCuratedRow('vote_average.desc', {
        with_keywords: cat.kw!,
        'vote_count.gte': cat.id === 'queer-deep' || cat.id === 'horror-deep' ? '15' : '30',
        'vote_average.gte': '6.5',
        ...recencyParams,
      });
    }),
    // Personal vibe keyword rows — each cluster fetched separately
    ...vibes.map(vibe =>
      fetchCuratedRow('vote_average.desc', {
        with_keywords: vibe.keywordIds.join('|'),
        'vote_count.gte': '10',
      })
    ),
    // Curated TMDB list — anchors quality with real human curation
    fetchCuratedList(curatedList.id),
  ]);

  // Unwrap settled results — failed fetches become empty arrays instead of crashing the feed
  const unwrap = (r: PromiseSettledResult<DiscoverItem[]>): DiscoverItem[] =>
    r.status === 'fulfilled' ? r.value : [];
  const allResults = results.map(unwrap);
  const [certified, hidden, decadeRow, genreRow, recentCritical, worldCinema, deepCuts, genreMash, wildCard] =
    allResults.slice(0, 9);
  const enhancedResults = allResults.slice(9, 9 + pickedCats.length);
  const vibeResults = allResults.slice(9 + pickedCats.length, 9 + pickedCats.length + vibes.length);
  const curatedListItems = allResults[9 + pickedCats.length + vibes.length] || [];

  const langNames: Record<string, string> = {
    ko: 'Korean', ja: 'Japanese', fr: 'French', es: 'Spanish',
    de: 'German', it: 'Italian', pt: 'Portuguese', zh: 'Chinese',
    hi: 'Hindi', sv: 'Swedish', da: 'Danish', pl: 'Polish',
    tr: 'Turkish', th: 'Thai',
  };

  // ── Build mood-aware reason text ──
  // "reasonTaste" = why this matches their viewing identity
  // "reasonMood"  = why this feels right for who they are *tonight*
  const t = mood?.timeOfDay || 'evening';
  const tone = mood?.recentTone || 'unknown';
  const dayN = mood?.dayName || '';
  const wknd = mood?.isWeekend ?? false;
  const knows = mood?.hasHistory ?? false;

  // Helper: a gentle time-aware line
  function timeFeel(evening: string, late: string, afternoon: string, fallback: string): string {
    if (t === 'latenight') return late;
    if (t === 'evening') return evening;
    if (t === 'afternoon') return afternoon;
    return fallback;
  }

  // Helper: reads the viewer's recent emotional trajectory
  function toneAware(
    afterHeavy: string,
    afterIntense: string,
    afterLight: string,
    neutral: string,
  ): string {
    if (!knows) return neutral;
    if (tone === 'heavy') return afterHeavy;
    if (tone === 'intense') return afterIntense;
    if (tone === 'light') return afterLight;
    return neutral;
  }

  const pool: CuratedRow[] = [];

  if (recentCritical.length > 0) {
    pool.push({
      id: 'recent-critical',
      title: 'Recent Critical Darlings',
      subtitle: 'The films critics can\'t stop talking about',
      reasonTaste: 'New and acclaimed',
      reasonMood: timeFeel(
        'Something fresh for tonight',
        'Still buzzing from this year',
        'Catch up on what everyone\'s talking about',
        'The best of right now',
      ),
      items: recentCritical,
    });
  }
  if (certified.length > 0) {
    pool.push({
      id: 'for-you',
      title: tasteGenres ? 'Picked for You' : 'Acclaimed & Overlooked',
      subtitle: tasteGenres
        ? 'Based on everything you\'ve been watching'
        : 'Great films that slipped through the cracks',
      reasonTaste: tasteGenres
        ? 'Matched to your actual taste profile'
        : 'Acclaimed but not obvious',
      reasonMood: tasteGenres
        ? toneAware(
            'Something that gets you — after a heavy stretch',
            'Tuned to your wavelength',
            'More of the energy you\'ve been chasing',
            'Films that feel like they were chosen for you',
          )
        : timeFeel(
            'A film worth discovering tonight',
            'The ones that reward late-night attention',
            'Something you haven\'t heard of — yet',
            'Quietly brilliant',
          ),
      items: certified,
    });
  }
  if (hidden.length > 0) {
    pool.push({
      id: 'hidden',
      title: 'Hidden Gems',
      subtitle: 'Films most people haven\'t found yet',
      reasonTaste: 'Almost nobody knows these',
      reasonMood: timeFeel(
        'Perfect for a quiet night — discover something new',
        'A rabbit hole for the night owl in you',
        wknd ? 'A lazy weekend find' : 'Something to look forward to tonight',
        'For the curious',
      ),
      items: hidden,
    });
  }
  if (decadeRow.length > 0) {
    pool.push({
      id: 'decade',
      title: `Best of the ${decade.label}`,
      subtitle: decadeIsPersonal
        ? `We noticed you love the ${decade.label}`
        : `A time capsule of the decade's best`,
      reasonTaste: decadeIsPersonal
        ? `You keep gravitating toward the ${decade.label}`
        : `Great films from the ${decade.label}`,
      reasonMood: decadeIsPersonal
        ? timeFeel(
            `A ${decade.label} film feels right tonight`,
            `Late-night ${decade.label} — your comfort zone`,
            `Revisit the ${decade.label} this ${dayN}`,
            `Back to the ${decade.label}`,
          )
        : timeFeel(
            `Travel back to the ${decade.label} tonight`,
            `The ${decade.label} hit different late at night`,
            `Time-travel for a ${dayN} afternoon`,
            `A different era, a different feel`,
          ),
      items: decadeRow,
    });
  }
  if (genreRow.length > 0) {
    const gn = genre.name.toLowerCase();
    pool.push({
      id: 'genre',
      title: genreIsPersonal ? `More ${genre.name}` : `${genre.name} Essentials`,
      subtitle: genreIsPersonal
        ? `Because you keep coming back to ${gn}`
        : 'The definitive collection',
      reasonTaste: genreIsPersonal
        ? `You love ${gn}`
        : `Exploring ${gn}`,
      reasonMood: genreIsPersonal
        ? toneAware(
            `You\'ve been in a heavy place — ${gn} might be the shift you need`,
            `After all that intensity, more ${gn} could hit right`,
            `You\'re in a ${gn} mood — lean into it`,
            `More of what you love`,
          )
        : timeFeel(
            `A ${gn} night`,
            `Late-night ${gn}`,
            `${genre.name} for a ${dayN}`,
            `Try some ${gn}`,
          ),
      items: genreRow,
    });
  }
  if (worldCinema.length > 0) {
    const ln = langNames[worldLang] || 'world';
    pool.push({
      id: 'world',
      title: `${langNames[worldLang] || 'World'} Cinema`,
      subtitle: 'Subtitles on, phones down',
      reasonTaste: `Something different — ${ln} storytelling`,
      reasonMood: toneAware(
        `After all that drama, a change of perspective`,
        `Step outside the familiar for a bit`,
        `Keep exploring — ${ln} cinema has range`,
        timeFeel(
          `Give your evening to a ${ln} film`,
          `The world looks different after midnight`,
          `A ${dayN} afternoon trip — no passport needed`,
          `Broaden the view`,
        ),
      ),
      items: worldCinema,
    });
  }
  if (deepCuts.length > 0) {
    pool.push({
      id: 'deep-cuts',
      title: 'Deep Cuts',
      subtitle: 'Films only cinephiles know',
      reasonTaste: 'The rabbit hole',
      reasonMood: timeFeel(
        'The kind of film you tell people about tomorrow',
        'Deep cuts hit hardest late at night',
        wknd ? 'Weekend discovery mode' : 'Save one for tonight',
        'For when you want to find something nobody else has seen',
      ),
      items: deepCuts,
    });
  }
  if (genreMash.length > 0) {
    pool.push({
      id: 'genre-mash',
      title: `${genre.name} × ${genre2.name}`,
      subtitle: 'When two worlds collide',
      reasonTaste: `What happens when ${genre.name.toLowerCase()} meets ${genre2.name.toLowerCase()}`,
      reasonMood: timeFeel(
        'Something you wouldn\'t think to search for',
        'The weird stuff finds you late at night',
        'Feeling adventurous?',
        'Trust the unexpected',
      ),
      items: genreMash,
    });
  }

  // Wild Card — pure surprise, ignores taste entirely
  if (wildCard.length > 0) {
    pool.push({
      id: 'wild-card',
      title: 'Wild Card',
      subtitle: 'Something you\'d never search for yourself',
      reasonTaste: 'No algorithm — just chance',
      reasonMood: timeFeel(
        'Let the universe pick tonight\'s movie',
        'The best late-night finds are the ones you never expected',
        wknd ? 'Weekend energy: trust the random' : 'Midweek wildcard',
        'Expand the map',
      ),
      items: wildCard,
    });
  }

  // Enhanced category rows — critics' choices, festival, classic cinema, queer deep, horror deep
  pickedCats.forEach((cat, i) => {
    const items = enhancedResults[i] || [];
    if (items.length > 0) {
      pool.push({
        id: `enhanced-${cat.id}`,
        title: cat.label,
        subtitle: cat.subtitle,
        reasonTaste: cat.id === 'queer-deep' ? 'Part of who you are'
          : cat.id === 'horror-deep' ? 'For the brave'
          : cat.id === 'festival' ? 'Award-season credibility'
          : cat.id === 'classic' ? 'The history of the medium'
          : 'What the critics see that audiences miss',
        reasonMood: timeFeel(
          cat.id === 'horror-deep' ? 'Horror hits different after dark'
            : `A ${cat.label.toLowerCase()} night`,
          cat.id === 'horror-deep' ? 'The darkest hour — perfect for this'
            : `Late-night ${cat.label.toLowerCase()}`,
          `${cat.label} for a ${dayN}`,
          cat.subtitle,
        ),
        items,
      });
    }
  });

  // Personal vibe rows — keyword-based discovery from the viewer's specific world
  vibes.forEach((vibe, i) => {
    const items = vibeResults[i] || [];
    if (items.length > 0) {
      pool.push({
        id: `vibe-${i}`,
        title: vibe.label,
        subtitle: vibe.subtitle,
        reasonTaste: `Part of who you are`,
        reasonMood: timeFeel(
          `A ${vibe.label.toLowerCase()} night`,
          `Late-night ${vibe.label.toLowerCase()}`,
          `${vibe.label} for a ${dayN}`,
          vibe.subtitle,
        ),
        items,
      });
    }
  });

  // Curated list row — quality-anchored by real human curation
  if (curatedListItems.length > 0) {
    pool.push({
      id: `curated-${curatedList.id}`,
      title: curatedList.name,
      subtitle: curatedList.subtitle,
      reasonTaste: 'Curated by humans, not algorithms',
      reasonMood: timeFeel(
        'Something from a list worth trusting',
        'Late-night list diving',
        'Browse a curated collection',
        curatedList.subtitle,
      ),
      items: curatedListItems,
    });
  }

  // Deduplicate across rows — a title should only appear in its first row
  const seen = new Set<number>();
  for (const row of pool) {
    row.items = row.items.filter((item) => {
      if (seen.has(item.id)) return false;
      seen.add(item.id);
      return true;
    });
  }

  // ── 60/40 Row ordering: personal-targeted vs enriching/unexpected ──
  //
  // TARGET BALANCE:
  //   60% "over-targeted at David" — rows that match his taste profile,
  //   personal vibes, favourite genres, recent critical picks he'd choose
  //   himself.
  //   40% "entertaining/enriching/unexpected" — world cinema, decade time
  //   capsules, curated canon lists, deep cuts, wild cards, genre mashes.
  //
  // This prevents the feed from becoming either a narrow echo chamber OR
  // an academic film-studies syllabus.

  // Classify every row as personal (P) or discovery (D)
  const personalIds = new Set([
    'recent-critical',  // stuff he'd find himself — new and acclaimed
    'for-you',          // explicitly taste-matched
    'genre',            // his favourite genre
  ]);
  // Vibe rows and queer-deep are also personal
  const isPersonal = (r: CuratedRow): boolean =>
    personalIds.has(r.id) ||
    r.id.startsWith('vibe-') ||
    r.id === 'enhanced-queer-deep';

  const discoveryIds = new Set([
    'hidden', 'deep-cuts', 'wild-card', 'genre-mash',
    'decade', 'world',
  ]);
  const isDiscovery = (r: CuratedRow): boolean =>
    discoveryIds.has(r.id) ||
    r.id.startsWith('curated-') ||
    (r.id.startsWith('enhanced-') && r.id !== 'enhanced-queer-deep');

  const shuffle = <T,>(arr: T[]): T[] => {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  };

  const personalPool = shuffle(pool.filter(isPersonal));
  const discoveryPool = shuffle(pool.filter(isDiscovery));

  // Cap discovery rows: for every 3 personal rows, allow 2 discovery rows.
  // This produces ~60/40. If personal pool is thin (cold start), discovery
  // fills in so the feed isn't empty.
  const maxDiscovery = Math.max(
    3,
    Math.ceil(personalPool.length * (2 / 3)),
  );
  const discoveryCapped = discoveryPool.slice(0, maxDiscovery);

  // Interleave: personal rows dominate the top, discovery rows woven in.
  // Pattern: P, P, D, P, D, P, P, D, ... (roughly 60/40)
  const finalFeed: CuratedRow[] = [];
  let pi = 0;
  let di = 0;
  let slot = 0;

  // Pin Recent Critical Darlings first if present
  const pinned = personalPool.find(r => r.id === 'recent-critical');
  if (pinned) {
    finalFeed.push(pinned);
    pi = personalPool.indexOf(pinned) === 0 ? 1 : 0;
    // Remove it from personalPool so we don't double-add
    const idx = personalPool.indexOf(pinned);
    if (idx !== -1) personalPool.splice(idx, 1);
    slot++;
  }

  while (pi < personalPool.length || di < discoveryCapped.length) {
    // Every 3rd slot (0-indexed: slot 2, 5, 8...) is discovery
    const isDiscoverySlot = slot % 3 === 2;

    if (isDiscoverySlot && di < discoveryCapped.length) {
      finalFeed.push(discoveryCapped[di++]);
    } else if (pi < personalPool.length) {
      finalFeed.push(personalPool[pi++]);
    } else if (di < discoveryCapped.length) {
      finalFeed.push(discoveryCapped[di++]);
    }
    slot++;
  }

  return finalFeed;
}

/**
 * Keyword-based discover — lets users type unusual terms and find matching films
 */
export async function discoverByKeyword(
  keywordIds: number[],
  page = 1,
): Promise<DiscoverResponse> {
  if (keywordIds.length === 0) return { results: [], page: 1, total_pages: 0, total_results: 0 };

  const params = new URLSearchParams({
    api_key: API_KEY,
    language: 'en-US',
    watch_region: 'US',
    page: String(page),
    sort_by: 'vote_average.desc',
    include_adult: 'false',
    with_poster: 'true',
    with_keywords: keywordIds.join('|'),
    'vote_count.gte': '30',
  });

  const url = `${TMDB_BASE}/discover/movie?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) return { results: [], page: 1, total_pages: 0, total_results: 0 };
  const data = await res.json();

  const results: DiscoverItem[] = (data.results || [])
    .filter((r: any) => r.poster_path)
    .map((r: any): DiscoverItem => ({
      id: r.id,
      title: r.title || r.name || '',
      poster_path: r.poster_path,
      backdrop_path: r.backdrop_path,
      media_type: 'movie',
      year: r.release_date ? parseInt(r.release_date.substring(0, 4)) : null,
      vote_average: r.vote_average || 0,
      vote_count: r.vote_count || 0,
      overview: r.overview || '',
      genre_ids: r.genre_ids || [],
    }));

  return {
    results,
    page: data.page,
    total_pages: Math.min(data.total_pages || 0, 500),
    total_results: data.total_results || 0,
  };
}

/**
 * Main discover function — routes to trending or discover based on params
 */
export async function discoverContent(params: DiscoverParams): Promise<DiscoverResponse> {
  const { mediaType, genre, sourceFilter, page } = params;
  const freeOnly = sourceFilter === 'free';
  const isBadMovies = genre === -1;
  const isTrending = genre === 0;

  if (isTrending) {
    // On first page, occasionally pull from deeper pages (2-3) so it's
    // not always the same 20 theatrical releases dominating the view
    const effectivePage = page === 1 && Math.random() < 0.3
      ? 1 + Math.floor(Math.random() * 3)
      : page;
    return fetchTrending(mediaType === 'all' ? 'all' : mediaType, effectivePage);
  }

  // For "all" media type, fetch both and merge
  if (mediaType === 'all') {
    const [movies, tv] = await Promise.all([
      fetchDiscover('movie', page, isBadMovies ? null : genre, isBadMovies, freeOnly),
      fetchDiscover('tv', page, isBadMovies ? null : genre, isBadMovies, freeOnly),
    ]);

    const merged = [...movies.results, ...tv.results]
      .sort((a, b) => {
        if (isBadMovies) return a.vote_average - b.vote_average;
        return b.vote_average - a.vote_average;
      })
      .slice(0, 20);

    return {
      results: merged,
      page,
      total_pages: Math.min(movies.total_pages, tv.total_pages, 500),
      total_results: movies.total_results + tv.total_results,
    };
  }

  return fetchDiscover(mediaType, page, isBadMovies ? null : genre, isBadMovies, freeOnly);
}
