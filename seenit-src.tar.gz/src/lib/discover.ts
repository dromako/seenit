/**
 * TMDB Discover API Client
 * Powers the Browse Mode — continuous movie/TV discovery feed
 */

const TMDB_BASE = 'https://api.themoviedb.org/3';
const API_KEY = import.meta.env.VITE_TMDB_API_KEY;

export interface DiscoverItem {
  id: number;
  title: string;
  poster_path: string | null;
  backdrop_path: string | null;
  media_type: 'movie' | 'tv';
  year: number | null;
  vote_average: number;
  vote_count: number;
  overview: string;
  genre_ids: number[];
}

export interface DiscoverResponse {
  results: DiscoverItem[];
  page: number;
  total_pages: number;
  total_results: number;
}

/** Mood-based browse tabs — cinephile picks by feeling, not genre label */
export const BROWSE_GENRES = [
  { id: 0, name: 'Trending' },
  { id: 27, name: 'Get Scared' },
  { id: 35, name: 'Make Me Laugh' },
  { id: 18, name: 'Feel Something' },
  { id: 878, name: 'Mind-Bending' },
  { id: 99, name: 'Learn Something' },
  { id: 28, name: 'Adrenaline' },
  { id: 53, name: 'On the Edge' },
  { id: 10749, name: 'Fall in Love' },
  { id: -1, name: 'So Bad It\'s Good' },
];

// US free/ad-supported provider IDs (TMDB watch_provider IDs)
// Tubi=73, Pluto=300, Peacock(free)=386, Plex=538, Kanopy=191
const FREE_PROVIDER_IDS = '73|300|386|538|191';

export type MediaFilter = 'all' | 'movie' | 'tv';
export type SourceFilter = 'all' | 'free';

interface DiscoverParams {
  mediaType: MediaFilter;
  genre: number;         // 0 = trending, -1 = bad movies
  sourceFilter: SourceFilter;
  page: number;
}

// Family (10751) and Kids (10762) genre IDs — not blocked, but held to a
// higher bar. Spirited Away / Inside Out / Fantastic Mr. Fox belong in the
// feed; Paw Patrol: The Movie does not. The test: would a childless adult
// cinephile enjoy this? High vote count + high rating = yes.
const FAMILY_GENRE = 10751;
const KIDS_GENRE = 10762;
const KIDS_VOTE_FLOOR = 500;   // Must be widely seen, not just well-rated by parents
const KIDS_RATING_FLOOR = 7.5; // Must be genuinely excellent, not just "good for kids"

// Music (10402) — concerts, music documentaries, concert films. The vast
// majority are fan-service with inflated ratings from stans. Stop Making
// Sense and Amadeus pass; a random K-pop concert film does not.
const MUSIC_GENRE = 10402;
const MUSIC_VOTE_FLOOR = 800;
const MUSIC_RATING_FLOOR = 7.5;

/**
 * Quality gate: filters out content with built-in audiences that inflate
 * ratings regardless of actual quality. Every category here follows the
 * same DTV pattern: a captive audience rates en masse, making the content
 * look acclaimed when it's actually niche. We let through titles with
 * genuine broad critical engagement (high vote count + high average).
 *
 * Categories filtered:
 * - Children's/family (rated 10/10 by parents of a narrow age group)
 * - Faith-based/DTV religious (rated 10/10 by congregations)
 * - Music/concerts (rated 10/10 by fanbases of a specific artist)
 * - Reality TV / vanity projects / sports docs (low-effort, built-in audience)
 *
 * The test for all: would a serious cinephile with no prior attachment
 * to the subject enjoy this as a *film experience*?
 */
function passesQualityGate(
  genreIds: number[],
  voteCount: number,
  voteAvg: number,
  title: string,
  overview: string,
): boolean {
  // ── Kids/Family filter ──
  const isKidsFamily = genreIds.includes(FAMILY_GENRE) || genreIds.includes(KIDS_GENRE);
  if (isKidsFamily && (voteCount < KIDS_VOTE_FLOOR || voteAvg < KIDS_RATING_FLOOR)) {
    return false;
  }

  // ── Music / concert film filter ──
  // Fan-filmed concerts, K-pop docs, artist vanity projects inflate via
  // stans. Stop Making Sense, Amadeus, Whiplash pass the bar easily.
  const isMusic = genreIds.includes(MUSIC_GENRE);
  if (isMusic && (voteCount < MUSIC_VOTE_FLOOR || voteAvg < MUSIC_RATING_FLOOR)) {
    return false;
  }

  // ── Text-based signal detection ──
  const lowerTitle = title.toLowerCase();
  const lowerOverview = overview.toLowerCase();
  const text = `${lowerTitle} ${lowerOverview}`;

  // ── DTV / faith-based / religious propaganda filter ──
  const faithSignals = [
    'faith', 'prayer', 'prayers', 'praying', 'god\'s', 'gods plan',
    'christian', 'church congregation', 'gospel', 'scripture',
    'bible study', 'biblical', 'testament', 'sermon',
    'pureflix', 'pure flix', 'affirm films',
    'missionary', 'salvation', 'rapture', 'prophecy fulfil',
    'christian film', 'faith-based', 'faith based',
  ];

  const hasFaithSignal = faithSignals.some(s => text.includes(s));

  if (hasFaithSignal && voteCount < 500) {
    return false;
  }
  if (hasFaithSignal && voteAvg >= 8.5 && voteCount < 200) {
    return false;
  }

  // ── Concert / live performance filter ──
  // Catches music content even when genre tag is missing. The Talking Heads,
  // Prince, or Beyoncé concert films that genuinely move cinema forward will
  // have the vote counts to pass. A random EDM festival recording will not.
  const concertSignals = [
    'concert', 'live performance', 'live tour', 'world tour',
    'stadium tour', 'farewell tour', 'reunion tour',
    'concert film', 'concert special', 'live at',
    'music video', 'music special', 'unplugged',
  ];
  const hasConcertSignal = concertSignals.some(s => text.includes(s));
  if (hasConcertSignal && voteCount < 500) {
    return false;
  }

  // ── Reality TV / competition / vanity project filter ──
  // Reality shows and their film spinoffs have built-in audiences that
  // rate 10/10 regardless of quality. Keeping the vote floor at 300 lets
  // genuinely acclaimed docs about these worlds through (e.g. Paris Is
  // Burning) while filtering out "Real Housewives: The Movie".
  const realitySignals = [
    'reality show', 'reality tv', 'reality series', 'reality competition',
    'big brother', 'the bachelor', 'love island', 'survivor',
    'talent show', 'talent competition', 'audition',
    'vanity project', 'self-funded', 'crowdfunded film',
  ];
  const hasRealitySignal = realitySignals.some(s => text.includes(s));
  if (hasRealitySignal && voteCount < 300) {
    return false;
  }

  // ── Sports / athletic event filter ──
  // ESPN 30 for 30 and Hoop Dreams pass easily. A random MMA highlight
  // reel or bowling championship does not. The bar: it must work as a
  // *film*, not just as sports coverage.
  const sportsSignals = [
    'championship game', 'championship match', 'championship fight',
    'playoff', 'super bowl', 'world cup final',
    'boxing match', 'mma fight', 'ufc', 'wrestling event',
    'highlight reel', 'season recap', 'game highlights',
    'sports special', 'espn', 'match day',
  ];
  const hasSportsSignal = sportsSignals.some(s => text.includes(s));
  if (hasSportsSignal && voteCount < 400) {
    return false;
  }

  // ── Ultra-low-vote filter (catches trailers, shorts, and DTV slop) ──
  // Anything with <20 votes is almost certainly not a real theatrical
  // release or notable direct-to-streaming title. This catches things
  // like "AJ Zombies!" that are effectively trailers or student films
  // indexed by TMDB but not real movies anyone should discover.
  if (voteCount < 20) {
    return false;
  }

  return true;
}

/**
 * Fetch trending content from TMDB
 */
async function fetchTrending(
  mediaType: 'movie' | 'tv' | 'all',
  page: number,
): Promise<DiscoverResponse> {
  const type = mediaType === 'all' ? 'all' : mediaType;
  const url = `${TMDB_BASE}/trending/${type}/week?api_key=${API_KEY}&page=${page}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Trending fetch failed: ${res.status}`);
  const data = await res.json();

  const results: DiscoverItem[] = data.results.map((r: any) => ({
    id: r.id,
    title: r.title || r.name || '',
    poster_path: r.poster_path,
    backdrop_path: r.backdrop_path,
    media_type: r.media_type || mediaType,
    year: r.release_date
      ? parseInt(r.release_date.substring(0, 4))
      : r.first_air_date
        ? parseInt(r.first_air_date.substring(0, 4))
        : null,
    vote_average: r.vote_average || 0,
    vote_count: r.vote_count || 0,
    overview: r.overview || '',
    genre_ids: r.genre_ids || [],
  }));

  // Smart kids/family filter — keeps genuinely great films (Ghibli, Pixar best),
  // filters out narrow-audience kids content that inflates ratings
  const filtered = results.filter(r =>
    passesQualityGate(r.genre_ids, r.vote_count, r.vote_average, r.title, r.overview)
  );

  return {
    results: filtered,
    page: data.page,
    total_pages: Math.min(data.total_pages, 500),
    total_results: data.total_results,
  };
}

/**
 * Fetch from TMDB Discover endpoint (movies or TV)
 */
async function fetchDiscover(
  type: 'movie' | 'tv',
  page: number,
  genreId: number | null,
  badMovies: boolean,
  freeOnly: boolean
): Promise<DiscoverResponse> {
  // For genre tabs: sort by quality (vote_average) with a vote floor so we
  // surface great catalog films, not just whatever's in theaters this week.
  // For trending (genreId=null, !badMovies): keep popularity for recency.
  const defaultSort = genreId ? 'vote_average.desc' : 'popularity.desc';

  const params = new URLSearchParams({
    api_key: API_KEY,
    language: 'en-US',
    watch_region: 'US',
    page: String(page),
    sort_by: badMovies ? 'vote_average.asc' : defaultSort,
    include_adult: 'false',
  });

  if (genreId && genreId > 0) {
    params.set('with_genres', String(genreId));
    // Quality floor: enough votes to be credible, high enough rating to be worth watching
    params.set('vote_count.gte', '150');
    params.set('vote_average.gte', '6.0');
  }

  if (badMovies) {
    params.set('vote_average.lte', '4.5');
    params.set('vote_count.gte', '50');     // enough votes to be "known bad"
    params.set('sort_by', 'vote_count.desc'); // popular bad movies first
  }

  if (freeOnly) {
    params.set('with_watch_monetization_types', 'free|ads');
    params.set('with_watch_providers', FREE_PROVIDER_IDS);
  }

  // Ensure we get things with posters
  params.set('with_poster', 'true');

  const url = `${TMDB_BASE}/discover/${type}?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Discover fetch failed: ${res.status}`);
  const data = await res.json();

  const results: DiscoverItem[] = data.results.map((r: any) => ({
    id: r.id,
    title: r.title || r.name || '',
    poster_path: r.poster_path,
    backdrop_path: r.backdrop_path,
    media_type: type,
    year: r.release_date
      ? parseInt(r.release_date.substring(0, 4))
      : r.first_air_date
        ? parseInt(r.first_air_date.substring(0, 4))
        : null,
    vote_average: r.vote_average || 0,
    vote_count: r.vote_count || 0,
    overview: r.overview || '',
    genre_ids: r.genre_ids || [],
  }));

  return {
    results: results
      .filter(r => r.poster_path)
      .filter(r => passesQualityGate(r.genre_ids, r.vote_count, r.vote_average, r.title, r.overview)),
    page: data.page,
    total_pages: Math.min(data.total_pages, 500),
    total_results: data.total_results,
  };
}

// ── Curated feed helpers for the homepage rows ──

/** Pick a random element from an array */
function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

// ── The Bookshop: Phantom Patron system ──
//
// The browse feed is modeled as a used bookshop. 60% of the shelves are
// stocked for the viewer (personal rows). 40% belong to "phantom patrons" —
// imaginary cinephiles whose taste overlaps with the viewer's but extends in
// directions they haven't explored. Patrons rotate in and out: some become
// regulars who appear for weeks, others drift through once.
//
// The viewer never sees patron names directly — they see evocative shelf
// labels ("Shadows and smoke", "Postcards from far away") that feel like
// someone interesting left them there.
//
// Each patron maps to specific TMDB query parameters. Patrons are ATTRACTED
// by the viewer's engagement data (horror fans attract the Night Owl) but
// they also bring adjacent genres the viewer hasn't tried.

import type { TasteVector } from './storage';
import { pickActivePatrons } from './storage';

/**
 * Translate a patron's TasteVector into TMDB Discover API params.
 * This is where the abstract vector becomes a concrete query.
 */
function vectorToTMDBParams(v: TasteVector): Record<string, string> {
  const params: Record<string, string> = {
    without_genres: '10402,10770', // always exclude music, TV movie
  };

  // Genre filter
  if (v.genreSecondary) {
    params['with_genres'] = `${v.genrePrimary},${v.genreSecondary}`;
  } else {
    params['with_genres'] = String(v.genrePrimary);
  }

  // Decade window
  const startYear = v.decadeCenter - v.decadeSpread;
  const endYear = Math.min(new Date().getFullYear(), v.decadeCenter + v.decadeSpread);
  if (startYear > 1950) {
    params['primary_release_date.gte'] = `${startYear}-01-01`;
  }
  params['primary_release_date.lte'] = `${endYear}-12-31`;

  // Vote count bounds (obscurity control)
  params['vote_count.gte'] = String(v.voteFloor);
  if (v.voteCeiling) {
    params['vote_count.lte'] = String(v.voteCeiling);
  }

  // Rating floor
  params['vote_average.gte'] = String(v.ratingFloor);

  // Language
  if (v.language !== 'any') {
    params['with_original_language'] = v.language;
  }

  // Mood keywords (if any)
  if (v.moodKeywords.length > 0) {
    params['with_keywords'] = v.moodKeywords.join('|');
  }

  return params;
}

/**
 * Fetch items from a TMDB list. Returns DiscoverItems from a random page
 * of the list for variety. Falls back gracefully on failure.
 */
// fetchCuratedList removed in Session 12 — was only used by list-based patron archetypes

export interface CuratedRow {
  id: string;
  title: string;
  subtitle: string;
  reasonTaste: string;  // why this aligns with their viewing history
  reasonMood: string;   // why this feels right for them *right now*
  items: DiscoverItem[];
}

// DECADES constant removed in Session 12 — decade ranges now derived from patron TasteVector

const SPOTLIGHT_GENRES = [
  { id: 99, name: 'Documentary' },
  { id: 878, name: 'Sci-Fi' },
  { id: 27, name: 'Horror' },
  { id: 80, name: 'Crime' },
  { id: 10752, name: 'War' },
  { id: 36, name: 'History' },
  { id: 16, name: 'Animation' },
  { id: 37, name: 'Western' },
  { id: 9648, name: 'Mystery' },
  { id: 14, name: 'Fantasy' },
  { id: 10749, name: 'Romance' },
  { id: 53, name: 'Thriller' },
];

// (World language selection is now handled dynamically by patron TasteVectors
// via the language field — no fixed language list needed.)

/**
 * Fetch a single curated discover row
 */
async function fetchCuratedRow(
  sortBy: string,
  extraParams: Record<string, string>,
  limit = 12,
): Promise<DiscoverItem[]> {
  // Randomise across pages 1-20 for deep variety — never the same feed twice
  const page = 1 + Math.floor(Math.random() * 20);

  const params = new URLSearchParams({
    api_key: API_KEY,
    language: 'en-US',
    watch_region: 'US',
    page: String(page),
    sort_by: sortBy,
    include_adult: 'false',
    with_poster: 'true',
    ...extraParams,
  });

  const url = `${TMDB_BASE}/discover/movie?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) return [];
  const data = await res.json();

  const items = (data.results || [])
    .filter((r: any) => r.poster_path)
    .map((r: any): DiscoverItem => ({
      id: r.id,
      title: r.title || r.name || '',
      poster_path: r.poster_path,
      backdrop_path: r.backdrop_path,
      media_type: 'movie',
      year: r.release_date ? parseInt(r.release_date.substring(0, 4)) : null,
      vote_average: r.vote_average || 0,
      vote_count: r.vote_count || 0,
      overview: r.overview || '',
      genre_ids: r.genre_ids || [],
    }))
    // Smart kids/family filter — keeps genuinely great films (Ghibli, Pixar best),
    // filters out narrow-audience kids content that inflates ratings
    .filter((r: DiscoverItem) => passesQualityGate(r.genre_ids, r.vote_count, r.vote_average, r.title, r.overview))
    .slice(0, limit);

  // Shuffle results within the row for extra unpredictability
  return items.sort(() => Math.random() - 0.5);
}

/**
 * Build the full curated homepage feed.
 * Returns up to 9 themed rows, each with ~12 posters.
 * Randomises decade, genre, language, and genre-mash combos each load
 * so it never feels stale. Rows are shuffled (first row pinned).
 */
export interface VibeClusterInput {
  label: string;
  subtitle: string;
  keywordIds: number[];
}

export interface ViewerAffinities {
  topGenres?: number[];   // genre IDs the viewer taps most
  topDecade?: string;     // e.g. "80s"
  vibes?: VibeClusterInput[];  // personal keyword clusters to surface
}

export interface MoodInput {
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'latenight';
  dayName: string;
  isWeekend: boolean;
  recentTone: 'heavy' | 'light' | 'intense' | 'mixed' | 'unknown';
  hasHistory: boolean;
}

export async function getCuratedFeed(affinities?: ViewerAffinities, mood?: MoodInput): Promise<CuratedRow[]> {
  const hasAffinities = affinities && (affinities.topGenres?.length || affinities.topDecade);
  const topGenres = affinities?.topGenres || [];

  // ── Personal shelf parameters ──
  // Genre leans 40% toward their favourite (prevents "More Horror" every load)
  let genre: typeof SPOTLIGHT_GENRES[number];
  let genreIsPersonal = false;
  if (hasAffinities && affinities?.topGenres?.length) {
    const match = SPOTLIGHT_GENRES.find(g => affinities.topGenres!.includes(g.id));
    genre = match && Math.random() < 0.4 ? match : pickRandom(SPOTLIGHT_GENRES);
    genreIsPersonal = genre === match;
  } else {
    genre = pickRandom(SPOTLIGHT_GENRES);
  }

  // Taste genres for "your shelf" row (1-2 genres, 30% full surprise)
  let tasteGenres: string | null = null;
  if (hasAffinities && affinities?.topGenres?.length && Math.random() > 0.3) {
    const shuffledTaste = [...affinities.topGenres].sort(() => Math.random() - 0.5);
    tasteGenres = shuffledTaste.slice(0, 1 + Math.floor(Math.random() * 2)).join(',');
  }

  // Personal vibes
  const vibes = affinities?.vibes || [];

  // ── Pick phantom patrons for this load ──
  // 3-4 dynamic patrons are "in the shop" — spawned from the viewer's
  // engagement clusters, mutated to explore adjacent taste territory.
  const activePatrons = pickActivePatrons(topGenres, 4);

  // ── Fetch all rows in parallel ──
  // Personal shelves (your side of the bookshop)
  const personalFetches = [
    // Recent Critical Darlings — last 3 years, randomise sort between
    // rating and popularity so different films surface each load
    fetchCuratedRow(Math.random() < 0.5 ? 'vote_average.desc' : 'popularity.desc', {
      'primary_release_date.gte': `${new Date().getFullYear() - 3}-01-01`,
      'vote_count.gte': '200',
      'vote_average.gte': '6.0',
      without_genres: '10402,10770',
    }),
    // Your shelf — taste-matched or acclaimed-but-overlooked
    tasteGenres
      ? fetchCuratedRow('vote_average.desc', {
          with_genres: tasteGenres,
          'vote_count.gte': '50',
          'vote_count.lte': '1500',
          'vote_average.gte': '6.0',
          without_genres: '10402,10770',
        })
      : fetchCuratedRow('vote_average.desc', {
          'vote_count.gte': '300',
          'vote_count.lte': '2000',
          'vote_average.gte': '6.5',
          without_genres: '10402,10770',
        }),
    // Genre shelf — your genre or a surprise genre
    fetchCuratedRow(Math.random() < 0.6 ? 'vote_average.desc' : 'popularity.desc', {
      with_genres: String(genre.id),
      'vote_count.gte': '200',
      'vote_average.gte': '6.0',
      without_genres: '10402,10770',
      ...(Math.random() < 0.5 ? { 'primary_release_date.gte': `${new Date().getFullYear() - 30}-01-01` } : {}),
    }),
    // Personal vibe keyword rows
    ...vibes.map(vibe =>
      fetchCuratedRow('vote_average.desc', {
        with_keywords: vibe.keywordIds.join('|'),
        'vote_count.gte': '10',
      })
    ),
  ];

  // Patron shelves (the other people in the bookshop)
  // Each patron's TasteVector is translated into TMDB query params on the fly.
  const patronFetches = activePatrons.map(patron => {
    const query = vectorToTMDBParams(patron.vector);
    return fetchCuratedRow('vote_average.desc', query);
  });

  const results = await Promise.allSettled([...personalFetches, ...patronFetches]);

  // Unwrap — failed fetches become empty arrays
  const unwrap = (r: PromiseSettledResult<DiscoverItem[]>): DiscoverItem[] =>
    r.status === 'fulfilled' ? r.value : [];

  const personalResults = results.slice(0, personalFetches.length).map(unwrap);
  const patronResults = results.slice(personalFetches.length).map(unwrap);

  // Destructure personal results
  const [recentCritical, yourShelf, genreShelf, ...vibeResults] = personalResults;

  // ── Mood context for text ──
  const t = mood?.timeOfDay || 'evening';
  const tone = mood?.recentTone || 'unknown';
  const dayN = mood?.dayName || '';
  const wknd = mood?.isWeekend ?? false;
  const knows = mood?.hasHistory ?? false;

  function timeFeel(evening: string, late: string, afternoon: string, fallback: string): string {
    if (t === 'latenight') return late;
    if (t === 'evening') return evening;
    if (t === 'afternoon') return afternoon;
    return fallback;
  }

  function toneAware(afterHeavy: string, afterIntense: string, afterLight: string, neutral: string): string {
    if (!knows) return neutral;
    if (tone === 'heavy') return afterHeavy;
    if (tone === 'intense') return afterIntense;
    if (tone === 'light') return afterLight;
    return neutral;
  }

  // ── Build personal rows (Your side of the bookshop) ──
  const personalPool: CuratedRow[] = [];

  if (recentCritical.length > 0) {
    personalPool.push({
      id: 'recent-critical',
      title: 'Just arrived',
      subtitle: 'The new ones everyone\'s talking about',
      reasonTaste: 'New and acclaimed',
      reasonMood: timeFeel('Fresh off the shelf', 'Still warm from the press', 'The latest arrivals', 'Just in'),
      items: recentCritical,
    });
  }
  if (yourShelf.length > 0) {
    personalPool.push({
      id: 'for-you',
      title: tasteGenres ? 'Your shelf' : 'Acclaimed & overlooked',
      subtitle: tasteGenres ? 'Based on everything you\'ve been watching' : 'Great films that slipped through the cracks',
      reasonTaste: tasteGenres ? 'Matched to your actual taste' : 'Acclaimed but not obvious',
      reasonMood: tasteGenres
        ? toneAware('Something that gets you', 'Tuned to your wavelength', 'More of that energy', 'Chosen for you')
        : timeFeel('Worth discovering tonight', 'Rewards late-night attention', 'Something you haven\'t heard of', 'Quietly brilliant'),
      items: yourShelf,
    });
  }
  if (genreShelf.length > 0) {
    const gn = genre.name.toLowerCase();
    personalPool.push({
      id: 'genre',
      title: genreIsPersonal ? `More ${gn}` : `${genre.name} essentials`,
      subtitle: genreIsPersonal ? `You keep coming back` : 'The definitive shelf',
      reasonTaste: genreIsPersonal ? `You love ${gn}` : `Exploring ${gn}`,
      reasonMood: genreIsPersonal
        ? toneAware(`${gn} might be the shift you need`, `More ${gn} could hit right`, `Lean into the ${gn} mood`, `More of what you love`)
        : timeFeel(`A ${gn} night`, `Late-night ${gn}`, `${genre.name} for a ${dayN}`, `Try some ${gn}`),
      items: genreShelf,
    });
  }

  // Vibe rows
  vibes.forEach((vibe, i) => {
    const items = vibeResults[i] || [];
    if (items.length > 0) {
      personalPool.push({
        id: `vibe-${i}`,
        title: vibe.label,
        subtitle: vibe.subtitle,
        reasonTaste: 'Part of who you are',
        reasonMood: timeFeel(`A ${vibe.label.toLowerCase()} night`, `Late-night ${vibe.label.toLowerCase()}`, `${vibe.label} for a ${dayN}`, vibe.subtitle),
        items,
      });
    }
  });

  // ── Build patron rows (Other people's shelves) ──
  const patronPool: CuratedRow[] = [];

  activePatrons.forEach((patron, i) => {
    const items = patronResults[i] || [];
    if (items.length < 3) return; // patron shelf too thin — skip

    const isNiche = patron.vector.voteCeiling !== null && patron.vector.voteCeiling < 1000;

    patronPool.push({
      id: `patron-${patron.id}`,
      title: patron.shelfTitle,
      subtitle: patron.shelfNote,
      reasonTaste: `— ${patron.attribution}`,
      reasonMood: timeFeel(
        isNiche ? 'A shelf you haven\'t browsed before' : 'Someone left these for you',
        'The late crowd has good taste',
        wknd ? 'A weekend regular\'s picks' : 'Browse someone else\'s shelf',
        patron.shelfNote,
      ),
      items,
    });
  });

  // ── Deduplicate across all rows ──
  const allRows = [...personalPool, ...patronPool];
  const seen = new Set<number>();
  for (const row of allRows) {
    row.items = row.items.filter((item) => {
      if (seen.has(item.id)) return false;
      seen.add(item.id);
      return true;
    });
  }

  // Remove rows that got too thin after dedup
  const validPersonal = personalPool.filter(r => r.items.length >= 3);
  const validPatron = patronPool.filter(r => r.items.length >= 3);

  // ── 60/40 interleave: Your shelves / Someone else's shelves ──
  //
  // The bookshop metaphor: 60% of the shelves are stocked for you.
  // 40% belong to the other interesting people browsing right now.
  // Pattern: You, You, Them, You, Them, You, You, Them, ...

  const shuffle = <T,>(arr: T[]): T[] => {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  };

  // Pin "Just arrived" first if present, shuffle the rest
  const pinned = validPersonal.find(r => r.id === 'recent-critical');
  const restPersonal = shuffle(validPersonal.filter(r => r.id !== 'recent-critical'));
  const shuffledPatron = shuffle(validPatron);

  const finalFeed: CuratedRow[] = [];
  if (pinned) finalFeed.push(pinned);

  let pi = 0;
  let di = 0;
  let slot = pinned ? 1 : 0;

  while (pi < restPersonal.length || di < shuffledPatron.length) {
    // Every 3rd slot is a patron shelf (P, P, D pattern)
    const isPatronSlot = slot % 3 === 2;

    if (isPatronSlot && di < shuffledPatron.length) {
      finalFeed.push(shuffledPatron[di++]);
    } else if (pi < restPersonal.length) {
      finalFeed.push(restPersonal[pi++]);
    } else if (di < shuffledPatron.length) {
      finalFeed.push(shuffledPatron[di++]);
    }
    slot++;
  }

  return finalFeed;
}

/**
 * Keyword-based discover — lets users type unusual terms and find matching films
 */
export async function discoverByKeyword(
  keywordIds: number[],
  page = 1,
): Promise<DiscoverResponse> {
  if (keywordIds.length === 0) return { results: [], page: 1, total_pages: 0, total_results: 0 };

  const params = new URLSearchParams({
    api_key: API_KEY,
    language: 'en-US',
    watch_region: 'US',
    page: String(page),
    sort_by: 'vote_average.desc',
    include_adult: 'false',
    with_poster: 'true',
    with_keywords: keywordIds.join('|'),
    'vote_count.gte': '30',
  });

  const url = `${TMDB_BASE}/discover/movie?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) return { results: [], page: 1, total_pages: 0, total_results: 0 };
  const data = await res.json();

  const results: DiscoverItem[] = (data.results || [])
    .filter((r: any) => r.poster_path)
    .map((r: any): DiscoverItem => ({
      id: r.id,
      title: r.title || r.name || '',
      poster_path: r.poster_path,
      backdrop_path: r.backdrop_path,
      media_type: 'movie',
      year: r.release_date ? parseInt(r.release_date.substring(0, 4)) : null,
      vote_average: r.vote_average || 0,
      vote_count: r.vote_count || 0,
      overview: r.overview || '',
      genre_ids: r.genre_ids || [],
    }));

  return {
    results,
    page: data.page,
    total_pages: Math.min(data.total_pages || 0, 500),
    total_results: data.total_results || 0,
  };
}

/**
 * Main discover function — routes to trending or discover based on params
 */
export async function discoverContent(params: DiscoverParams): Promise<DiscoverResponse> {
  const { mediaType, genre, sourceFilter, page } = params;
  const freeOnly = sourceFilter === 'free';
  const isBadMovies = genre === -1;
  const isTrending = genre === 0;

  if (isTrending) {
    // On first page, occasionally pull from deeper pages (2-3) so it's
    // not always the same 20 theatrical releases dominating the view
    const effectivePage = page === 1 && Math.random() < 0.3
      ? 1 + Math.floor(Math.random() * 3)
      : page;
    return fetchTrending(mediaType === 'all' ? 'all' : mediaType, effectivePage);
  }

  // For "all" media type, fetch both and merge
  if (mediaType === 'all') {
    const [movies, tv] = await Promise.all([
      fetchDiscover('movie', page, isBadMovies ? null : genre, isBadMovies, freeOnly),
      fetchDiscover('tv', page, isBadMovies ? null : genre, isBadMovies, freeOnly),
    ]);

    const merged = [...movies.results, ...tv.results]
      .sort((a, b) => {
        if (isBadMovies) return a.vote_average - b.vote_average;
        return b.vote_average - a.vote_average;
      })
      .slice(0, 20);

    return {
      results: merged,
      page,
      total_pages: Math.min(movies.total_pages, tv.total_pages, 500),
      total_results: movies.total_results + tv.total_results,
    };
  }

  return fetchDiscover(mediaType, page, isBadMovies ? null : genre, isBadMovies, freeOnly);
}
