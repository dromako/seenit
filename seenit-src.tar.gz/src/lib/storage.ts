/**
 * Local Storage and Caching
 * Manages localStorage caching, lookups, and OAuth tokens
 */

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttlMinutes: number;
}

interface LookupData {
  tmdbId: number;
  title: string;
  year?: number;
  posterPath?: string;
  mediaType: 'movie' | 'tv';
  searchedAt: number;
}

// RecentLookup type imported from types
import type { RecentLookup } from '../types';

interface TraktToken {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  token_type: string;
}

const CACHE_PREFIX = 'seenit_cache_';
const LOOKUP_PREFIX = 'seenit_lookup_';
const RECENT_LOOKUPS_KEY = 'seenit_recent_lookups';
const NOTES_PREFIX = 'seenit_notes_';
const TRAKT_TOKEN_KEY = 'seenit_trakt_token';

// ── Storage budget ──
// localStorage is typically 5-10 MB. We budget 3 MB for SeenIt to leave
// headroom for other origins sharing the same limit on some browsers.
const STORAGE_BUDGET_BYTES = 3 * 1024 * 1024;   // 3 MB
const MAX_LOOKUPS = 150;   // cap lookup entries (LRU eviction)
const MAX_ENGAGEMENT_GENRES = 40; // cap genre tally keys

/**
 * Get a value from cache (with TTL checking)
 */
export function cacheGet<T>(key: string): T | null {
  try {
    const stored = localStorage.getItem(`${CACHE_PREFIX}${key}`);
    if (!stored) return null;

    const entry = JSON.parse(stored) as CacheEntry<T>;
    const now = Date.now();
    const ageMinutes = (now - entry.timestamp) / 1000 / 60;

    // Check if expired
    if (ageMinutes > entry.ttlMinutes) {
      localStorage.removeItem(`${CACHE_PREFIX}${key}`);
      return null;
    }

    return entry.data;
  } catch (error) {
    console.error('Error reading cache:', error);
    return null;
  }
}

/**
 * Set a value in cache with TTL.
 * On quota error, evicts expired entries + oldest lookups, then retries once.
 */
export function cacheSet<T>(key: string, value: T, ttlMinutes = 60): void {
  const entry: CacheEntry<T> = {
    data: value,
    timestamp: Date.now(),
    ttlMinutes,
  };
  const raw = JSON.stringify(entry);

  try {
    localStorage.setItem(`${CACHE_PREFIX}${key}`, raw);
  } catch {
    // Likely QuotaExceededError — free space and retry
    console.warn('[storage] write failed, evicting to free space...');
    pruneExpiredCache();
    evictOldestLookups(Math.max(20, MAX_LOOKUPS / 2)); // drop oldest half
    try {
      localStorage.setItem(`${CACHE_PREFIX}${key}`, raw);
    } catch (err2) {
      console.error('[storage] write still failed after eviction:', err2);
    }
  }
}

/**
 * Get cached lookup data for a TMDB ID
 */
export function getCachedLookup(tmdbId: number): LookupData | null {
  try {
    const stored = localStorage.getItem(`${LOOKUP_PREFIX}${tmdbId}`);
    if (!stored) return null;

    return JSON.parse(stored) as LookupData;
  } catch (error) {
    console.error('Error reading cached lookup:', error);
    return null;
  }
}

/**
 * Cache lookup data for a TMDB ID.
 * Enforces MAX_LOOKUPS cap — evicts oldest entries when full.
 */
export function setCachedLookup(tmdbId: number, data: LookupData): void {
  try {
    // Enforce cap before writing
    evictOldestLookups(MAX_LOOKUPS - 1); // make room for this one
    localStorage.setItem(`${LOOKUP_PREFIX}${tmdbId}`, JSON.stringify(data));
  } catch {
    // Quota error — drop half the lookups and retry
    evictOldestLookups(Math.max(20, MAX_LOOKUPS / 2));
    try {
      localStorage.setItem(`${LOOKUP_PREFIX}${tmdbId}`, JSON.stringify(data));
    } catch { /* give up silently */ }
  }
}

/**
 * Get list of recent lookups (last 20)
 */
export function getRecentLookups(): RecentLookup[] {
  try {
    const stored = localStorage.getItem(RECENT_LOOKUPS_KEY);
    if (!stored) return [];

    return JSON.parse(stored) as RecentLookup[];
  } catch (error) {
    console.error('Error reading recent lookups:', error);
    return [];
  }
}

/**
 * Add item to recent lookups
 */
export function addRecentLookup(item: {
  tmdbId: number;
  title: string;
  posterPath?: string;
  mediaType: 'movie' | 'tv';
}): void {
  try {
    const recent = getRecentLookups();

    // Remove if already exists (to move to front)
    const filtered = recent.filter((r) => r.tmdbId !== item.tmdbId);

    // Add new item at front
    const updated: RecentLookup[] = [
      {
        ...item,
        lastViewed: Date.now(),
      },
      ...filtered,
    ];

    // Keep only last 20
    const limited = updated.slice(0, 20);

    localStorage.setItem(RECENT_LOOKUPS_KEY, JSON.stringify(limited));
  } catch (error) {
    console.error('Error adding to recent lookups:', error);
  }
}

/**
 * Get personal notes for a title
 */
export function getNotes(tmdbId: number): string {
  try {
    const stored = localStorage.getItem(`${NOTES_PREFIX}${tmdbId}`);
    return stored || '';
  } catch (error) {
    console.error('Error reading notes:', error);
    return '';
  }
}

/**
 * Set personal notes for a title
 */
export function setNotes(tmdbId: number, notes: string): void {
  try {
    if (notes.trim()) {
      localStorage.setItem(`${NOTES_PREFIX}${tmdbId}`, notes);
    } else {
      localStorage.removeItem(`${NOTES_PREFIX}${tmdbId}`);
    }
  } catch (error) {
    console.error('Error writing notes:', error);
  }
}

/**
 * Get Trakt OAuth tokens
 */
export function getTraktToken(): TraktToken | null {
  try {
    const stored = localStorage.getItem(TRAKT_TOKEN_KEY);
    if (!stored) return null;

    return JSON.parse(stored) as TraktToken;
  } catch (error) {
    console.error('Error reading Trakt token:', error);
    return null;
  }
}

/**
 * Set Trakt OAuth tokens
 */
export function setTraktToken(token: TraktToken): void {
  try {
    localStorage.setItem(TRAKT_TOKEN_KEY, JSON.stringify(token));
  } catch (error) {
    console.error('Error writing Trakt token:', error);
  }
}

/**
 * Clear all SeenIt cache
 */
export function clearAllCache(): void {
  // PROTECT auth tokens — clearing cache should never deauth the user.
  // Without tokens, all Trakt writes silently fail and ratings are lost.
  const PROTECTED_KEYS = new Set([TRAKT_TOKEN_KEY, 'seenit_trakt_token_expiry']);
  try {
    const keys = Object.keys(localStorage);
    keys.forEach((key) => {
      if (key.startsWith('seenit_') && !PROTECTED_KEYS.has(key)) {
        localStorage.removeItem(key);
      }
    });
  } catch (error) {
    console.error('Error clearing cache:', error);
  }
}

/**
 * Invalidate browse-related caches so the next BrowsePage load
 * re-fetches Trakt status. Call after marking items watched/hidden/watchlisted.
 */
export function invalidateBrowseCaches(): void {
  try {
    localStorage.removeItem(`${CACHE_PREFIX}browse_hidden`);
    localStorage.removeItem(`${CACHE_PREFIX}browse_watched`);
    localStorage.removeItem(`${CACHE_PREFIX}browse_watchlist`);
    localStorage.removeItem(`${CACHE_PREFIX}curated_feed`);
    // Also clear library caches so My Picks reflects changes immediately
    localStorage.removeItem(`${CACHE_PREFIX}library_full`);
    localStorage.removeItem(`${CACHE_PREFIX}library_critics`);
    localStorage.removeItem(`${CACHE_PREFIX}library_unseen`);
  } catch { /* ignore */ }
}

// ── OMDB daily quota tracking ──
const OMDB_QUOTA_KEY = 'seenit_omdb_quota';
const OMDB_DAILY_LIMIT = 1000;

interface OmdbQuota { count: number; date: string }

function getOmdbQuota(): OmdbQuota {
  try {
    const raw = localStorage.getItem(OMDB_QUOTA_KEY);
    if (raw) {
      const q = JSON.parse(raw) as OmdbQuota;
      const today = new Date().toISOString().slice(0, 10);
      if (q.date === today) return q;
    }
  } catch { /* ignore */ }
  return { count: 0, date: new Date().toISOString().slice(0, 10) };
}

/** Increment the daily OMDB request counter. Returns false if quota exhausted. */
export function trackOmdbRequest(): boolean {
  const q = getOmdbQuota();
  if (q.count >= OMDB_DAILY_LIMIT) return false;
  q.count++;
  try { localStorage.setItem(OMDB_QUOTA_KEY, JSON.stringify(q)); } catch { /* ignore */ }
  return true;
}

/** Get remaining OMDB requests for today. */
export function getOmdbRemaining(): number {
  const q = getOmdbQuota();
  return Math.max(0, OMDB_DAILY_LIMIT - q.count);
}

// ── Negative-feedback & suppression ──
// Three layers of "less of this":
//   1. Soft negative: tap × on a poster → negative engagement event on its
//      genres/decade. decayScore is a sum so a -2 cancels a +2 over the
//      same 90-day half-life. Affects ranking, not visibility.
//   2. Shelf suppression: "Not this shelf" → that shelf id is blacklisted
//      for SUPPRESS_DAYS. The vector that produced it can still surface
//      from a different angle.
//   3. Genre suppression: stronger "Show me less crime" → that genre is
//      blocked from engagement shelves for SUPPRESS_DAYS but can still
//      surface via patrons.
// Negative weight is dominant — the engine learns from a dismissal twice
// as fast as from a tap.

const SUPPRESSED_KEY = 'seenit_suppressed';
const NEGATIVE_TAP_WEIGHT = -2;
const NEGATIVE_STRONG_WEIGHT = -5;
const SUPPRESS_DAYS_SHELF = 7;
const SUPPRESS_DAYS_GENRE = 14;

interface SuppressionData {
  shelves: Record<string, number>;
  genres: Record<number, number>;
}

function getSuppressions(): SuppressionData {
  try {
    const raw = localStorage.getItem(SUPPRESSED_KEY);
    if (raw) {
      const data = JSON.parse(raw) as SuppressionData;
      const now = Date.now();
      for (const id of Object.keys(data.shelves)) {
        if (data.shelves[id] < now) delete data.shelves[id];
      }
      for (const g of Object.keys(data.genres)) {
        if (data.genres[Number(g)] < now) delete data.genres[Number(g)];
      }
      return data;
    }
  } catch { /* ignore */ }
  return { shelves: {}, genres: {} };
}

function saveSuppressions(data: SuppressionData): void {
  try { localStorage.setItem(SUPPRESSED_KEY, JSON.stringify(data)); } catch { /* ignore */ }
}

export function suppressShelf(shelfId: string, days = SUPPRESS_DAYS_SHELF): void {
  const data = getSuppressions();
  data.shelves[shelfId] = Date.now() + days * 24 * 60 * 60 * 1000;
  saveSuppressions(data);
}

export function suppressGenre(genreId: number, days = SUPPRESS_DAYS_GENRE): void {
  const data = getSuppressions();
  data.genres[genreId] = Date.now() + days * 24 * 60 * 60 * 1000;
  saveSuppressions(data);
}

export function isShelfSuppressed(shelfId: string): boolean {
  return Date.now() < (getSuppressions().shelves[shelfId] || 0);
}

export function isGenreSuppressed(genreId: number): boolean {
  return Date.now() < (getSuppressions().genres[genreId] || 0);
}

export function listActiveSuppressions(): { shelves: string[]; genres: number[] } {
  const data = getSuppressions();
  return {
    shelves: Object.keys(data.shelves),
    genres: Object.keys(data.genres).map(Number),
  };
}

export function clearSuppression(kind: 'shelf' | 'genre', id: string | number): void {
  const data = getSuppressions();
  if (kind === 'shelf') delete data.shelves[String(id)];
  else delete data.genres[Number(id)];
  saveSuppressions(data);
}

// ── Row-vector monotony memory ──
// Persist the last N row vectors. Candidates that match too many axes
// of any row stored here within ROW_MEMORY_TTL_MS are rejected.

const ROW_MEMORY_KEY = 'seenit_recent_row_vectors';
const ROW_MEMORY_MAX = 14;
const ROW_MEMORY_TTL_MS = 5 * 24 * 60 * 60 * 1000;

export interface RowVector {
  genre: number | null;
  decade: string | null;
  mood: string | null;
  language: string | null;
  ts: number;
}

export function getRecentRowVectors(): RowVector[] {
  try {
    const raw = localStorage.getItem(ROW_MEMORY_KEY);
    if (raw) {
      const list = JSON.parse(raw) as RowVector[];
      const now = Date.now();
      return list.filter(v => now - v.ts < ROW_MEMORY_TTL_MS).slice(0, ROW_MEMORY_MAX);
    }
  } catch { /* ignore */ }
  return [];
}

export function recordShownRowVectors(vecs: Omit<RowVector, 'ts'>[]): void {
  try {
    const existing = getRecentRowVectors();
    const now = Date.now();
    const fresh = vecs.map(v => ({ ...v, ts: now }));
    const merged = [...fresh, ...existing].slice(0, ROW_MEMORY_MAX);
    localStorage.setItem(ROW_MEMORY_KEY, JSON.stringify(merged));
  } catch { /* ignore */ }
}

export function rowVectorSimilarity(a: Omit<RowVector, 'ts'>, b: Omit<RowVector, 'ts'>): number {
  let n = 0;
  if (a.genre !== null && a.genre === b.genre) n++;
  if (a.decade !== null && a.decade === b.decade) n++;
  if (a.mood !== null && a.mood === b.mood) n++;
  if (a.language !== null && a.language === b.language) n++;
  return n;
}

export function isRowTooMonotonous(candidate: Omit<RowVector, 'ts'>, threshold = 3): boolean {
  const recent = getRecentRowVectors();
  return recent.some(r => rowVectorSimilarity(candidate, r) >= threshold);
}

// ── Anchor candidate registry ──
// A flat list of real films the viewer has watched/rated, used to give
// each patron a "reason" to be in this library.

const ANCHOR_CANDIDATES_KEY = 'seenit_anchor_candidates';

export interface AnchorCandidate {
  title: string;
  year: number;
  imdbId?: string;
  tmdbId?: number;
  genres: number[];
  rating?: number;
}

export function setAnchorCandidates(items: AnchorCandidate[]): void {
  try {
    localStorage.setItem(ANCHOR_CANDIDATES_KEY, JSON.stringify(items.slice(0, 500)));
  } catch { /* ignore */ }
}

export function getAnchorCandidates(): AnchorCandidate[] {
  try {
    const raw = localStorage.getItem(ANCHOR_CANDIDATES_KEY);
    if (raw) return JSON.parse(raw) as AnchorCandidate[];
  } catch { /* ignore */ }
  return [];
}

/**
 * Prune expired cache entries + orphaned keys to free localStorage space.
 * Call this on app startup to prevent unbounded growth.
 */
export function pruneExpiredCache(): number {
  let removed = 0;
  try {
    const keys = Object.keys(localStorage);
    const now = Date.now();

    // 1. Remove expired TTL-based cache entries
    for (const key of keys) {
      if (!key.startsWith(CACHE_PREFIX)) continue;
      try {
        const raw = localStorage.getItem(key);
        if (!raw) continue;
        const entry = JSON.parse(raw) as CacheEntry<unknown>;
        const ageMin = (now - entry.timestamp) / 60000;
        if (ageMin > entry.ttlMinutes) {
          localStorage.removeItem(key);
          removed++;
        }
      } catch {
        // Corrupted entry — remove it
        localStorage.removeItem(key);
        removed++;
      }
    }

    // 2. Cap lookup entries (LRU by searchedAt)
    removed += evictOldestLookups(MAX_LOOKUPS);

    // 3. Cap engagement genre keys
    removed += trimEngagementGenres();

  } catch { /* ignore */ }
  return removed;
}

/**
 * Evict oldest lookup entries until count <= maxKeep.
 * Returns number of entries removed.
 */
function evictOldestLookups(maxKeep: number): number {
  let removed = 0;
  try {
    const keys = Object.keys(localStorage).filter(k => k.startsWith(LOOKUP_PREFIX));
    if (keys.length <= maxKeep) return 0;

    // Parse and sort by searchedAt (oldest first)
    const entries: { key: string; ts: number }[] = [];
    for (const key of keys) {
      try {
        const raw = localStorage.getItem(key);
        if (!raw) { localStorage.removeItem(key); removed++; continue; }
        const data = JSON.parse(raw) as LookupData;
        entries.push({ key, ts: data.searchedAt || 0 });
      } catch {
        localStorage.removeItem(key); removed++;
      }
    }

    entries.sort((a, b) => a.ts - b.ts); // oldest first
    const toRemove = entries.length - maxKeep;
    for (let i = 0; i < toRemove && i < entries.length; i++) {
      localStorage.removeItem(entries[i].key);
      removed++;
    }
  } catch { /* ignore */ }
  return removed;
}

/**
 * Trim genre engagement data to keep only the top N genres by count.
 * Prevents the tally object from growing unbounded.
 */
function trimEngagementGenres(): number {
  try {
    const raw = localStorage.getItem('seenit_genre_engagement');
    if (!raw) return 0;
    const data = JSON.parse(raw) as { genres: Record<string, number>; decades: Record<string, number>; updated: number };
    const genreEntries = Object.entries(data.genres);
    if (genreEntries.length <= MAX_ENGAGEMENT_GENRES) return 0;

    // Keep only the top N by count
    genreEntries.sort(([, a], [, b]) => b - a);
    const kept = Object.fromEntries(genreEntries.slice(0, MAX_ENGAGEMENT_GENRES));
    const trimmed = genreEntries.length - MAX_ENGAGEMENT_GENRES;
    data.genres = kept;
    localStorage.setItem('seenit_genre_engagement', JSON.stringify(data));
    return trimmed;
  } catch { return 0; }
}

/**
 * Get total bytes used by all SeenIt keys in localStorage.
 */
export function getStorageBytes(): number {
  try {
    let total = 0;
    for (const key of Object.keys(localStorage)) {
      if (!key.startsWith('seenit_')) continue;
      const val = localStorage.getItem(key);
      // Each char is ~2 bytes in JS strings (UTF-16)
      total += (key.length + (val?.length || 0)) * 2;
    }
    return total;
  } catch { return 0; }
}

// ── Engagement-derived personal shelves ──
//
// DESIGN PHILOSOPHY: No hardcoded themes. Shelves emerge from what the
// viewer actually watches, taps, and rates. The engagement system tracks
// genre × decade × keyword signals with time-decay. Personal shelves are
// generated from the top engagement clusters — never from a fixed list.
//
// Keyword engagement flows in from patron shelves: when the viewer picks
// something from a patron's shelf, that patron's mood keywords enter the
// keyword engagement pool. Over time, recurring keywords crystallize into
// personal shelf parameters. This is how identity-based shelves (queer
// cinema, political thrillers, etc.) emerge organically rather than being
// predefined.

const KEYWORD_ENGAGEMENT_KEY = 'seenit_keyword_engagement';

interface KeywordEngagementData {
  /** keyword_id → timestamped events for decay scoring */
  events: Record<number, EngagementEvent[]>;
  updated: number;
}

function getKeywordEngagement(): KeywordEngagementData {
  try {
    const raw = localStorage.getItem(KEYWORD_ENGAGEMENT_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return { events: {}, updated: Date.now() };
}

function saveKeywordEngagement(data: KeywordEngagementData): void {
  try {
    // Cap events per keyword to prevent unbounded growth
    for (const kid of Object.keys(data.events)) {
      const evts = data.events[Number(kid)];
      if (evts && evts.length > 40) data.events[Number(kid)] = evts.slice(0, 40);
    }
    localStorage.setItem(KEYWORD_ENGAGEMENT_KEY, JSON.stringify(data));
  } catch { /* ignore */ }
}

/**
 * Record keyword engagement — called when the viewer picks from a patron
 * shelf or when we detect keyword-relevant engagement. Keywords flow from
 * patron vectors into the viewer's personal keyword pool over time.
 */
export function recordKeywordEngagement(keywordIds: number[], weight: number): void {
  if (!keywordIds.length) return;
  const data = getKeywordEngagement();
  const evt: EngagementEvent = { weight, ts: Date.now() };
  for (const kid of keywordIds) {
    if (!data.events[kid]) data.events[kid] = [];
    data.events[kid].unshift(evt);
  }
  data.updated = Date.now();
  saveKeywordEngagement(data);
}

/**
 * Get the viewer's top keyword IDs by time-decayed engagement score.
 * These emerge from patron shelf picks — never hardcoded.
 */
export function getTopKeywords(limit = 6): { id: number; score: number }[] {
  const data = getKeywordEngagement();
  const scored: { id: number; score: number }[] = [];
  for (const [kid, events] of Object.entries(data.events)) {
    const s = decayScore(events);
    if (s > 0.1) scored.push({ id: Number(kid), score: s });
  }
  return scored.sort((a, b) => b.score - a.score).slice(0, limit);
}

/**
 * Engagement shelf spec — what the discovery engine needs to build a row.
 * Generated from engagement data, not stored. Labels are composed from
 * the shelf's vector properties using the label vocabulary.
 */
export interface EngagementShelf {
  id: string;
  /** TMDB query params for this shelf */
  query: Record<string, string>;
  /** Auto-generated evocative label */
  label: string;
  /** Subtitle / context line */
  subtitle: string;
  /** Whether this shelf represents a core engagement cluster */
  isCore: boolean;
  /** Vector axes used for monotony detection */
  vector: {
    genre: number | null;
    decade: string | null;
    mood: string | null;
  };
}

/**
 * Generate personal shelf specs from the viewer's engagement data.
 *
 * SAFETY CEILING: the shop should never feel more than 60% "safe."
 * Of the 4 shelves returned here:
 *   - Up to 2 are engagement-driven (your taste reflected back)
 *   - Up to 1 is keyword-driven (absorbed from patron picks)
 *   - Exactly 1 is a CONTRARIAN shelf: a genre you don't usually
 *     browse, paired with a decade you don't usually watch. The
 *     shopkeeper saying "I know you, and I think you're ready."
 *
 * Combined with "Just arrived" (safe) + wild card (surprise) + 4
 * patrons (3 adjacent + 1 stranger), this targets ~55-60% safe.
 */
export function getEngagementShelves(count = 4): EngagementShelf[] {
  const data = getEngagementData();
  const shelves: EngagementShelf[] = [];
  const usedGenres = new Set<number>();

  // ── Score all genres and decades ──
  const genreScores: { id: number; score: number }[] = [];
  if (data.genreEvents) {
    for (const [gid, events] of Object.entries(data.genreEvents)) {
      const s = decayScore(events);
      if (s > 0.5) genreScores.push({ id: Number(gid), score: s });
    }
  }
  genreScores.sort((a, b) => b.score - a.score);
  const engagedGenreIds = new Set(genreScores.map(g => g.id));

  const decadeScores: { decade: string; score: number }[] = [];
  if (data.decadeEvents) {
    for (const [dec, events] of Object.entries(data.decadeEvents)) {
      const s = decayScore(events);
      if (s > 0.3) decadeScores.push({ decade: dec, score: s });
    }
  }
  decadeScores.sort((a, b) => b.score - a.score);
  const topDecade = decadeScores[0]?.decade || null;

  // Safety cap: only 2 pure-engagement genre shelves (the other
  // slots go to keyword-driven + contrarian). This prevents the
  // feed from feeling like "More of what you already watch."
  const maxEngagement = 2;

  // ── Keyword-driven shelf (from patron picks) ──
  const topKeywords = getTopKeywords(4);
  const hasKeywordShelf = topKeywords.length >= 2 && topKeywords[0].score > 1;

  if (hasKeywordShelf) {
    const kwIds = topKeywords.slice(0, 3).map(k => k.id);
    let matchedMood = 'spectacle';
    let bestMoodOverlap = 0;
    for (const [mood, pool] of Object.entries(MOOD_POOLS)) {
      const overlap = kwIds.filter(k => pool.includes(k)).length;
      if (overlap > bestMoodOverlap) {
        bestMoodOverlap = overlap;
        matchedMood = mood;
      }
    }

    const moodLabels = LABEL_MOOD[matchedMood] || ['worth finding'];
    const label = moodLabels[Math.floor(Math.random() * moodLabels.length)];

    shelves.push({
      id: `kw-${matchedMood}`,
      query: {
        with_keywords: kwIds.join('|'),
        'vote_count.gte': '10',
      },
      label: label.charAt(0).toUpperCase() + label.slice(1),
      subtitle: 'Picked up from other people\'s shelves',
      isCore: true,
      vector: { genre: null, decade: null, mood: matchedMood },
    });
  }

  // ── Engagement genre shelves (capped at maxEngagement) ──
  let engagementCount = 0;
  for (const gs of genreScores) {
    if (engagementCount >= maxEngagement) break;
    if (shelves.length >= count - 1) break; // reserve 1 slot for contrarian
    if (usedGenres.has(gs.id)) continue;
    if (isGenreSuppressed(gs.id)) continue; // user said "less of this"
    usedGenres.add(gs.id);

    const query: Record<string, string> = {
      with_genres: String(gs.id),
      'vote_count.gte': '50',
      'vote_average.gte': '6.0',
      without_genres: '10402,10770',
    };

    let shelfDecade: string | null = null;
    if (topDecade && Math.random() < 0.6) {
      shelfDecade = topDecade;
      const yearCenter = decadeToYear(topDecade);
      const spread = 10;
      query['primary_release_date.gte'] = `${yearCenter - spread}-01-01`;
      query['primary_release_date.lte'] = `${Math.min(new Date().getFullYear(), yearCenter + spread)}-12-31`;
    }

    if (Math.random() >= 0.5) {
      query['vote_count.gte'] = '200';
    }

    const genreLabels = LABEL_GENRE[gs.id] || ['worth your time'];
    let label: string;
    let subtitle: string;

    if (shelfDecade && Math.random() < 0.5) {
      const eraLabels = LABEL_ERA[shelfDecade] || ['from the archive'];
      label = eraLabels[Math.floor(Math.random() * eraLabels.length)];
      subtitle = genreLabels[Math.floor(Math.random() * genreLabels.length)];
    } else {
      label = genreLabels[Math.floor(Math.random() * genreLabels.length)];
      subtitle = shelfDecade
        ? (LABEL_ERA[shelfDecade] || ['from the archive'])[Math.floor(Math.random() * (LABEL_ERA[shelfDecade]?.length || 1))]
        : 'You keep coming back to this shelf';
    }

    shelves.push({
      id: `eng-${gs.id}${shelfDecade ? `-${shelfDecade}` : ''}`,
      query,
      label: label.charAt(0).toUpperCase() + label.slice(1),
      subtitle,
      isCore: true,
      vector: { genre: gs.id, decade: shelfDecade, mood: null },
    });
    engagementCount++;
  }

  // ── Contrarian shelf — the shopkeeper's challenge ──
  // Picks a genre from the BOTTOM of engagement (or completely untouched)
  // and pairs it with a decade the viewer doesn't usually browse.
  // "I know you don't think you'd like this, but trust me."
  const ALL_GENRE_IDS = [28, 12, 16, 35, 80, 99, 18, 14, 36, 27, 9648, 10749, 878, 53, 10752, 37];
  const untouchedGenres = ALL_GENRE_IDS.filter(g => !engagedGenreIds.has(g) && !usedGenres.has(g));
  const weakGenres = genreScores.length > 3
    ? genreScores.slice(-3).filter(g => !usedGenres.has(g.id)).map(g => g.id)
    : [];
  const contrarianPool = untouchedGenres.length > 0 ? untouchedGenres : weakGenres;

  if (contrarianPool.length > 0 && shelves.length < count) {
    const contrarianGenre = contrarianPool[Math.floor(Math.random() * contrarianPool.length)];
    usedGenres.add(contrarianGenre);

    // Pair with a decade the viewer DOESN'T usually watch
    const ALL_DECADES = ['60s', '70s', '80s', '90s', '2000s', '2010s', '2020s'];
    const engagedDecades = new Set(decadeScores.slice(0, 2).map(d => d.decade));
    const contrarianDecades = ALL_DECADES.filter(d => !engagedDecades.has(d));
    const contrarianDecade = contrarianDecades.length > 0
      ? contrarianDecades[Math.floor(Math.random() * contrarianDecades.length)]
      : ALL_DECADES[Math.floor(Math.random() * ALL_DECADES.length)];

    const yearCenter = decadeToYear(contrarianDecade);
    const query: Record<string, string> = {
      with_genres: String(contrarianGenre),
      'vote_count.gte': '100',
      'vote_average.gte': '6.5',
      without_genres: '10402,10770',
      'primary_release_date.gte': `${yearCenter - 8}-01-01`,
      'primary_release_date.lte': `${Math.min(new Date().getFullYear(), yearCenter + 8)}-12-31`,
    };

    const genreLabels = LABEL_GENRE[contrarianGenre] || ['something different'];
    const eraLabels = LABEL_ERA[contrarianDecade] || ['from the archive'];
    // Contrarian labels lean toward the provocative
    const contrarianSubtitles = [
      'The shopkeeper thinks you\'re ready',
      'Not your usual shelf — that\'s the point',
      'You\'d be surprised',
      'Trust the process',
    ];

    const label = (Math.random() < 0.5 ? genreLabels : eraLabels)[
      Math.floor(Math.random() * (Math.random() < 0.5 ? genreLabels : eraLabels).length)
    ];

    shelves.push({
      id: `contrarian-${contrarianGenre}-${contrarianDecade}`,
      query,
      label: label.charAt(0).toUpperCase() + label.slice(1),
      subtitle: contrarianSubtitles[Math.floor(Math.random() * contrarianSubtitles.length)],
      isCore: false,
      vector: { genre: contrarianGenre, decade: contrarianDecade, mood: null },
    });
  }

  // ── Cold start: fill remaining slots with diverse genres ──
  if (shelves.length < count) {
    const coldStartGenres = [18, 53, 878, 80, 27, 99, 36, 16, 9648, 14, 10749, 37];
    const shuffled = [...coldStartGenres].sort(() => Math.random() - 0.5);
    for (const gid of shuffled) {
      if (shelves.length >= count) break;
      if (usedGenres.has(gid)) continue;
      usedGenres.add(gid);

      const genreLabels = LABEL_GENRE[gid] || ['worth discovering'];
      const label = genreLabels[Math.floor(Math.random() * genreLabels.length)];

      shelves.push({
        id: `cold-${gid}`,
        query: {
          with_genres: String(gid),
          'vote_count.gte': '200',
          'vote_average.gte': '6.5',
          without_genres: '10402,10770',
        },
        label: label.charAt(0).toUpperCase() + label.slice(1),
        subtitle: 'Something to try',
        isCore: false,
        vector: { genre: gid, decade: null, mood: null },
      });
    }
  }

  // Shuffle so the order isn't always engagement-first
  return shelves.sort(() => Math.random() - 0.5);
}

// ── Viewer engagement tracking (powers smart shuffle) ──
//
// Three-signal feedback loop:
//   Taps   (1×)  — interest: you clicked to learn more
//   Watches (3×) — commitment: you sat through the whole thing
//   Ratings (5×) — opinion: you cared enough to score it
//
// All signals decay over time so the algorithm follows where you're going,
// not where you've been. Half-life: ~90 days. The decay is applied at read
// time (getWeightedGenres / getWeightedDecade) so writes stay cheap.

const ENGAGEMENT_KEY = 'seenit_genre_engagement';

/** Signal weight multipliers */
const TAP_WEIGHT = 1;
const WATCH_WEIGHT = 3;
const RATING_WEIGHT = 5;

/** Half-life in milliseconds (~90 days). After 90 days a signal is worth
 *  half as much; after 180 days a quarter, etc. */
const HALF_LIFE_MS = 90 * 24 * 60 * 60 * 1000;

interface EngagementEvent {
  weight: number;  // TAP / WATCH / RATING multiplied by count
  ts: number;      // when it happened
}

interface EngagementData {
  genres: Record<number, number>;   // genre_id → raw weighted score
  decades: Record<string, number>;  // "80s" → raw weighted score
  updated: number;
  /** Per-signal event log — kept small (last 200 events max) for decay calc */
  events?: EngagementEvent[];
  /** Per-genre timestamped events for time-decay scoring */
  genreEvents?: Record<number, EngagementEvent[]>;
  /** Per-decade timestamped events */
  decadeEvents?: Record<string, EngagementEvent[]>;
}

function getEngagementData(): EngagementData {
  try {
    const raw = localStorage.getItem(ENGAGEMENT_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return { genres: {}, decades: {}, updated: Date.now(), genreEvents: {}, decadeEvents: {} };
}

function saveEngagementData(data: EngagementData): void {
  try {
    // Cap event lists to prevent unbounded growth (keep newest 60 per genre/decade)
    if (data.genreEvents) {
      for (const gid of Object.keys(data.genreEvents)) {
        const evts = data.genreEvents[Number(gid)];
        if (evts && evts.length > 60) data.genreEvents[Number(gid)] = evts.slice(0, 60);
      }
    }
    if (data.decadeEvents) {
      for (const dec of Object.keys(data.decadeEvents)) {
        const evts = data.decadeEvents[dec];
        if (evts && evts.length > 60) data.decadeEvents[dec] = evts.slice(0, 60);
      }
    }
    localStorage.setItem(ENGAGEMENT_KEY, JSON.stringify(data));
  } catch { /* ignore */ }
}

const RECENT_TAPS_KEY = 'seenit_recent_taps';
const MAX_RECENT_TAPS = 8;

interface RecentTap {
  genreIds: number[];
  ts: number;
}

/** Compute a year → decade label. Matches the DECADES array in discover.ts. */
function yearToDecade(year: number): string {
  if (year < 1970) return '60s';
  if (year < 1980) return '70s';
  if (year < 1990) return '80s';
  if (year < 2000) return '90s';
  if (year < 2010) return '2000s';
  if (year < 2020) return '2010s';
  return '2020s'; // 2020–present
}

/**
 * Internal: record an engagement event with a given weight.
 */
function recordEngagement(genreIds: number[], year: number | null, weight: number): void {
  try {
    const data = getEngagementData();
    const now = Date.now();
    const evt: EngagementEvent = { weight, ts: now };

    // Update genre tallies + event logs
    if (!data.genreEvents) data.genreEvents = {};
    for (const g of genreIds) {
      data.genres[g] = (data.genres[g] || 0) + weight;
      if (!data.genreEvents[g]) data.genreEvents[g] = [];
      data.genreEvents[g].unshift(evt);
    }

    // Update decade tallies + event logs
    if (year) {
      if (!data.decadeEvents) data.decadeEvents = {};
      const dec = yearToDecade(year);
      data.decades[dec] = (data.decades[dec] || 0) + weight;
      if (!data.decadeEvents[dec]) data.decadeEvents[dec] = [];
      data.decadeEvents[dec].unshift(evt);
    }

    data.updated = now;
    saveEngagementData(data);
  } catch { /* ignore */ }
}

/**
 * Track a poster tap — lightweight interest signal (1×).
 * Call on every poster tap. Also records recent taps for mood detection.
 */
export function trackEngagement(genreIds: number[], year: number | null): void {
  recordEngagement(genreIds, year, TAP_WEIGHT);

  // Recent taps (rolling window for mood detection)
  try {
    let recent: RecentTap[] = [];
    try {
      const raw = localStorage.getItem(RECENT_TAPS_KEY);
      if (raw) recent = JSON.parse(raw);
    } catch { /* ignore */ }
    recent.unshift({ genreIds, ts: Date.now() });
    if (recent.length > MAX_RECENT_TAPS) recent = recent.slice(0, MAX_RECENT_TAPS);
    localStorage.setItem(RECENT_TAPS_KEY, JSON.stringify(recent));
  } catch { /* ignore */ }
}

/**
 * Track a watch — commitment signal (3×).
 * Call when the user marks something as watched.
 */
export function trackWatch(genreIds: number[], year: number | null): void {
  recordEngagement(genreIds, year, WATCH_WEIGHT);
}

/**
 * Track a rating — opinion signal (5×).
 * Call when the user rates something. Higher ratings boost more.
 * A 10/10 = 5× weight, a 1/10 = 1× weight (they still watched it).
 */
export function trackRating(genreIds: number[], year: number | null, rating: number): void {
  // Scale: rating 1-10 maps to weight 1-5 (RATING_WEIGHT)
  const scaled = Math.max(1, Math.round((rating / 10) * RATING_WEIGHT));
  recordEngagement(genreIds, year, scaled);
}

/**
 * Record a negative engagement event — "less of this."
 * Writes a negative-weight event into the same stream as positives.
 * decayScore sums weighted events, so a -2 cancels +2 over the 90-day
 * half-life. Negative is dominant — engine learns faster from dismissal.
 *   'soft'   — poster × button (weight -2)
 *   'strong' — "Not for me" on TitlePage (weight -5)
 */
export function trackNegative(
  genreIds: number[],
  year: number | null,
  strength: 'soft' | 'strong' = 'soft',
): void {
  const w = strength === 'strong' ? NEGATIVE_STRONG_WEIGHT : NEGATIVE_TAP_WEIGHT;
  recordEngagement(genreIds, year, w);
}

/**
 * Apply time-decay to a list of engagement events and return a weighted score.
 * Uses exponential decay with the configured half-life.
 */
function decayScore(events: EngagementEvent[] | undefined): number {
  if (!events || events.length === 0) return 0;
  const now = Date.now();
  let score = 0;
  for (const evt of events) {
    const age = now - evt.ts;
    // Exponential decay: weight × 0.5^(age / halfLife)
    const decay = Math.pow(0.5, age / HALF_LIFE_MS);
    score += evt.weight * decay;
  }
  return score;
}

/**
 * Get the viewer's top genre IDs by time-decayed weighted engagement.
 * Taps count 1×, watches 3×, ratings up to 5× — all decaying over ~90 days.
 * Returns up to `limit` genre IDs sorted by decayed score.
 */
export function getTopGenres(limit = 5): number[] {
  const data = getEngagementData();

  // If we have timestamped events, use decay scoring
  if (data.genreEvents && Object.keys(data.genreEvents).length > 0) {
    const scored: [number, number][] = [];
    for (const [gid, events] of Object.entries(data.genreEvents)) {
      const s = decayScore(events);
      if (s > 0.01) scored.push([Number(gid), s]);
    }
    return scored
      .sort(([, a], [, b]) => b - a)
      .slice(0, limit)
      .map(([id]) => id);
  }

  // Fallback: raw tallies (pre-upgrade data)
  return Object.entries(data.genres)
    .sort(([, a], [, b]) => b - a)
    .slice(0, limit)
    .map(([id]) => Number(id));
}

/**
 * Get the viewer's most-engaged decade label (e.g. "80s") by decayed score.
 */
export function getTopDecade(): string | null {
  const data = getEngagementData();

  // If we have timestamped events, use decay scoring
  if (data.decadeEvents && Object.keys(data.decadeEvents).length > 0) {
    let best: string | null = null;
    let bestScore = 0;
    for (const [dec, events] of Object.entries(data.decadeEvents)) {
      const s = decayScore(events);
      if (s > bestScore) { best = dec; bestScore = s; }
    }
    return best;
  }

  // Fallback: raw tallies
  const entries = Object.entries(data.decades);
  if (entries.length === 0) return null;
  entries.sort(([, a], [, b]) => b - a);
  return entries[0][0];
}

// ── Mood context engine ──
// Reads the clock, the calendar, and the viewer's recent emotional trajectory
// to generate a sense of *what kind of night this is*.

/**
 * Genre IDs by emotional register — NOT by darkness or scariness.
 * "Heavy" = slow, emotional, slow burn (the kind of film you sit with).
 * "Light" = fun, fast, energetic.
 * "Intense" = gripping tension, edge-of-seat.
 * Horror is intense, not heavy. Foreign films aren't inherently heavy.
 */
const HEAVY_GENRES = new Set([18, 36, 99]);       // Drama, History, Documentary — slow burn
const LIGHT_GENRES = new Set([35, 16, 10402, 28, 12]); // Comedy, Animation, Music, Action, Adventure
const INTENSE_GENRES = new Set([27, 53, 878, 80, 9648, 10752]); // Horror, Thriller, Sci-Fi, Crime, Mystery, War

export interface MoodContext {
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'latenight';
  dayName: string;
  isWeekend: boolean;
  recentTone: 'heavy' | 'light' | 'intense' | 'mixed' | 'unknown';
  hasHistory: boolean; // have they used the app enough for us to read them
}

export function getMoodContext(): MoodContext {
  const now = new Date();
  const hour = now.getHours();
  const day = now.getDay(); // 0=Sun, 6=Sat

  const timeOfDay: MoodContext['timeOfDay'] =
    hour < 12 ? 'morning'
    : hour < 17 ? 'afternoon'
    : hour < 21 ? 'evening'
    : 'latenight';

  const dayName = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][day];
  const isWeekend = day === 0 || day === 5 || day === 6; // Fri-Sun

  // Read recent taps to detect emotional trajectory
  let recentTone: MoodContext['recentTone'] = 'unknown';
  let hasHistory = false;
  try {
    const raw = localStorage.getItem(RECENT_TAPS_KEY);
    if (raw) {
      const taps: RecentTap[] = JSON.parse(raw);
      // Only consider taps from the last 7 days
      const recent = taps.filter(t => Date.now() - t.ts < 7 * 24 * 60 * 60 * 1000);
      if (recent.length >= 3) {
        hasHistory = true;
        const allGenres = recent.flatMap(t => t.genreIds);
        const heavyCount = allGenres.filter(g => HEAVY_GENRES.has(g)).length;
        const lightCount = allGenres.filter(g => LIGHT_GENRES.has(g)).length;
        const intenseCount = allGenres.filter(g => INTENSE_GENRES.has(g)).length;
        const total = allGenres.length || 1;

        if (heavyCount / total > 0.4) recentTone = 'heavy';
        else if (lightCount / total > 0.4) recentTone = 'light';
        else if (intenseCount / total > 0.4) recentTone = 'intense';
        else recentTone = 'mixed';
      }
    }
  } catch { /* ignore */ }

  return { timeOfDay, dayName, isWeekend, recentTone, hasHistory };
}

// ── Dynamic Phantom Patron system ──
//
// The bookshop has "regulars" and "passersby" — imaginary cinephiles whose
// taste overlaps with the viewer's but extends in surprising directions.
// Unlike fixed archetypes, patrons are EMERGENT: spawned from the viewer's
// own engagement clusters, then mutated to explore adjacent taste territory.
//
// Three mechanisms drive the system:
//   1. SPAWNING — engagement clusters crystallize into new patrons, offset
//      from the viewer's center (adjacent genres, shifted decades, injected
//      mood keywords). The offset IS the serendipity.
//   2. EVOLUTION — patrons the viewer engages with sharpen (vector shifts
//      toward what was clicked/watched). Ignored patrons drift (their vectors
//      randomize). Natural lifecycle: resonate → sharpen, ignore → dissolve.
//   3. RETIREMENT — patrons whose energy drops below threshold are retired.
//      New patrons spawn to fill the gap. The shop is always alive.
//
// Each patron is a TasteVector — a point in multi-dimensional taste space
// (genres × decades × mood keywords × language × obscurity). Shelf labels
// are composed from the vector, not stored as fixed strings.

const PATRON_STORE_KEY = 'seenit_dynamic_patrons';
const PATRON_HISTORY_KEY = 'seenit_patron_history';
const PATRON_MAX = 12;           // max patrons alive at once
const PATRON_MIN = 6;            // always keep at least this many
const SPAWN_CLUSTER_MIN = 3;     // 3+ engagements in a cluster to spawn
const ENERGY_DECAY = 0.08;       // energy lost per session without engagement
const ENERGY_BOOST = 0.15;       // energy gained when viewer engages
const ENERGY_RETIRE = 0.15;      // retire below this threshold
const REGULAR_THRESHOLD = 3;     // 3+ appearances with engagement = regular
const REGULAR_WINDOW_MS = 14 * 24 * 60 * 60 * 1000;

// ── Genre adjacency map ──
// Maps each TMDB genre to its "neighbors" — genres that share thematic DNA.
// Used to mutate patron vectors: a thriller cluster might spawn a patron
// that leans into mystery or crime or noir.
const GENRE_NEIGHBORS: Record<number, number[]> = {
  28: [12, 53, 80, 878, 10752],     // Action → Adventure, Thriller, Crime, Sci-Fi, War
  12: [28, 14, 878, 37],             // Adventure → Action, Fantasy, Sci-Fi, Western
  16: [14, 35, 10751],               // Animation → Fantasy, Comedy, Family
  35: [10749, 18, 16],               // Comedy → Romance, Drama, Animation
  80: [53, 9648, 18, 28],            // Crime → Thriller, Mystery, Drama, Action
  99: [36, 10752, 878],              // Documentary → History, War, Sci-Fi
  18: [10749, 80, 36, 53],           // Drama → Romance, Crime, History, Thriller
  14: [12, 16, 878],                 // Fantasy → Adventure, Animation, Sci-Fi
  36: [18, 10752, 99],               // History → Drama, War, Documentary
  27: [53, 9648, 878],               // Horror → Thriller, Mystery, Sci-Fi
  10402: [18, 99],                    // Music → Drama, Documentary
  9648: [80, 53, 27, 18],            // Mystery → Crime, Thriller, Horror, Drama
  10749: [35, 18],                    // Romance → Comedy, Drama
  878: [27, 53, 12, 14],             // Sci-Fi → Horror, Thriller, Adventure, Fantasy
  10770: [18, 35],                    // TV Movie → Drama, Comedy
  53: [80, 27, 9648, 28],            // Thriller → Crime, Horror, Mystery, Action
  10752: [36, 18, 28],               // War → History, Drama, Action
  37: [28, 12, 18],                   // Western → Action, Adventure, Drama
  10751: [16, 35, 14],               // Family → Animation, Comedy, Fantasy
};

// ── Mood keyword pools ──
// Evocative TMDB keyword IDs grouped by mood. When a patron spawns, 1-2
// keywords from an adjacent mood pool get injected into their vector.
const MOOD_POOLS: Record<string, number[]> = {
  paranoia: [944, 3446, 14601, 5565],           // conspiracy, politics, surveillance
  nostalgia: [156218, 18035, 10683],             // coming-of-age, 1980s, americana
  desire: [158718, 155493, 264384, 158713],      // lgbt, camp, drag, bdsm
  wanderlust: [7312, 1513, 9648],                // road trip, escape, journey
  dread: [261178, 224636, 6152, 163053],         // folk horror, body horror, cosmic horror
  rebellion: [4565, 11322, 5340],                // punk, counterculture, protest
  solitude: [9673, 818, 156218],                 // isolation, loneliness, coming-of-age
  spectacle: [9882, 779, 5927],                  // heist, car chase, showdown
  intrigue: [521, 169086, 6149],                 // washington dc, political drama, power
};
const MOOD_NAMES = Object.keys(MOOD_POOLS);

// ── Shelf label vocabulary ──
// Fragments composed into evocative shelf labels based on vector properties.
// Format: [primary feel] + [optional modifier]. Never the same label twice.

const LABEL_ERA: Record<string, string[]> = {
  '60s': ['Vinyl-era', 'Before the revolution', 'The long sixties'],
  '70s': ['New Hollywood', 'Post-Watergate', 'Grain and grit'],
  '80s': ['Neon & paranoia', 'Reagan-era', 'Synth and shadow'],
  '90s': ['Pre-internet', 'End of the century', 'The last analog decade'],
  '2000s': ['Post-9/11', 'Early digital', 'Turn of the millennium'],
  '2010s': ['Peak streaming', 'The algorithm age', 'Last decade\'s best'],
  '2020s': ['Right now', 'Fresh off the press', 'Still in theaters'],
};

const LABEL_MOOD: Record<string, string[]> = {
  paranoia: ['whispers', 'who\'s watching', 'trust no one'],
  nostalgia: ['remember when', 'before everything changed', 'golden hour'],
  desire: ['after dark', 'skin and smoke', 'the things we want'],
  wanderlust: ['postcards', 'far from home', 'the open road'],
  dread: ['don\'t look away', 'something\'s wrong', 'the quiet before'],
  rebellion: ['burn it down', 'the ones they banned', 'against the grain'],
  solitude: ['alone with this', 'empty rooms', 'the long night'],
  spectacle: ['hold your breath', 'the big screen demands it', 'pure cinema'],
  intrigue: ['behind closed doors', 'power plays', 'the corridors'],
};

export const LABEL_GENRE: Record<number, string[]> = {
  28: ['adrenaline', 'fists and fire', 'full throttle'],
  12: ['the map ends here', 'beyond the edge', 'uncharted'],
  35: ['laughing at the wrong things', 'sharp and mean', 'the funny shelf'],
  80: ['case files', 'crooked lines', 'blood money'],
  99: ['the real world', 'see for yourself', 'evidence'],
  18: ['the weight of it', 'feel everything', 'slow burn'],
  14: ['where the map ends', 'impossible places', 'once upon'],
  27: ['sleep with the lights on', 'the other shelf', 'nightmares'],
  9648: ['every frame is a clue', 'whodunit', 'unsolved'],
  878: ['future tense', 'what if', 'the universe doesn\'t care'],
  53: ['edge of the seat', 'ticking clock', 'no way out'],
  10749: ['the heart wants', 'two people', 'chemistry'],
  36: ['dispatches from another era', 'the past isn\'t dead', 'history rhymes'],
  10752: ['the cost of war', 'frontlines', 'sacrifice'],
  37: ['dust and honor', 'the frontier', 'high noon'],
  16: ['hand-drawn dreams', 'animated brilliance', 'frame by frame'],
};

const LABEL_OBSCURITY = [
  'the ones the algorithm missed',
  'you probably haven\'t seen',
  'from the back of the shelf',
  'dusted off just for you',
  'buried treasure',
];

const LABEL_POPULAR = [
  'everyone\'s talking about these',
  'undeniable',
  'the obvious shelf (for good reason)',
];

// ── Interfaces ──

export interface TasteVector {
  /** Primary TMDB genre ID */
  genrePrimary: number;
  /** Secondary TMDB genre ID (for intersection queries) */
  genreSecondary: number | null;
  /** Center year for decade preference */
  decadeCenter: number;
  /** How wide the decade spread is (±years) */
  decadeSpread: number;
  /** Mood keyword IDs from MOOD_POOLS (1-2) */
  moodKeywords: number[];
  /** Mood pool name for label generation */
  moodName: string;
  /** Language preference: 'any', 'en', or ISO code */
  language: 'any' | string;
  /** Vote count ceiling — low = obscure, null = any */
  voteCeiling: number | null;
  /** Vote floor — higher = more acclaimed */
  voteFloor: number;
  /** Minimum rating */
  ratingFloor: number;
}

/** A specific film that gives a patron a reason to be in this library —
 *  something the viewer engaged with that the patron "also loved." */
export interface PatronAnchor {
  title: string;
  year: number;
  imdbId?: string;
  tmdbId?: number;
}

/** Derived display state — set by evolvePatrons each load. */
export type PatronState = 'fresh' | 'present' | 'fading' | 'departing';

export interface DynamicPatron {
  id: string;
  vector: TasteVector;
  age: number;
  energy: number;
  lastShown: number;
  engagements: number;
  spawnedFrom: string;
  isRegular: boolean;
  shelfTitle: string;
  shelfNote: string;
  attribution: string;
  /** A real film from the viewer's history giving this patron a reason
   *  to be in this library. Surfaces in the shelf subtitle. */
  anchor?: PatronAnchor | null;
  /** Display state derived from energy + recency. */
  state?: PatronState;
}

interface PatronVisit {
  patronId: string;
  ts: number;
  hadEngagement: boolean;
}

// ── Patron persistence ──

function getStoredPatrons(): DynamicPatron[] {
  try {
    const raw = localStorage.getItem(PATRON_STORE_KEY);
    if (raw) return JSON.parse(raw) as DynamicPatron[];
  } catch { /* ignore */ }
  return [];
}

function savePatrons(patrons: DynamicPatron[]): void {
  try {
    // Cap to prevent unbounded growth
    const capped = patrons.slice(0, PATRON_MAX);
    localStorage.setItem(PATRON_STORE_KEY, JSON.stringify(capped));
  } catch { /* ignore */ }
}

export function getPatronHistory(): PatronVisit[] {
  try {
    const raw = localStorage.getItem(PATRON_HISTORY_KEY);
    if (raw) return JSON.parse(raw) as PatronVisit[];
  } catch { /* ignore */ }
  return [];
}

function savePatronHistory(history: PatronVisit[]): void {
  try {
    localStorage.setItem(PATRON_HISTORY_KEY, JSON.stringify(history.slice(0, 60)));
  } catch { /* ignore */ }
}

// ── Shelf label generation ──
// Composes an evocative label from the patron's vector. Never algorithmic-
// sounding — feels like a handwritten card left on a shelf.

function generateShelfLabel(v: TasteVector): { title: string; note: string; attribution: string } {
  const r = () => Math.random();

  // Pick label fragments from each dimension
  const eraKey = yearToDecade(v.decadeCenter);
  const eraOptions = LABEL_ERA[eraKey] || LABEL_ERA['2020s'];
  const moodOptions = LABEL_MOOD[v.moodName] || LABEL_MOOD['spectacle'];
  const genreOptions = LABEL_GENRE[v.genrePrimary] || ['someone\'s favorites', 'worth your time'];

  // Obscurity-based labels for niche patrons
  const isObscure = v.voteCeiling !== null && v.voteCeiling < 1000;
  const obscurityLabels = isObscure ? LABEL_OBSCURITY : LABEL_POPULAR;

  // Compose: 40% mood-led, 30% era-led, 20% genre-led, 10% obscurity-led
  const roll = r();
  let title: string;
  let note: string;

  if (roll < 0.4) {
    title = moodOptions[Math.floor(r() * moodOptions.length)];
    note = eraOptions[Math.floor(r() * eraOptions.length)];
  } else if (roll < 0.7) {
    title = eraOptions[Math.floor(r() * eraOptions.length)];
    note = genreOptions[Math.floor(r() * genreOptions.length)];
  } else if (roll < 0.9) {
    title = genreOptions[Math.floor(r() * genreOptions.length)];
    note = moodOptions[Math.floor(r() * moodOptions.length)];
  } else {
    title = obscurityLabels[Math.floor(r() * obscurityLabels.length)];
    note = moodOptions[Math.floor(r() * moodOptions.length)];
  }

  // Capitalize first letter
  title = title.charAt(0).toUpperCase() + title.slice(1);

  // Attribution — a brief persona hint, not a fixed name
  const attributionFragments = [
    'A regular', 'Someone passing through', 'The person in the corner',
    'A familiar face', 'Someone who knows this section well',
    'The one who always finds the good ones', 'A friend of a friend',
    'Back again', 'Just browsing', 'The quiet one with great taste',
  ];
  const attribution = attributionFragments[Math.floor(r() * attributionFragments.length)];

  return { title, note, attribution };
}

// ── Engagement cluster detection ──
// Scans the viewer's recent engagement to find clusters (co-occurring genre +
// decade patterns). Each cluster can spawn a patron.

interface EngagementCluster {
  /** Cluster ID for dedup (genre:decade) */
  id: string;
  genreId: number;
  decade: string;
  score: number;
}

function detectEngagementClusters(): EngagementCluster[] {
  const data = getEngagementData();
  if (!data.genreEvents) return [];

  const clusters: EngagementCluster[] = [];

  // Score each genre×decade combination
  for (const [gidStr, events] of Object.entries(data.genreEvents)) {
    const gid = Number(gidStr);
    if (!events || events.length < SPAWN_CLUSTER_MIN) continue;

    // Get the genre's decayed score
    const genreScore = decayScore(events);
    if (genreScore < 1) continue;

    // Use the viewer's overall top decade as the cluster's decade
    const topDec = getTopDecade() || '2020s';
    const clusterId = `${gid}:${topDec}`;

    clusters.push({
      id: clusterId,
      genreId: gid,
      decade: topDec,
      score: genreScore,
    });
  }

  // Sort by score, return top clusters
  return clusters.sort((a, b) => b.score - a.score).slice(0, 8);
}

// ── Patron spawning ──
// Creates a new patron from an engagement cluster, mutated to explore
// adjacent taste territory.

function decadeToYear(decade: string): number {
  const map: Record<string, number> = {
    '60s': 1965, '70s': 1975, '80s': 1985, '90s': 1995,
    '2000s': 2005, '2010s': 2015, '2020s': 2023,
  };
  return map[decade] || 2020;
}

/**
 * Pick an anchor film for a patron from the candidate pool.
 * Tier 1: genre + decade + rating, Tier 2: genre, Tier 3: decade,
 * Tier 4: any well-rated, Tier 5: anything. Null if pool is empty.
 */
function pickAnchorForVector(v: TasteVector): PatronAnchor | null {
  const pool = getAnchorCandidates();
  if (pool.length === 0) return null;

  const decadeMin = v.decadeCenter - v.decadeSpread;
  const decadeMax = v.decadeCenter + v.decadeSpread;

  let tier = pool.filter(c =>
    c.genres.includes(v.genrePrimary) &&
    c.year >= decadeMin && c.year <= decadeMax &&
    (c.rating === undefined || c.rating >= 7)
  );
  if (tier.length === 0) tier = pool.filter(c => c.genres.includes(v.genrePrimary));
  if (tier.length === 0) tier = pool.filter(c => c.year >= decadeMin && c.year <= decadeMax);
  if (tier.length === 0) tier = pool.filter(c => (c.rating ?? 0) >= 7);
  if (tier.length === 0) tier = pool;

  const pick = tier[Math.floor(Math.random() * tier.length)];
  return {
    title: pick.title,
    year: pick.year,
    imdbId: pick.imdbId,
    tmdbId: pick.tmdbId,
  };
}

function spawnPatron(cluster: EngagementCluster): DynamicPatron {
  const r = () => Math.random();

  // Primary genre: 50% keep cluster genre, 50% shift to adjacent
  const neighbors = GENRE_NEIGHBORS[cluster.genreId] || [];
  const genrePrimary = r() < 0.5 && neighbors.length > 0
    ? neighbors[Math.floor(r() * neighbors.length)]
    : cluster.genreId;

  // Secondary genre: pick from primary's neighbors (or null)
  const secNeighbors = GENRE_NEIGHBORS[genrePrimary] || [];
  const genreSecondary = r() < 0.6 && secNeighbors.length > 0
    ? secNeighbors[Math.floor(r() * secNeighbors.length)]
    : null;

  // Decade: shift ±0-20 years from cluster center
  const baseYear = decadeToYear(cluster.decade);
  const yearShift = Math.round((r() - 0.5) * 40); // ±20 years
  const decadeCenter = Math.max(1960, Math.min(2026, baseYear + yearShift));
  const decadeSpread = 5 + Math.floor(r() * 15); // ±5 to ±20 years

  // Mood: pick a random mood pool, inject 1-2 keywords
  const moodName = MOOD_NAMES[Math.floor(r() * MOOD_NAMES.length)];
  const pool = MOOD_POOLS[moodName];
  const kwCount = 1 + Math.floor(r() * 2);
  const shuffledPool = [...pool].sort(() => r() - 0.5);
  const moodKeywords = shuffledPool.slice(0, kwCount);

  // Language: 75% any, 15% English-only, 10% specific world language
  const worldLangs = ['ko', 'ja', 'fr', 'es', 'de', 'it', 'pt', 'zh', 'hi', 'sv', 'da'];
  let language: string = 'any';
  const langRoll = r();
  if (langRoll < 0.15) language = 'en';
  else if (langRoll < 0.25) language = worldLangs[Math.floor(r() * worldLangs.length)];

  // Obscurity: 40% niche (low vote ceiling), 60% open
  const voteCeiling = r() < 0.4 ? 200 + Math.floor(r() * 800) : null;
  const voteFloor = voteCeiling ? 20 : 50 + Math.floor(r() * 200);
  const ratingFloor = 5.5 + r() * 2; // 5.5 – 7.5

  const vector: TasteVector = {
    genrePrimary,
    genreSecondary,
    decadeCenter,
    decadeSpread,
    moodKeywords,
    moodName,
    language,
    voteCeiling,
    voteFloor,
    ratingFloor: Math.round(ratingFloor * 10) / 10,
  };

  const label = generateShelfLabel(vector);
  const anchor = pickAnchorForVector(vector);

  return {
    id: `p-${Date.now().toString(36)}-${Math.floor(r() * 1000).toString(36)}`,
    vector,
    age: 0,
    energy: 0.7,
    engagements: 0,
    lastShown: 0,
    spawnedFrom: cluster.id,
    isRegular: false,
    shelfTitle: label.title,
    shelfNote: label.note,
    attribution: label.attribution,
    anchor,
    state: 'fresh',
  };
}

// ── Patron evolution ──
// After each session, patrons evolve based on whether the viewer engaged
// with their shelf.

function evolvePatrons(patrons: DynamicPatron[]): DynamicPatron[] {
  const now = Date.now();
  const history = getPatronHistory();
  const recentCutoff = now - REGULAR_WINDOW_MS;

  return patrons.map(p => {
    const updated = { ...p, age: p.age + 1 };

    const recentAppearances = history.filter(
      v => v.patronId === p.id && v.ts >= recentCutoff && v.hadEngagement
    ).length;
    updated.isRegular = recentAppearances >= REGULAR_THRESHOLD;

    // Energy decay — bigger step than before so the fade is visible over
    // 5–7 days instead of dragging for weeks.
    const daysSinceShown = (now - p.lastShown) / (24 * 60 * 60 * 1000);
    if (daysSinceShown > 2) {
      const extraSteps = Math.min(3, Math.floor(daysSinceShown / 2));
      updated.energy = Math.max(0, p.energy - ENERGY_DECAY * extraSteps);
    }

    // Regulars decay slower
    if (updated.isRegular) {
      updated.energy = Math.max(updated.energy, 0.35);
    }

    // Derived display state
    if (updated.age <= 2) updated.state = 'fresh';
    else if (updated.energy >= 0.4) updated.state = 'present';
    else if (updated.energy >= 0.2) updated.state = 'fading';
    else updated.state = 'departing';

    // Refresh labels periodically
    if (updated.age % 5 === 0) {
      const label = generateShelfLabel(updated.vector);
      updated.shelfTitle = label.title;
      updated.shelfNote = label.note;
      updated.attribution = label.attribution;
    }

    // Re-anchor patrons that don't have one yet (legacy / cold-spawn)
    if (!updated.anchor) {
      updated.anchor = pickAnchorForVector(updated.vector);
    }

    return updated;
  });
}

// ── Patron engagement feedback ──
// Call when the viewer taps/watches something from a patron's shelf.

export function recordPatronEngagement(
  patronId: string,
  itemGenreIds?: number[],
  itemYear?: number | null,
): void {
  const patrons = getStoredPatrons();
  const idx = patrons.findIndex(p => p.id === patronId);
  if (idx === -1) return;

  const patron = { ...patrons[idx] };
  patron.energy = Math.min(1, patron.energy + ENERGY_BOOST);
  patron.engagements++;

  // ── Keyword absorption: patron taste flows into the viewer's pool ──
  // When the viewer picks from a patron's shelf, the patron's mood
  // keywords enter the viewer's keyword engagement data. Over time,
  // recurring keywords crystallize into personal shelf parameters.
  // This is how "Queer Cinema" or "DC & Politics" emerge organically
  // rather than being hardcoded.
  if (patron.vector.moodKeywords.length > 0) {
    recordKeywordEngagement(patron.vector.moodKeywords, TAP_WEIGHT);
  }

  // ── Vector drift: the patron "learns" from what was clicked ──
  // The patron's vector shifts toward the engaged item's genres.
  // Drift is gentle (20% blend) so the patron evolves gradually
  // rather than snapping to the last thing tapped.
  if (itemGenreIds && itemGenreIds.length > 0) {
    const v = { ...patron.vector };

    // Genre drift: 20% chance primary shifts toward an engaged genre
    // that isn't already primary. Feels like the patron noticed what
    // the viewer picked and adjusted their shelf accordingly.
    const newGenres = itemGenreIds.filter(g => g !== v.genrePrimary);
    if (newGenres.length > 0 && Math.random() < 0.2) {
      // Old primary becomes secondary (preserves continuity)
      v.genreSecondary = v.genrePrimary;
      v.genrePrimary = newGenres[Math.floor(Math.random() * newGenres.length)];
    } else if (newGenres.length > 0 && Math.random() < 0.4) {
      // More common: secondary shifts to reflect the new influence
      v.genreSecondary = newGenres[Math.floor(Math.random() * newGenres.length)];
    }

    // Decade drift: nudge toward the engaged item's decade
    if (itemYear && itemYear > 1950) {
      const drift = (itemYear - v.decadeCenter) * 0.15; // 15% pull
      v.decadeCenter = Math.max(1960, Math.min(2026, Math.round(v.decadeCenter + drift)));
    }

    // Mood drift: if the engaged genres suggest a different mood,
    // there's a small chance the patron picks up a new keyword
    const genreMoodMap: Record<number, string> = {
      27: 'dread', 53: 'paranoia', 80: 'intrigue', 18: 'solitude',
      35: 'spectacle', 12: 'wanderlust', 878: 'paranoia', 10749: 'desire',
      36: 'nostalgia', 28: 'spectacle', 99: 'rebellion', 9648: 'paranoia',
    };
    for (const g of itemGenreIds) {
      const suggestedMood = genreMoodMap[g];
      if (suggestedMood && suggestedMood !== v.moodName && Math.random() < 0.15) {
        const pool = MOOD_POOLS[suggestedMood];
        if (pool && pool.length > 0) {
          v.moodName = suggestedMood;
          v.moodKeywords = [pool[Math.floor(Math.random() * pool.length)]];
        }
        break; // only one mood shift per engagement
      }
    }

    patron.vector = v;

    // Refresh shelf label after significant drift (every 3 engagements)
    if (patron.engagements % 3 === 0) {
      const label = generateShelfLabel(patron.vector);
      patron.shelfTitle = label.title;
      patron.shelfNote = label.note;
      patron.attribution = label.attribution;
    }
  }

  patrons[idx] = patron;
  savePatrons(patrons);

  // Record visit with engagement flag
  const history = getPatronHistory();
  const recent = history.find(v => v.patronId === patronId && Date.now() - v.ts < 60000);
  if (recent) {
    recent.hadEngagement = true;
    savePatronHistory(history);
  }
}

// ── Main entry point: get active patrons for this feed load ──
//
// Orchestrates the full lifecycle:
//   1. Load stored patrons
//   2. Evolve (age, energy decay, regular detection)
//   3. Retire dead patrons
//   4. Spawn new patrons from engagement clusters if needed
//   5. Score and pick 3-4 for this load
//   6. Save state

export function pickActivePatrons(
  topGenres: number[],
  count = 4,
): DynamicPatron[] {
  let patrons = getStoredPatrons();

  // ── Step 1: Evolve existing patrons ──
  patrons = evolvePatrons(patrons);

  // ── Step 2: Retire exhausted patrons ──
  patrons = patrons.filter(p => p.energy >= ENERGY_RETIRE || p.isRegular);

  // ── Step 3: Spawn new patrons if below minimum ──
  const clusters = detectEngagementClusters();
  const existingSpawns = new Set(patrons.map(p => p.spawnedFrom));

  while (patrons.length < PATRON_MIN && clusters.length > 0) {
    // Find a cluster that hasn't already spawned a living patron
    const available = clusters.filter(c => !existingSpawns.has(c.id));
    const cluster = available.length > 0 ? available[0] : clusters[0];

    const newPatron = spawnPatron(cluster);
    patrons.push(newPatron);
    existingSpawns.add(cluster.id);

    // Remove used cluster
    const ci = clusters.indexOf(cluster);
    if (ci >= 0) clusters.splice(ci, 1);
  }

  // Also spawn 1-2 surprise patrons from weaker clusters for novelty
  if (patrons.length < PATRON_MAX && clusters.length > 0) {
    const surpriseCount = 1 + Math.floor(Math.random() * 2);
    const weakClusters = clusters.slice(-surpriseCount);
    for (const c of weakClusters) {
      if (patrons.length >= PATRON_MAX) break;
      if (!existingSpawns.has(c.id) || Math.random() < 0.3) {
        patrons.push(spawnPatron(c));
      }
    }
  }

  // ── Fallback: if no engagement data yet, seed with diverse patrons ──
  // Deliberately eclectic — NOT the obvious genre buckets. Each seed
  // combines an unexpected genre×decade pairing so the feed never
  // looks like a streaming service's default homepage rows.
  if (patrons.length === 0) {
    const seeds: Array<{ genre: number; decade: string }> = [
      { genre: 9648, decade: '70s' },   // mystery × 70s paranoia thrillers
      { genre: 878, decade: '80s' },    // sci-fi × practical-effects era
      { genre: 99, decade: '2000s' },   // documentary × peak nonfiction era
      { genre: 80, decade: '90s' },     // crime × neo-noir heyday
      { genre: 14, decade: '2010s' },   // fantasy × modern auteur fantasy
      { genre: 36, decade: '60s' },     // history × new wave cinema
      { genre: 53, decade: '2020s' },   // thriller × now
      { genre: 37, decade: '70s' },     // western × revisionist era
    ];
    // Shuffle seeds so each cold-start looks different
    for (let i = seeds.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [seeds[i], seeds[j]] = [seeds[j], seeds[i]];
    }
    for (let i = 0; i < PATRON_MIN; i++) {
      const s = seeds[i % seeds.length];
      const fakeCluster: EngagementCluster = {
        id: `seed:${s.genre}:${s.decade}`,
        genreId: s.genre,
        decade: s.decade,
        score: 1,
      };
      patrons.push(spawnPatron(fakeCluster));
    }
  }

  // ── Step 4: Score and pick for this load ──
  // Patrons "come in more often when they see things on my shelves that
  // they like." Score is based on engagement overlap, energy lifecycle,
  // and novelty — patrons are attracted by the viewer's current taste
  // clusters, not just static genre lists.
  const now = Date.now();
  const topSet = new Set(topGenres);

  // Current keyword engagement for patron mood-matching
  const topKw = getTopKeywords(6);
  const kwSet = new Set(topKw.map(k => k.id));

  const scored = patrons.map(p => {
    let score = 0;

    // Genre affinity: patron's taste overlaps with the viewer's top genres
    if (topSet.has(p.vector.genrePrimary)) score += 0.25;
    if (p.vector.genreSecondary && topSet.has(p.vector.genreSecondary)) score += 0.15;

    // Keyword affinity: patron's mood keywords overlap with viewer's
    // absorbed keywords. This is the "they see things on my shelves
    // that they like" signal — patrons with shared keyword DNA are
    // drawn back to the shop.
    const kwOverlap = p.vector.moodKeywords.filter(k => kwSet.has(k)).length;
    score += kwOverlap * 0.15;

    // Diversity bonus: patrons that DON'T overlap get a surprise bonus
    // (the bookshop needs strangers too, not just regulars)
    if (!topSet.has(p.vector.genrePrimary) && kwOverlap === 0) score += 0.1;

    // Energy: healthy patrons are more likely to appear
    score += p.energy * 0.3;

    // Regular bonus — earned through repeated engagement
    if (p.isRegular) score += 0.35;

    // Recency penalty: don't show same patron every load
    if (now - p.lastShown < 30000) score -= 0.5; // shown this session
    else if (now - p.lastShown < 24 * 60 * 60 * 1000) score -= 0.1; // shown today

    // Novelty bonus for never-shown patrons
    if (p.lastShown === 0) score += 0.2;

    // ── Negative-feedback penalties ──
    if (isShelfSuppressed(`patron-${p.id}`)) score -= 1.5;
    if (isGenreSuppressed(p.vector.genrePrimary)) score -= 0.4;
    if (p.state === 'departing') score -= 0.25;

    // Randomness (±0.25)
    score += (Math.random() - 0.5) * 0.5;

    return { patron: p, score };
  });

  scored.sort((a, b) => b.score - a.score);

  // ── Stranger guarantee ──
  // At least 1 of the 4 patrons must have ZERO genre overlap with
  // the viewer's top genres. The stranger walked into the wrong shop
  // and left behind something you'd never find on your own.
  // Pick top (count - 1) by score, then fill the last slot with the
  // highest-scoring stranger. If no true stranger exists, pick the
  // patron with the least overlap.
  const affinityPicks = scored.slice(0, count - 1).map(s => s.patron);
  const pickedIds = new Set(affinityPicks.map(p => p.id));

  const strangerCandidates = scored
    .filter(s => !pickedIds.has(s.patron.id))
    .sort((a, b) => {
      // Sort by LEAST genre overlap first
      const overlapA = (topSet.has(a.patron.vector.genrePrimary) ? 1 : 0)
        + (a.patron.vector.genreSecondary && topSet.has(a.patron.vector.genreSecondary) ? 1 : 0);
      const overlapB = (topSet.has(b.patron.vector.genrePrimary) ? 1 : 0)
        + (b.patron.vector.genreSecondary && topSet.has(b.patron.vector.genreSecondary) ? 1 : 0);
      if (overlapA !== overlapB) return overlapA - overlapB; // less overlap first
      return b.score - a.score; // then by score
    });

  const stranger = strangerCandidates[0]?.patron || scored[count - 1]?.patron;
  const picked = stranger ? [...affinityPicks, stranger] : affinityPicks;

  // Record visits and update lastShown
  const history = getPatronHistory();
  for (const p of picked) {
    p.lastShown = now;
    history.unshift({ patronId: p.id, ts: now, hadEngagement: false });
  }
  savePatronHistory(history);

  // Save updated state
  savePatrons(patrons);

  // Shuffle so order isn't score-ranked
  for (let i = picked.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [picked[i], picked[j]] = [picked[j], picked[i]];
  }

  return picked;
}

/**
 * Get cache statistics (includes byte-level size tracking).
 */
export function getCacheStats(): {
  cacheEntries: number;
  lookupEntries: number;
  totalSize: number;
  totalBytes: number;
  budgetBytes: number;
  budgetPct: number;
} {
  try {
    const keys = Object.keys(localStorage);
    const cacheKeys = keys.filter((k) => k.startsWith(CACHE_PREFIX));
    const lookupKeys = keys.filter((k) => k.startsWith(LOOKUP_PREFIX));

    let totalSize = 0;
    keys.forEach((key) => {
      if (key.startsWith('seenit_')) {
        const item = localStorage.getItem(key);
        totalSize += item ? item.length : 0;
      }
    });

    const totalBytes = getStorageBytes();

    return {
      cacheEntries: cacheKeys.length,
      lookupEntries: lookupKeys.length,
      totalSize,
      totalBytes,
      budgetBytes: STORAGE_BUDGET_BYTES,
      budgetPct: Math.round((totalBytes / STORAGE_BUDGET_BYTES) * 100),
    };
  } catch (error) {
    console.error('Error getting cache stats:', error);
    return { cacheEntries: 0, lookupEntries: 0, totalSize: 0, totalBytes: 0, budgetBytes: STORAGE_BUDGET_BYTES, budgetPct: 0 };
  }
}
