/**
 * Local Storage and Caching
 * Manages localStorage caching, lookups, and OAuth tokens
 */

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttlMinutes: number;
}

interface LookupData {
  tmdbId: number;
  title: string;
  year?: number;
  posterPath?: string;
  mediaType: 'movie' | 'tv';
  searchedAt: number;
}

// RecentLookup type imported from types
import type { RecentLookup } from '../types';

interface TraktToken {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  token_type: string;
}

const CACHE_PREFIX = 'seenit_cache_';
const LOOKUP_PREFIX = 'seenit_lookup_';
const RECENT_LOOKUPS_KEY = 'seenit_recent_lookups';
const NOTES_PREFIX = 'seenit_notes_';
const TRAKT_TOKEN_KEY = 'seenit_trakt_token';

// ── Storage budget ──
// localStorage is typically 5-10 MB. We budget 3 MB for SeenIt to leave
// headroom for other origins sharing the same limit on some browsers.
const STORAGE_BUDGET_BYTES = 3 * 1024 * 1024;   // 3 MB
const MAX_LOOKUPS = 150;   // cap lookup entries (LRU eviction)
const MAX_ENGAGEMENT_GENRES = 40; // cap genre tally keys

/**
 * Get a value from cache (with TTL checking)
 */
export function cacheGet<T>(key: string): T | null {
  try {
    const stored = localStorage.getItem(`${CACHE_PREFIX}${key}`);
    if (!stored) return null;

    const entry = JSON.parse(stored) as CacheEntry<T>;
    const now = Date.now();
    const ageMinutes = (now - entry.timestamp) / 1000 / 60;

    // Check if expired
    if (ageMinutes > entry.ttlMinutes) {
      localStorage.removeItem(`${CACHE_PREFIX}${key}`);
      return null;
    }

    return entry.data;
  } catch (error) {
    console.error('Error reading cache:', error);
    return null;
  }
}

/**
 * Set a value in cache with TTL.
 * On quota error, evicts expired entries + oldest lookups, then retries once.
 */
export function cacheSet<T>(key: string, value: T, ttlMinutes = 60): void {
  const entry: CacheEntry<T> = {
    data: value,
    timestamp: Date.now(),
    ttlMinutes,
  };
  const raw = JSON.stringify(entry);

  try {
    localStorage.setItem(`${CACHE_PREFIX}${key}`, raw);
  } catch {
    // Likely QuotaExceededError — free space and retry
    console.warn('[storage] write failed, evicting to free space...');
    pruneExpiredCache();
    evictOldestLookups(Math.max(20, MAX_LOOKUPS / 2)); // drop oldest half
    try {
      localStorage.setItem(`${CACHE_PREFIX}${key}`, raw);
    } catch (err2) {
      console.error('[storage] write still failed after eviction:', err2);
    }
  }
}

/**
 * Get cached lookup data for a TMDB ID
 */
export function getCachedLookup(tmdbId: number): LookupData | null {
  try {
    const stored = localStorage.getItem(`${LOOKUP_PREFIX}${tmdbId}`);
    if (!stored) return null;

    return JSON.parse(stored) as LookupData;
  } catch (error) {
    console.error('Error reading cached lookup:', error);
    return null;
  }
}

/**
 * Cache lookup data for a TMDB ID.
 * Enforces MAX_LOOKUPS cap — evicts oldest entries when full.
 */
export function setCachedLookup(tmdbId: number, data: LookupData): void {
  try {
    // Enforce cap before writing
    evictOldestLookups(MAX_LOOKUPS - 1); // make room for this one
    localStorage.setItem(`${LOOKUP_PREFIX}${tmdbId}`, JSON.stringify(data));
  } catch {
    // Quota error — drop half the lookups and retry
    evictOldestLookups(Math.max(20, MAX_LOOKUPS / 2));
    try {
      localStorage.setItem(`${LOOKUP_PREFIX}${tmdbId}`, JSON.stringify(data));
    } catch { /* give up silently */ }
  }
}

/**
 * Get list of recent lookups (last 20)
 */
export function getRecentLookups(): RecentLookup[] {
  try {
    const stored = localStorage.getItem(RECENT_LOOKUPS_KEY);
    if (!stored) return [];

    return JSON.parse(stored) as RecentLookup[];
  } catch (error) {
    console.error('Error reading recent lookups:', error);
    return [];
  }
}

/**
 * Add item to recent lookups
 */
export function addRecentLookup(item: {
  tmdbId: number;
  title: string;
  posterPath?: string;
  mediaType: 'movie' | 'tv';
}): void {
  try {
    const recent = getRecentLookups();

    // Remove if already exists (to move to front)
    const filtered = recent.filter((r) => r.tmdbId !== item.tmdbId);

    // Add new item at front
    const updated: RecentLookup[] = [
      {
        ...item,
        lastViewed: Date.now(),
      },
      ...filtered,
    ];

    // Keep only last 20
    const limited = updated.slice(0, 20);

    localStorage.setItem(RECENT_LOOKUPS_KEY, JSON.stringify(limited));
  } catch (error) {
    console.error('Error adding to recent lookups:', error);
  }
}

/**
 * Get personal notes for a title
 */
export function getNotes(tmdbId: number): string {
  try {
    const stored = localStorage.getItem(`${NOTES_PREFIX}${tmdbId}`);
    return stored || '';
  } catch (error) {
    console.error('Error reading notes:', error);
    return '';
  }
}

/**
 * Set personal notes for a title
 */
export function setNotes(tmdbId: number, notes: string): void {
  try {
    if (notes.trim()) {
      localStorage.setItem(`${NOTES_PREFIX}${tmdbId}`, notes);
    } else {
      localStorage.removeItem(`${NOTES_PREFIX}${tmdbId}`);
    }
  } catch (error) {
    console.error('Error writing notes:', error);
  }
}

/**
 * Get Trakt OAuth tokens
 */
export function getTraktToken(): TraktToken | null {
  try {
    const stored = localStorage.getItem(TRAKT_TOKEN_KEY);
    if (!stored) return null;

    return JSON.parse(stored) as TraktToken;
  } catch (error) {
    console.error('Error reading Trakt token:', error);
    return null;
  }
}

/**
 * Set Trakt OAuth tokens
 */
export function setTraktToken(token: TraktToken): void {
  try {
    localStorage.setItem(TRAKT_TOKEN_KEY, JSON.stringify(token));
  } catch (error) {
    console.error('Error writing Trakt token:', error);
  }
}

/**
 * Clear all SeenIt cache
 */
export function clearAllCache(): void {
  try {
    const keys = Object.keys(localStorage);
    keys.forEach((key) => {
      if (key.startsWith('seenit_')) {
        localStorage.removeItem(key);
      }
    });
  } catch (error) {
    console.error('Error clearing cache:', error);
  }
}

/**
 * Invalidate browse-related caches so the next BrowsePage load
 * re-fetches Trakt status. Call after marking items watched/hidden/watchlisted.
 */
export function invalidateBrowseCaches(): void {
  try {
    localStorage.removeItem(`${CACHE_PREFIX}browse_hidden`);
    localStorage.removeItem(`${CACHE_PREFIX}browse_watched`);
    localStorage.removeItem(`${CACHE_PREFIX}browse_watchlist`);
    localStorage.removeItem(`${CACHE_PREFIX}curated_feed`);
    // Also clear library caches so My Picks reflects changes immediately
    localStorage.removeItem(`${CACHE_PREFIX}library_full`);
    localStorage.removeItem(`${CACHE_PREFIX}library_critics`);
    localStorage.removeItem(`${CACHE_PREFIX}library_unseen`);
  } catch { /* ignore */ }
}

// ── OMDB daily quota tracking ──
const OMDB_QUOTA_KEY = 'seenit_omdb_quota';
const OMDB_DAILY_LIMIT = 1000;

interface OmdbQuota { count: number; date: string }

function getOmdbQuota(): OmdbQuota {
  try {
    const raw = localStorage.getItem(OMDB_QUOTA_KEY);
    if (raw) {
      const q = JSON.parse(raw) as OmdbQuota;
      const today = new Date().toISOString().slice(0, 10);
      if (q.date === today) return q;
    }
  } catch { /* ignore */ }
  return { count: 0, date: new Date().toISOString().slice(0, 10) };
}

/** Increment the daily OMDB request counter. Returns false if quota exhausted. */
export function trackOmdbRequest(): boolean {
  const q = getOmdbQuota();
  if (q.count >= OMDB_DAILY_LIMIT) return false;
  q.count++;
  try { localStorage.setItem(OMDB_QUOTA_KEY, JSON.stringify(q)); } catch { /* ignore */ }
  return true;
}

/** Get remaining OMDB requests for today. */
export function getOmdbRemaining(): number {
  const q = getOmdbQuota();
  return Math.max(0, OMDB_DAILY_LIMIT - q.count);
}

/**
 * Prune expired cache entries + orphaned keys to free localStorage space.
 * Call this on app startup to prevent unbounded growth.
 */
export function pruneExpiredCache(): number {
  let removed = 0;
  try {
    const keys = Object.keys(localStorage);
    const now = Date.now();

    // 1. Remove expired TTL-based cache entries
    for (const key of keys) {
      if (!key.startsWith(CACHE_PREFIX)) continue;
      try {
        const raw = localStorage.getItem(key);
        if (!raw) continue;
        const entry = JSON.parse(raw) as CacheEntry<unknown>;
        const ageMin = (now - entry.timestamp) / 60000;
        if (ageMin > entry.ttlMinutes) {
          localStorage.removeItem(key);
          removed++;
        }
      } catch {
        // Corrupted entry — remove it
        localStorage.removeItem(key);
        removed++;
      }
    }

    // 2. Cap lookup entries (LRU by searchedAt)
    removed += evictOldestLookups(MAX_LOOKUPS);

    // 3. Cap engagement genre keys
    removed += trimEngagementGenres();

  } catch { /* ignore */ }
  return removed;
}

/**
 * Evict oldest lookup entries until count <= maxKeep.
 * Returns number of entries removed.
 */
function evictOldestLookups(maxKeep: number): number {
  let removed = 0;
  try {
    const keys = Object.keys(localStorage).filter(k => k.startsWith(LOOKUP_PREFIX));
    if (keys.length <= maxKeep) return 0;

    // Parse and sort by searchedAt (oldest first)
    const entries: { key: string; ts: number }[] = [];
    for (const key of keys) {
      try {
        const raw = localStorage.getItem(key);
        if (!raw) { localStorage.removeItem(key); removed++; continue; }
        const data = JSON.parse(raw) as LookupData;
        entries.push({ key, ts: data.searchedAt || 0 });
      } catch {
        localStorage.removeItem(key); removed++;
      }
    }

    entries.sort((a, b) => a.ts - b.ts); // oldest first
    const toRemove = entries.length - maxKeep;
    for (let i = 0; i < toRemove && i < entries.length; i++) {
      localStorage.removeItem(entries[i].key);
      removed++;
    }
  } catch { /* ignore */ }
  return removed;
}

/**
 * Trim genre engagement data to keep only the top N genres by count.
 * Prevents the tally object from growing unbounded.
 */
function trimEngagementGenres(): number {
  try {
    const raw = localStorage.getItem('seenit_genre_engagement');
    if (!raw) return 0;
    const data = JSON.parse(raw) as { genres: Record<string, number>; decades: Record<string, number>; updated: number };
    const genreEntries = Object.entries(data.genres);
    if (genreEntries.length <= MAX_ENGAGEMENT_GENRES) return 0;

    // Keep only the top N by count
    genreEntries.sort(([, a], [, b]) => b - a);
    const kept = Object.fromEntries(genreEntries.slice(0, MAX_ENGAGEMENT_GENRES));
    const trimmed = genreEntries.length - MAX_ENGAGEMENT_GENRES;
    data.genres = kept;
    localStorage.setItem('seenit_genre_engagement', JSON.stringify(data));
    return trimmed;
  } catch { return 0; }
}

/**
 * Get total bytes used by all SeenIt keys in localStorage.
 */
export function getStorageBytes(): number {
  try {
    let total = 0;
    for (const key of Object.keys(localStorage)) {
      if (!key.startsWith('seenit_')) continue;
      const val = localStorage.getItem(key);
      // Each char is ~2 bytes in JS strings (UTF-16)
      total += (key.length + (val?.length || 0)) * 2;
    }
    return total;
  } catch { return 0; }
}

// ── Personal vibe keywords ──
// Thematic clusters of TMDB keyword IDs that reflect the viewer's specific
// interests beyond genre. Each load picks 1-2 clusters for a "Your Vibes" row.

const VIBES_KEY = 'seenit_vibes';

export interface VibeCluster {
  label: string;           // human-readable name for the cluster
  subtitle: string;        // what shows under the row title
  keywordIds: number[];    // TMDB keyword IDs (OR-combined in discover)
}

/**
 * Each vibe has an optional `group` — pickVibes won't select two vibes
 * from the same group in the same feed load (e.g. no "Queer Cinema" AND
 * "Queer History" on the same screen).
 */
interface VibeWithGroup extends VibeCluster { group?: string }

// Vibe clusters are the viewer's personal keyword-driven discovery rows.
// pickVibes() selects 1-2 per feed load; the `group` field prevents two
// vibes from the same group from appearing on the same screen.
//
// DESIGN RULE: nothing here should be hardcoded on every load. Vibes
// rotate randomly. Queer/kink/camp keywords are spread across multiple
// entries in the queer group so they surface frequently without being
// guaranteed. Generic categories like "Indie" or "Horror" don't belong
// here — those are already covered by the genre tabs and curated lists.
const DEFAULT_VIBES: VibeWithGroup[] = [
  { label: 'Queer Cinema', subtitle: 'Stories that see you', keywordIds: [158718, 264384, 300642, 824, 1886], group: 'queer' },
  { label: 'Camp & Desire', subtitle: 'Over the top and proud of it', keywordIds: [155493, 158713, 199817, 264384], group: 'queer' },
  { label: 'Queer History', subtitle: 'The relationships they tried to erase', keywordIds: [158718, 300642, 1886, 824], group: 'queer' },
  { label: 'Road Trip', subtitle: 'Windows down, nowhere to be', keywordIds: [7312] },
  { label: 'DC & Politics', subtitle: 'Power, scandal, and sharp suits', keywordIds: [521, 169086] },
];

/**
 * Get the viewer's personal vibe clusters.
 * Returns stored vibes or defaults.
 */
export function getVibes(): VibeCluster[] {
  try {
    const raw = localStorage.getItem(VIBES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as VibeCluster[];
      if (parsed.length > 0) return parsed;
    }
  } catch { /* ignore */ }
  return DEFAULT_VIBES;
}

/**
 * Save custom vibe clusters (for future UI where users can edit).
 */
export function setVibes(vibes: VibeCluster[]): void {
  try {
    localStorage.setItem(VIBES_KEY, JSON.stringify(vibes));
  } catch { /* ignore */ }
}

/**
 * Pick 1-2 random vibe clusters, never two from the same group.
 * E.g. you'll get "Queer Cinema" OR "Queer History" — never both.
 */
export function pickVibes(count = 2): VibeCluster[] {
  const all: VibeWithGroup[] = getVibes() as VibeWithGroup[];
  const shuffled = [...all].sort(() => Math.random() - 0.5);
  const picked: VibeCluster[] = [];
  const usedGroups = new Set<string>();

  for (const v of shuffled) {
    if (picked.length >= count) break;
    if (v.group && usedGroups.has(v.group)) continue; // skip same-group dupe
    picked.push(v);
    if (v.group) usedGroups.add(v.group);
  }
  return picked;
}

// ── Viewer engagement tracking (powers smart shuffle) ──
//
// Three-signal feedback loop:
//   Taps   (1×)  — interest: you clicked to learn more
//   Watches (3×) — commitment: you sat through the whole thing
//   Ratings (5×) — opinion: you cared enough to score it
//
// All signals decay over time so the algorithm follows where you're going,
// not where you've been. Half-life: ~90 days. The decay is applied at read
// time (getWeightedGenres / getWeightedDecade) so writes stay cheap.

const ENGAGEMENT_KEY = 'seenit_genre_engagement';

/** Signal weight multipliers */
const TAP_WEIGHT = 1;
const WATCH_WEIGHT = 3;
const RATING_WEIGHT = 5;

/** Half-life in milliseconds (~90 days). After 90 days a signal is worth
 *  half as much; after 180 days a quarter, etc. */
const HALF_LIFE_MS = 90 * 24 * 60 * 60 * 1000;

interface EngagementEvent {
  weight: number;  // TAP / WATCH / RATING multiplied by count
  ts: number;      // when it happened
}

interface EngagementData {
  genres: Record<number, number>;   // genre_id → raw weighted score
  decades: Record<string, number>;  // "80s" → raw weighted score
  updated: number;
  /** Per-signal event log — kept small (last 200 events max) for decay calc */
  events?: EngagementEvent[];
  /** Per-genre timestamped events for time-decay scoring */
  genreEvents?: Record<number, EngagementEvent[]>;
  /** Per-decade timestamped events */
  decadeEvents?: Record<string, EngagementEvent[]>;
}

function getEngagementData(): EngagementData {
  try {
    const raw = localStorage.getItem(ENGAGEMENT_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return { genres: {}, decades: {}, updated: Date.now(), genreEvents: {}, decadeEvents: {} };
}

function saveEngagementData(data: EngagementData): void {
  try {
    // Cap event lists to prevent unbounded growth (keep newest 60 per genre/decade)
    if (data.genreEvents) {
      for (const gid of Object.keys(data.genreEvents)) {
        const evts = data.genreEvents[Number(gid)];
        if (evts && evts.length > 60) data.genreEvents[Number(gid)] = evts.slice(0, 60);
      }
    }
    if (data.decadeEvents) {
      for (const dec of Object.keys(data.decadeEvents)) {
        const evts = data.decadeEvents[dec];
        if (evts && evts.length > 60) data.decadeEvents[dec] = evts.slice(0, 60);
      }
    }
    localStorage.setItem(ENGAGEMENT_KEY, JSON.stringify(data));
  } catch { /* ignore */ }
}

const RECENT_TAPS_KEY = 'seenit_recent_taps';
const MAX_RECENT_TAPS = 8;

interface RecentTap {
  genreIds: number[];
  ts: number;
}

/** Compute a year → decade label. Matches the DECADES array in discover.ts. */
function yearToDecade(year: number): string {
  if (year < 1970) return '60s';
  if (year < 1980) return '70s';
  if (year < 1990) return '80s';
  if (year < 2000) return '90s';
  if (year < 2010) return '2000s';
  if (year < 2020) return '2010s';
  return '2020s'; // 2020–present
}

/**
 * Internal: record an engagement event with a given weight.
 */
function recordEngagement(genreIds: number[], year: number | null, weight: number): void {
  try {
    const data = getEngagementData();
    const now = Date.now();
    const evt: EngagementEvent = { weight, ts: now };

    // Update genre tallies + event logs
    if (!data.genreEvents) data.genreEvents = {};
    for (const g of genreIds) {
      data.genres[g] = (data.genres[g] || 0) + weight;
      if (!data.genreEvents[g]) data.genreEvents[g] = [];
      data.genreEvents[g].unshift(evt);
    }

    // Update decade tallies + event logs
    if (year) {
      if (!data.decadeEvents) data.decadeEvents = {};
      const dec = yearToDecade(year);
      data.decades[dec] = (data.decades[dec] || 0) + weight;
      if (!data.decadeEvents[dec]) data.decadeEvents[dec] = [];
      data.decadeEvents[dec].unshift(evt);
    }

    data.updated = now;
    saveEngagementData(data);
  } catch { /* ignore */ }
}

/**
 * Track a poster tap — lightweight interest signal (1×).
 * Call on every poster tap. Also records recent taps for mood detection.
 */
export function trackEngagement(genreIds: number[], year: number | null): void {
  recordEngagement(genreIds, year, TAP_WEIGHT);

  // Recent taps (rolling window for mood detection)
  try {
    let recent: RecentTap[] = [];
    try {
      const raw = localStorage.getItem(RECENT_TAPS_KEY);
      if (raw) recent = JSON.parse(raw);
    } catch { /* ignore */ }
    recent.unshift({ genreIds, ts: Date.now() });
    if (recent.length > MAX_RECENT_TAPS) recent = recent.slice(0, MAX_RECENT_TAPS);
    localStorage.setItem(RECENT_TAPS_KEY, JSON.stringify(recent));
  } catch { /* ignore */ }
}

/**
 * Track a watch — commitment signal (3×).
 * Call when the user marks something as watched.
 */
export function trackWatch(genreIds: number[], year: number | null): void {
  recordEngagement(genreIds, year, WATCH_WEIGHT);
}

/**
 * Track a rating — opinion signal (5×).
 * Call when the user rates something. Higher ratings boost more.
 * A 10/10 = 5× weight, a 1/10 = 1× weight (they still watched it).
 */
export function trackRating(genreIds: number[], year: number | null, rating: number): void {
  // Scale: rating 1-10 maps to weight 1-5 (RATING_WEIGHT)
  const scaled = Math.max(1, Math.round((rating / 10) * RATING_WEIGHT));
  recordEngagement(genreIds, year, scaled);
}

/**
 * Apply time-decay to a list of engagement events and return a weighted score.
 * Uses exponential decay with the configured half-life.
 */
function decayScore(events: EngagementEvent[] | undefined): number {
  if (!events || events.length === 0) return 0;
  const now = Date.now();
  let score = 0;
  for (const evt of events) {
    const age = now - evt.ts;
    // Exponential decay: weight × 0.5^(age / halfLife)
    const decay = Math.pow(0.5, age / HALF_LIFE_MS);
    score += evt.weight * decay;
  }
  return score;
}

/**
 * Get the viewer's top genre IDs by time-decayed weighted engagement.
 * Taps count 1×, watches 3×, ratings up to 5× — all decaying over ~90 days.
 * Returns up to `limit` genre IDs sorted by decayed score.
 */
export function getTopGenres(limit = 5): number[] {
  const data = getEngagementData();

  // If we have timestamped events, use decay scoring
  if (data.genreEvents && Object.keys(data.genreEvents).length > 0) {
    const scored: [number, number][] = [];
    for (const [gid, events] of Object.entries(data.genreEvents)) {
      const s = decayScore(events);
      if (s > 0.01) scored.push([Number(gid), s]);
    }
    return scored
      .sort(([, a], [, b]) => b - a)
      .slice(0, limit)
      .map(([id]) => id);
  }

  // Fallback: raw tallies (pre-upgrade data)
  return Object.entries(data.genres)
    .sort(([, a], [, b]) => b - a)
    .slice(0, limit)
    .map(([id]) => Number(id));
}

/**
 * Get the viewer's most-engaged decade label (e.g. "80s") by decayed score.
 */
export function getTopDecade(): string | null {
  const data = getEngagementData();

  // If we have timestamped events, use decay scoring
  if (data.decadeEvents && Object.keys(data.decadeEvents).length > 0) {
    let best: string | null = null;
    let bestScore = 0;
    for (const [dec, events] of Object.entries(data.decadeEvents)) {
      const s = decayScore(events);
      if (s > bestScore) { best = dec; bestScore = s; }
    }
    return best;
  }

  // Fallback: raw tallies
  const entries = Object.entries(data.decades);
  if (entries.length === 0) return null;
  entries.sort(([, a], [, b]) => b - a);
  return entries[0][0];
}

// ── Mood context engine ──
// Reads the clock, the calendar, and the viewer's recent emotional trajectory
// to generate a sense of *what kind of night this is*.

/**
 * Genre IDs by emotional register — NOT by darkness or scariness.
 * "Heavy" = slow, emotional, slow burn (the kind of film you sit with).
 * "Light" = fun, fast, energetic.
 * "Intense" = gripping tension, edge-of-seat.
 * Horror is intense, not heavy. Foreign films aren't inherently heavy.
 */
const HEAVY_GENRES = new Set([18, 36, 99]);       // Drama, History, Documentary — slow burn
const LIGHT_GENRES = new Set([35, 16, 10402, 28, 12]); // Comedy, Animation, Music, Action, Adventure
const INTENSE_GENRES = new Set([27, 53, 878, 80, 9648, 10752]); // Horror, Thriller, Sci-Fi, Crime, Mystery, War

export interface MoodContext {
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'latenight';
  dayName: string;
  isWeekend: boolean;
  recentTone: 'heavy' | 'light' | 'intense' | 'mixed' | 'unknown';
  hasHistory: boolean; // have they used the app enough for us to read them
}

export function getMoodContext(): MoodContext {
  const now = new Date();
  const hour = now.getHours();
  const day = now.getDay(); // 0=Sun, 6=Sat

  const timeOfDay: MoodContext['timeOfDay'] =
    hour < 12 ? 'morning'
    : hour < 17 ? 'afternoon'
    : hour < 21 ? 'evening'
    : 'latenight';

  const dayName = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][day];
  const isWeekend = day === 0 || day === 5 || day === 6; // Fri-Sun

  // Read recent taps to detect emotional trajectory
  let recentTone: MoodContext['recentTone'] = 'unknown';
  let hasHistory = false;
  try {
    const raw = localStorage.getItem(RECENT_TAPS_KEY);
    if (raw) {
      const taps: RecentTap[] = JSON.parse(raw);
      // Only consider taps from the last 7 days
      const recent = taps.filter(t => Date.now() - t.ts < 7 * 24 * 60 * 60 * 1000);
      if (recent.length >= 3) {
        hasHistory = true;
        const allGenres = recent.flatMap(t => t.genreIds);
        const heavyCount = allGenres.filter(g => HEAVY_GENRES.has(g)).length;
        const lightCount = allGenres.filter(g => LIGHT_GENRES.has(g)).length;
        const intenseCount = allGenres.filter(g => INTENSE_GENRES.has(g)).length;
        const total = allGenres.length || 1;

        if (heavyCount / total > 0.4) recentTone = 'heavy';
        else if (lightCount / total > 0.4) recentTone = 'light';
        else if (intenseCount / total > 0.4) recentTone = 'intense';
        else recentTone = 'mixed';
      }
    }
  } catch { /* ignore */ }

  return { timeOfDay, dayName, isWeekend, recentTone, hasHistory };
}

// ── Dynamic Phantom Patron system ──
//
// The bookshop has "regulars" and "passersby" — imaginary cinephiles whose
// taste overlaps with the viewer's but extends in surprising directions.
// Unlike fixed archetypes, patrons are EMERGENT: spawned from the viewer's
// own engagement clusters, then mutated to explore adjacent taste territory.
//
// Three mechanisms drive the system:
//   1. SPAWNING — engagement clusters crystallize into new patrons, offset
//      from the viewer's center (adjacent genres, shifted decades, injected
//      mood keywords). The offset IS the serendipity.
//   2. EVOLUTION — patrons the viewer engages with sharpen (vector shifts
//      toward what was clicked/watched). Ignored patrons drift (their vectors
//      randomize). Natural lifecycle: resonate → sharpen, ignore → dissolve.
//   3. RETIREMENT — patrons whose energy drops below threshold are retired.
//      New patrons spawn to fill the gap. The shop is always alive.
//
// Each patron is a TasteVector — a point in multi-dimensional taste space
// (genres × decades × mood keywords × language × obscurity). Shelf labels
// are composed from the vector, not stored as fixed strings.

const PATRON_STORE_KEY = 'seenit_dynamic_patrons';
const PATRON_HISTORY_KEY = 'seenit_patron_history';
const PATRON_MAX = 12;           // max patrons alive at once
const PATRON_MIN = 6;            // always keep at least this many
const SPAWN_CLUSTER_MIN = 3;     // 3+ engagements in a cluster to spawn
const ENERGY_DECAY = 0.08;       // energy lost per session without engagement
const ENERGY_BOOST = 0.15;       // energy gained when viewer engages
const ENERGY_RETIRE = 0.15;      // retire below this threshold
const REGULAR_THRESHOLD = 3;     // 3+ appearances with engagement = regular
const REGULAR_WINDOW_MS = 14 * 24 * 60 * 60 * 1000;

// ── Genre adjacency map ──
// Maps each TMDB genre to its "neighbors" — genres that share thematic DNA.
// Used to mutate patron vectors: a thriller cluster might spawn a patron
// that leans into mystery or crime or noir.
const GENRE_NEIGHBORS: Record<number, number[]> = {
  28: [12, 53, 80, 878, 10752],     // Action → Adventure, Thriller, Crime, Sci-Fi, War
  12: [28, 14, 878, 37],             // Adventure → Action, Fantasy, Sci-Fi, Western
  16: [14, 35, 10751],               // Animation → Fantasy, Comedy, Family
  35: [10749, 18, 16],               // Comedy → Romance, Drama, Animation
  80: [53, 9648, 18, 28],            // Crime → Thriller, Mystery, Drama, Action
  99: [36, 10752, 878],              // Documentary → History, War, Sci-Fi
  18: [10749, 80, 36, 53],           // Drama → Romance, Crime, History, Thriller
  14: [12, 16, 878],                 // Fantasy → Adventure, Animation, Sci-Fi
  36: [18, 10752, 99],               // History → Drama, War, Documentary
  27: [53, 9648, 878],               // Horror → Thriller, Mystery, Sci-Fi
  10402: [18, 99],                    // Music → Drama, Documentary
  9648: [80, 53, 27, 18],            // Mystery → Crime, Thriller, Horror, Drama
  10749: [35, 18],                    // Romance → Comedy, Drama
  878: [27, 53, 12, 14],             // Sci-Fi → Horror, Thriller, Adventure, Fantasy
  10770: [18, 35],                    // TV Movie → Drama, Comedy
  53: [80, 27, 9648, 28],            // Thriller → Crime, Horror, Mystery, Action
  10752: [36, 18, 28],               // War → History, Drama, Action
  37: [28, 12, 18],                   // Western → Action, Adventure, Drama
  10751: [16, 35, 14],               // Family → Animation, Comedy, Fantasy
};

// ── Mood keyword pools ──
// Evocative TMDB keyword IDs grouped by mood. When a patron spawns, 1-2
// keywords from an adjacent mood pool get injected into their vector.
const MOOD_POOLS: Record<string, number[]> = {
  paranoia: [944, 3446, 14601, 5565],           // conspiracy, politics, surveillance
  nostalgia: [156218, 18035, 10683],             // coming-of-age, 1980s, americana
  desire: [158718, 155493, 264384, 158713],      // lgbt, camp, drag, bdsm
  wanderlust: [7312, 1513, 9648],                // road trip, escape, journey
  dread: [261178, 224636, 6152, 163053],         // folk horror, body horror, cosmic horror
  rebellion: [4565, 11322, 5340],                // punk, counterculture, protest
  solitude: [9673, 818, 156218],                 // isolation, loneliness, coming-of-age
  spectacle: [9882, 779, 5927],                  // heist, car chase, showdown
  intrigue: [521, 169086, 6149],                 // washington dc, political drama, power
};
const MOOD_NAMES = Object.keys(MOOD_POOLS);

// ── Shelf label vocabulary ──
// Fragments composed into evocative shelf labels based on vector properties.
// Format: [primary feel] + [optional modifier]. Never the same label twice.

const LABEL_ERA: Record<string, string[]> = {
  '60s': ['Vinyl-era', 'Before the revolution', 'The long sixties'],
  '70s': ['New Hollywood', 'Post-Watergate', 'Grain and grit'],
  '80s': ['Neon & paranoia', 'Reagan-era', 'Synth and shadow'],
  '90s': ['Pre-internet', 'End of the century', 'The last analog decade'],
  '2000s': ['Post-9/11', 'Early digital', 'Turn of the millennium'],
  '2010s': ['Peak streaming', 'The algorithm age', 'Last decade\'s best'],
  '2020s': ['Right now', 'Fresh off the press', 'Still in theaters'],
};

const LABEL_MOOD: Record<string, string[]> = {
  paranoia: ['whispers', 'who\'s watching', 'trust no one'],
  nostalgia: ['remember when', 'before everything changed', 'golden hour'],
  desire: ['after dark', 'skin and smoke', 'the things we want'],
  wanderlust: ['postcards', 'far from home', 'the open road'],
  dread: ['don\'t look away', 'something\'s wrong', 'the quiet before'],
  rebellion: ['burn it down', 'the ones they banned', 'against the grain'],
  solitude: ['alone with this', 'empty rooms', 'the long night'],
  spectacle: ['hold your breath', 'the big screen demands it', 'pure cinema'],
  intrigue: ['behind closed doors', 'power plays', 'the corridors'],
};

const LABEL_GENRE: Record<number, string[]> = {
  28: ['adrenaline', 'fists and fire', 'full throttle'],
  12: ['the map ends here', 'beyond the edge', 'uncharted'],
  35: ['laughing at the wrong things', 'sharp and mean', 'the funny shelf'],
  80: ['case files', 'crooked lines', 'blood money'],
  99: ['the real world', 'see for yourself', 'evidence'],
  18: ['the weight of it', 'feel everything', 'slow burn'],
  14: ['where the map ends', 'impossible places', 'once upon'],
  27: ['sleep with the lights on', 'the other shelf', 'nightmares'],
  9648: ['every frame is a clue', 'whodunit', 'unsolved'],
  878: ['future tense', 'what if', 'the universe doesn\'t care'],
  53: ['edge of the seat', 'ticking clock', 'no way out'],
  10749: ['the heart wants', 'two people', 'chemistry'],
  36: ['dispatches from another era', 'the past isn\'t dead', 'history rhymes'],
  10752: ['the cost of war', 'frontlines', 'sacrifice'],
  37: ['dust and honor', 'the frontier', 'high noon'],
  16: ['hand-drawn dreams', 'animated brilliance', 'frame by frame'],
};

const LABEL_OBSCURITY = [
  'the ones the algorithm missed',
  'you probably haven\'t seen',
  'from the back of the shelf',
  'dusted off just for you',
  'buried treasure',
];

const LABEL_POPULAR = [
  'everyone\'s talking about these',
  'undeniable',
  'the obvious shelf (for good reason)',
];

// ── Interfaces ──

export interface TasteVector {
  /** Primary TMDB genre ID */
  genrePrimary: number;
  /** Secondary TMDB genre ID (for intersection queries) */
  genreSecondary: number | null;
  /** Center year for decade preference */
  decadeCenter: number;
  /** How wide the decade spread is (±years) */
  decadeSpread: number;
  /** Mood keyword IDs from MOOD_POOLS (1-2) */
  moodKeywords: number[];
  /** Mood pool name for label generation */
  moodName: string;
  /** Language preference: 'any', 'en', or ISO code */
  language: 'any' | string;
  /** Vote count ceiling — low = obscure, null = any */
  voteCeiling: number | null;
  /** Vote floor — higher = more acclaimed */
  voteFloor: number;
  /** Minimum rating */
  ratingFloor: number;
}

export interface DynamicPatron {
  /** Unique identifier */
  id: string;
  /** The patron's taste coordinates */
  vector: TasteVector;
  /** How many sessions this patron has existed */
  age: number;
  /** 0-1, decays without engagement. Retire below ENERGY_RETIRE */
  energy: number;
  /** Timestamp of last time this patron's shelf was shown */
  lastShown: number;
  /** Number of times the viewer tapped/watched something from this shelf */
  engagements: number;
  /** Which engagement cluster birthed this patron */
  spawnedFrom: string;
  /** Becomes true after 3+ appearances with engagement in 14 days */
  isRegular: boolean;
  /** Generated shelf title (recomputed on load, but cached for consistency) */
  shelfTitle: string;
  /** Generated shelf note */
  shelfNote: string;
  /** Attribution line shown under patron shelves */
  attribution: string;
}

interface PatronVisit {
  patronId: string;
  ts: number;
  hadEngagement: boolean;
}

// ── Patron persistence ──

function getStoredPatrons(): DynamicPatron[] {
  try {
    const raw = localStorage.getItem(PATRON_STORE_KEY);
    if (raw) return JSON.parse(raw) as DynamicPatron[];
  } catch { /* ignore */ }
  return [];
}

function savePatrons(patrons: DynamicPatron[]): void {
  try {
    // Cap to prevent unbounded growth
    const capped = patrons.slice(0, PATRON_MAX);
    localStorage.setItem(PATRON_STORE_KEY, JSON.stringify(capped));
  } catch { /* ignore */ }
}

export function getPatronHistory(): PatronVisit[] {
  try {
    const raw = localStorage.getItem(PATRON_HISTORY_KEY);
    if (raw) return JSON.parse(raw) as PatronVisit[];
  } catch { /* ignore */ }
  return [];
}

function savePatronHistory(history: PatronVisit[]): void {
  try {
    localStorage.setItem(PATRON_HISTORY_KEY, JSON.stringify(history.slice(0, 60)));
  } catch { /* ignore */ }
}

// ── Shelf label generation ──
// Composes an evocative label from the patron's vector. Never algorithmic-
// sounding — feels like a handwritten card left on a shelf.

function generateShelfLabel(v: TasteVector): { title: string; note: string; attribution: string } {
  const r = () => Math.random();

  // Pick label fragments from each dimension
  const eraKey = yearToDecade(v.decadeCenter);
  const eraOptions = LABEL_ERA[eraKey] || LABEL_ERA['2020s'];
  const moodOptions = LABEL_MOOD[v.moodName] || LABEL_MOOD['spectacle'];
  const genreOptions = LABEL_GENRE[v.genrePrimary] || ['someone\'s favorites', 'worth your time'];

  // Obscurity-based labels for niche patrons
  const isObscure = v.voteCeiling !== null && v.voteCeiling < 1000;
  const obscurityLabels = isObscure ? LABEL_OBSCURITY : LABEL_POPULAR;

  // Compose: 40% mood-led, 30% era-led, 20% genre-led, 10% obscurity-led
  const roll = r();
  let title: string;
  let note: string;

  if (roll < 0.4) {
    title = moodOptions[Math.floor(r() * moodOptions.length)];
    note = eraOptions[Math.floor(r() * eraOptions.length)];
  } else if (roll < 0.7) {
    title = eraOptions[Math.floor(r() * eraOptions.length)];
    note = genreOptions[Math.floor(r() * genreOptions.length)];
  } else if (roll < 0.9) {
    title = genreOptions[Math.floor(r() * genreOptions.length)];
    note = moodOptions[Math.floor(r() * moodOptions.length)];
  } else {
    title = obscurityLabels[Math.floor(r() * obscurityLabels.length)];
    note = moodOptions[Math.floor(r() * moodOptions.length)];
  }

  // Capitalize first letter
  title = title.charAt(0).toUpperCase() + title.slice(1);

  // Attribution — a brief persona hint, not a fixed name
  const attributionFragments = [
    'A regular', 'Someone passing through', 'The person in the corner',
    'A familiar face', 'Someone who knows this section well',
    'The one who always finds the good ones', 'A friend of a friend',
    'Back again', 'Just browsing', 'The quiet one with great taste',
  ];
  const attribution = attributionFragments[Math.floor(r() * attributionFragments.length)];

  return { title, note, attribution };
}

// ── Engagement cluster detection ──
// Scans the viewer's recent engagement to find clusters (co-occurring genre +
// decade patterns). Each cluster can spawn a patron.

interface EngagementCluster {
  /** Cluster ID for dedup (genre:decade) */
  id: string;
  genreId: number;
  decade: string;
  score: number;
}

function detectEngagementClusters(): EngagementCluster[] {
  const data = getEngagementData();
  if (!data.genreEvents) return [];

  const clusters: EngagementCluster[] = [];

  // Score each genre×decade combination
  for (const [gidStr, events] of Object.entries(data.genreEvents)) {
    const gid = Number(gidStr);
    if (!events || events.length < SPAWN_CLUSTER_MIN) continue;

    // Get the genre's decayed score
    const genreScore = decayScore(events);
    if (genreScore < 1) continue;

    // Use the viewer's overall top decade as the cluster's decade
    const topDec = getTopDecade() || '2020s';
    const clusterId = `${gid}:${topDec}`;

    clusters.push({
      id: clusterId,
      genreId: gid,
      decade: topDec,
      score: genreScore,
    });
  }

  // Sort by score, return top clusters
  return clusters.sort((a, b) => b.score - a.score).slice(0, 8);
}

// ── Patron spawning ──
// Creates a new patron from an engagement cluster, mutated to explore
// adjacent taste territory.

function decadeToYear(decade: string): number {
  const map: Record<string, number> = {
    '60s': 1965, '70s': 1975, '80s': 1985, '90s': 1995,
    '2000s': 2005, '2010s': 2015, '2020s': 2023,
  };
  return map[decade] || 2020;
}

function spawnPatron(cluster: EngagementCluster): DynamicPatron {
  const r = () => Math.random();

  // Primary genre: 50% keep cluster genre, 50% shift to adjacent
  const neighbors = GENRE_NEIGHBORS[cluster.genreId] || [];
  const genrePrimary = r() < 0.5 && neighbors.length > 0
    ? neighbors[Math.floor(r() * neighbors.length)]
    : cluster.genreId;

  // Secondary genre: pick from primary's neighbors (or null)
  const secNeighbors = GENRE_NEIGHBORS[genrePrimary] || [];
  const genreSecondary = r() < 0.6 && secNeighbors.length > 0
    ? secNeighbors[Math.floor(r() * secNeighbors.length)]
    : null;

  // Decade: shift ±0-20 years from cluster center
  const baseYear = decadeToYear(cluster.decade);
  const yearShift = Math.round((r() - 0.5) * 40); // ±20 years
  const decadeCenter = Math.max(1960, Math.min(2026, baseYear + yearShift));
  const decadeSpread = 5 + Math.floor(r() * 15); // ±5 to ±20 years

  // Mood: pick a random mood pool, inject 1-2 keywords
  const moodName = MOOD_NAMES[Math.floor(r() * MOOD_NAMES.length)];
  const pool = MOOD_POOLS[moodName];
  const kwCount = 1 + Math.floor(r() * 2);
  const shuffledPool = [...pool].sort(() => r() - 0.5);
  const moodKeywords = shuffledPool.slice(0, kwCount);

  // Language: 75% any, 15% English-only, 10% specific world language
  const worldLangs = ['ko', 'ja', 'fr', 'es', 'de', 'it', 'pt', 'zh', 'hi', 'sv', 'da'];
  let language: string = 'any';
  const langRoll = r();
  if (langRoll < 0.15) language = 'en';
  else if (langRoll < 0.25) language = worldLangs[Math.floor(r() * worldLangs.length)];

  // Obscurity: 40% niche (low vote ceiling), 60% open
  const voteCeiling = r() < 0.4 ? 200 + Math.floor(r() * 800) : null;
  const voteFloor = voteCeiling ? 20 : 50 + Math.floor(r() * 200);
  const ratingFloor = 5.5 + r() * 2; // 5.5 – 7.5

  const vector: TasteVector = {
    genrePrimary,
    genreSecondary,
    decadeCenter,
    decadeSpread,
    moodKeywords,
    moodName,
    language,
    voteCeiling,
    voteFloor,
    ratingFloor: Math.round(ratingFloor * 10) / 10,
  };

  const label = generateShelfLabel(vector);

  return {
    id: `p-${Date.now().toString(36)}-${Math.floor(r() * 1000).toString(36)}`,
    vector,
    age: 0,
    energy: 0.7,
    engagements: 0,
    lastShown: 0,
    spawnedFrom: cluster.id,
    isRegular: false,
    shelfTitle: label.title,
    shelfNote: label.note,
    attribution: label.attribution,
  };
}

// ── Patron evolution ──
// After each session, patrons evolve based on whether the viewer engaged
// with their shelf.

function evolvePatrons(patrons: DynamicPatron[]): DynamicPatron[] {
  const now = Date.now();
  const history = getPatronHistory();
  const recentCutoff = now - REGULAR_WINDOW_MS;

  return patrons.map(p => {
    const updated = { ...p, age: p.age + 1 };

    // Count recent appearances with engagement for regular detection
    const recentAppearances = history.filter(
      v => v.patronId === p.id && v.ts >= recentCutoff && v.hadEngagement
    ).length;
    updated.isRegular = recentAppearances >= REGULAR_THRESHOLD;

    // Energy decay for patrons not shown recently (>3 days)
    if (now - p.lastShown > 3 * 24 * 60 * 60 * 1000) {
      updated.energy = Math.max(0, p.energy - ENERGY_DECAY);
    }

    // Regulars decay slower
    if (updated.isRegular) {
      updated.energy = Math.max(updated.energy, 0.3);
    }

    // Refresh shelf labels periodically (every 5 sessions) to keep them alive
    if (updated.age % 5 === 0) {
      const label = generateShelfLabel(updated.vector);
      updated.shelfTitle = label.title;
      updated.shelfNote = label.note;
      updated.attribution = label.attribution;
    }

    return updated;
  });
}

// ── Patron engagement feedback ──
// Call when the viewer taps/watches something from a patron's shelf.

export function recordPatronEngagement(patronId: string): void {
  const patrons = getStoredPatrons();
  const idx = patrons.findIndex(p => p.id === patronId);
  if (idx === -1) return;

  const patron = { ...patrons[idx] };
  patron.energy = Math.min(1, patron.energy + ENERGY_BOOST);
  patron.engagements++;

  // Slight vector drift toward engagement — the patron "learns"
  // (We don't have the specific item's genres here, so we just
  // reinforce the patron's existing direction by boosting energy.
  // Future: pass genre IDs and shift vector.)

  patrons[idx] = patron;
  savePatrons(patrons);

  // Record visit with engagement flag
  const history = getPatronHistory();
  const recent = history.find(v => v.patronId === patronId && Date.now() - v.ts < 60000);
  if (recent) {
    recent.hadEngagement = true;
    savePatronHistory(history);
  }
}

// ── Main entry point: get active patrons for this feed load ──
//
// Orchestrates the full lifecycle:
//   1. Load stored patrons
//   2. Evolve (age, energy decay, regular detection)
//   3. Retire dead patrons
//   4. Spawn new patrons from engagement clusters if needed
//   5. Score and pick 3-4 for this load
//   6. Save state

export function pickActivePatrons(
  topGenres: number[],
  count = 4,
): DynamicPatron[] {
  let patrons = getStoredPatrons();

  // ── Step 1: Evolve existing patrons ──
  patrons = evolvePatrons(patrons);

  // ── Step 2: Retire exhausted patrons ──
  patrons = patrons.filter(p => p.energy >= ENERGY_RETIRE || p.isRegular);

  // ── Step 3: Spawn new patrons if below minimum ──
  const clusters = detectEngagementClusters();
  const existingSpawns = new Set(patrons.map(p => p.spawnedFrom));

  while (patrons.length < PATRON_MIN && clusters.length > 0) {
    // Find a cluster that hasn't already spawned a living patron
    const available = clusters.filter(c => !existingSpawns.has(c.id));
    const cluster = available.length > 0 ? available[0] : clusters[0];

    const newPatron = spawnPatron(cluster);
    patrons.push(newPatron);
    existingSpawns.add(cluster.id);

    // Remove used cluster
    const ci = clusters.indexOf(cluster);
    if (ci >= 0) clusters.splice(ci, 1);
  }

  // Also spawn 1-2 surprise patrons from weaker clusters for novelty
  if (patrons.length < PATRON_MAX && clusters.length > 0) {
    const surpriseCount = 1 + Math.floor(Math.random() * 2);
    const weakClusters = clusters.slice(-surpriseCount);
    for (const c of weakClusters) {
      if (patrons.length >= PATRON_MAX) break;
      if (!existingSpawns.has(c.id) || Math.random() < 0.3) {
        patrons.push(spawnPatron(c));
      }
    }
  }

  // ── Fallback: if no engagement data yet, seed with diverse patrons ──
  // Deliberately eclectic — NOT the obvious genre buckets. Each seed
  // combines an unexpected genre×decade pairing so the feed never
  // looks like a streaming service's default homepage rows.
  if (patrons.length === 0) {
    const seeds: Array<{ genre: number; decade: string }> = [
      { genre: 9648, decade: '70s' },   // mystery × 70s paranoia thrillers
      { genre: 878, decade: '80s' },    // sci-fi × practical-effects era
      { genre: 99, decade: '2000s' },   // documentary × peak nonfiction era
      { genre: 80, decade: '90s' },     // crime × neo-noir heyday
      { genre: 14, decade: '2010s' },   // fantasy × modern auteur fantasy
      { genre: 36, decade: '60s' },     // history × new wave cinema
      { genre: 53, decade: '2020s' },   // thriller × now
      { genre: 37, decade: '70s' },     // western × revisionist era
    ];
    // Shuffle seeds so each cold-start looks different
    for (let i = seeds.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [seeds[i], seeds[j]] = [seeds[j], seeds[i]];
    }
    for (let i = 0; i < PATRON_MIN; i++) {
      const s = seeds[i % seeds.length];
      const fakeCluster: EngagementCluster = {
        id: `seed:${s.genre}:${s.decade}`,
        genreId: s.genre,
        decade: s.decade,
        score: 1,
      };
      patrons.push(spawnPatron(fakeCluster));
    }
  }

  // ── Step 4: Score and pick for this load ──
  const now = Date.now();
  const topSet = new Set(topGenres);

  const scored = patrons.map(p => {
    let score = 0;

    // Affinity: how much does this patron's taste overlap with the viewer's?
    if (topSet.has(p.vector.genrePrimary)) score += 0.3;
    if (p.vector.genreSecondary && topSet.has(p.vector.genreSecondary)) score += 0.15;

    // Diversity bonus: patrons that DON'T overlap get a surprise bonus
    if (!topSet.has(p.vector.genrePrimary)) score += 0.1;

    // Energy: healthy patrons are more likely to appear
    score += p.energy * 0.3;

    // Regular bonus
    if (p.isRegular) score += 0.35;

    // Recency penalty: don't show same patron every load
    if (now - p.lastShown < 30000) score -= 0.5; // shown this session
    else if (now - p.lastShown < 24 * 60 * 60 * 1000) score -= 0.1; // shown today

    // Novelty bonus for never-shown patrons
    if (p.lastShown === 0) score += 0.2;

    // Randomness (±0.25)
    score += (Math.random() - 0.5) * 0.5;

    return { patron: p, score };
  });

  scored.sort((a, b) => b.score - a.score);
  const picked = scored.slice(0, count).map(s => s.patron);

  // Record visits and update lastShown
  const history = getPatronHistory();
  for (const p of picked) {
    p.lastShown = now;
    history.unshift({ patronId: p.id, ts: now, hadEngagement: false });
  }
  savePatronHistory(history);

  // Save updated state
  savePatrons(patrons);

  // Shuffle so order isn't score-ranked
  for (let i = picked.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [picked[i], picked[j]] = [picked[j], picked[i]];
  }

  return picked;
}

/**
 * Get cache statistics (includes byte-level size tracking).
 */
export function getCacheStats(): {
  cacheEntries: number;
  lookupEntries: number;
  totalSize: number;
  totalBytes: number;
  budgetBytes: number;
  budgetPct: number;
} {
  try {
    const keys = Object.keys(localStorage);
    const cacheKeys = keys.filter((k) => k.startsWith(CACHE_PREFIX));
    const lookupKeys = keys.filter((k) => k.startsWith(LOOKUP_PREFIX));

    let totalSize = 0;
    keys.forEach((key) => {
      if (key.startsWith('seenit_')) {
        const item = localStorage.getItem(key);
        totalSize += item ? item.length : 0;
      }
    });

    const totalBytes = getStorageBytes();

    return {
      cacheEntries: cacheKeys.length,
      lookupEntries: lookupKeys.length,
      totalSize,
      totalBytes,
      budgetBytes: STORAGE_BUDGET_BYTES,
      budgetPct: Math.round((totalBytes / STORAGE_BUDGET_BYTES) * 100),
    };
  } catch (error) {
    console.error('Error getting cache stats:', error);
    return { cacheEntries: 0, lookupEntries: 0, totalSize: 0, totalBytes: 0, budgetBytes: STORAGE_BUDGET_BYTES, budgetPct: 0 };
  }
}
