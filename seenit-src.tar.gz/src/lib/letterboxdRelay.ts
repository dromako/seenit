/**
 * Letterboxd Relay — silent sync from PWA to the Cloudflare Worker
 * that pushes the CSV to Letterboxd.
 *
 * Architecture:
 *   PWA → POST /ratings (CSV) → Worker stores in KV
 *   Worker cron daily → POST letterboxd.com/films/import/
 *
 * Config lives in localStorage so the relay URL and auth token aren't
 * baked into the deployed bundle. Set them once via Settings → Letterboxd.
 *
 * This module is fire-and-forget: it never blocks the UI, never throws
 * to the caller, and writes its status to localStorage for the Settings
 * page to display.
 */

import { getLetterboxdExportCSV } from './export';

const RELAY_URL_KEY = 'seenit_relay_url';
const RELAY_TOKEN_KEY = 'seenit_relay_token';
const RELAY_STATUS_KEY = 'seenit_relay_status';
const LAST_PUSH_KEY = 'seenit_relay_last_push';

// Don't push more than once an hour to avoid spamming the Worker on
// every app open. Worker dedupes on identical CSVs anyway, but this
// saves cycles.
const PUSH_COOLDOWN_MS = 60 * 60 * 1000;

export interface RelayStatus {
  lastAttempt: string | null;     // ISO timestamp
  lastSuccess: string | null;     // ISO timestamp of last 2xx
  lastError: string | null;       // error message
  rowsPushed: number;             // count from last success
  // Mirror of Worker /status for the Settings UI
  workerLastPwaSync?: string | null;
  workerLastLetterboxdSync?: string | null;
  workerLastError?: { ts: string; message: string } | null;
  workerHasStoredCsv?: boolean;
  workerStoredRows?: number;
}

function read<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch { return null; }
}

function write(key: string, value: unknown): void {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* ignore */ }
}

export function getRelayConfig(): { url: string; token: string } | null {
  const url = localStorage.getItem(RELAY_URL_KEY);
  const token = localStorage.getItem(RELAY_TOKEN_KEY);
  if (!url || !token) return null;
  return { url: url.replace(/\/+$/, ''), token };
}

export function setRelayConfig(url: string, token: string): void {
  localStorage.setItem(RELAY_URL_KEY, url.trim());
  localStorage.setItem(RELAY_TOKEN_KEY, token.trim());
}

export function clearRelayConfig(): void {
  localStorage.removeItem(RELAY_URL_KEY);
  localStorage.removeItem(RELAY_TOKEN_KEY);
  localStorage.removeItem(RELAY_STATUS_KEY);
  localStorage.removeItem(LAST_PUSH_KEY);
}

export function getRelayStatus(): RelayStatus {
  return read<RelayStatus>(RELAY_STATUS_KEY) || {
    lastAttempt: null,
    lastSuccess: null,
    lastError: null,
    rowsPushed: 0,
  };
}

function setStatus(patch: Partial<RelayStatus>): void {
  const cur = getRelayStatus();
  write(RELAY_STATUS_KEY, { ...cur, ...patch });
}

/**
 * Send the Letterboxd CSV to the relay Worker.
 * No-op if config is missing, no CSV is present, or we pushed recently.
 * Never throws. Updates RelayStatus for the Settings UI.
 */
export async function pushToRelay(force = false): Promise<void> {
  const cfg = getRelayConfig();
  if (!cfg) return; // user hasn't configured the relay yet

  const csv = getLetterboxdExportCSV();
  if (!csv) return;
  if (csv.split('\n').length < 2) return; // header only

  const lastPushRaw = localStorage.getItem(LAST_PUSH_KEY);
  const lastPushTs = lastPushRaw ? Number(lastPushRaw) : 0;
  if (!force && Date.now() - lastPushTs < PUSH_COOLDOWN_MS) return;

  const now = new Date().toISOString();
  setStatus({ lastAttempt: now });

  try {
    const res = await fetch(`${cfg.url}/ratings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/csv',
        'X-Auth-Token': cfg.token,
      },
      body: csv,
    });
    if (!res.ok) {
      const text = await res.text();
      setStatus({ lastError: `Relay ${res.status}: ${text.slice(0, 200)}` });
      return;
    }
    const data = await res.json() as { ok: boolean; rows: number };
    setStatus({
      lastSuccess: now,
      lastError: null,
      rowsPushed: data.rows ?? 0,
    });
    localStorage.setItem(LAST_PUSH_KEY, String(Date.now()));
  } catch (err) {
    setStatus({ lastError: err instanceof Error ? err.message : String(err) });
  }
}

/**
 * Pull the Worker's view of the world for the Settings UI.
 * Returns the same RelayStatus shape with worker* fields populated.
 */
export async function refreshRelayStatus(): Promise<RelayStatus> {
  const cfg = getRelayConfig();
  const cur = getRelayStatus();
  if (!cfg) return cur;
  try {
    const res = await fetch(`${cfg.url}/status`);
    if (!res.ok) return cur;
    const data = await res.json() as {
      lastPwaSync: string | null;
      lastLetterboxdSync: string | null;
      lastError: { ts: string; message: string } | null;
      hasStoredCsv: boolean;
      storedRows: number;
    };
    const merged: RelayStatus = {
      ...cur,
      workerLastPwaSync: data.lastPwaSync,
      workerLastLetterboxdSync: data.lastLetterboxdSync,
      workerLastError: data.lastError,
      workerHasStoredCsv: data.hasStoredCsv,
      workerStoredRows: data.storedRows,
    };
    write(RELAY_STATUS_KEY, merged);
    return merged;
  } catch {
    return cur;
  }
}
