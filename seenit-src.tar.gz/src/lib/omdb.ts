/**
 * OMDB API Client
 * Handles IMDB ratings and Metacritic scores.
 *
 * Self-throttling: OMDB free tier is 1000 req/day. When that quota trips
 * (401 + "Request limit reached!"), we set a circuit breaker that fails
 * open (returns empty ratings) for the rest of the UTC day. This keeps
 * the Library page from hanging on 1000+ sequential 401s.
 */

const OMDB_BASE_URL = 'https://www.omdbapi.com';
const OMDB_API_KEY = import.meta.env.VITE_OMDB_API_KEY;

// Circuit breaker — persists across reloads via localStorage.
// Value is the UTC midnight (ms) when the daily quota resets.
const QUOTA_KEY = 'seenit_omdb_quota_blocked_until';

interface OMDBResponse {
  Title: string;
  imdbID: string;
  imdbRating: string;
  Metascore: string;
  Ratings: Array<{
    Source: string;
    Value: string;
  }>;
  Response: string;
  Error?: string;
}

export interface RatingsObject {
  imdb: number | null;
  metacritic: number | null;
  rottenTomatoes: string | null;
}

const EMPTY: RatingsObject = { imdb: null, metacritic: null, rottenTomatoes: null };

function nextUtcMidnightMs(): number {
  const d = new Date();
  return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + 1, 0, 0, 0, 0);
}

function quotaIsBlocked(): boolean {
  try {
    const v = localStorage.getItem(QUOTA_KEY);
    if (!v) return false;
    const until = parseInt(v, 10);
    if (Date.now() < until) return true;
    // Expired — clear it
    localStorage.removeItem(QUOTA_KEY);
    return false;
  } catch {
    return false;
  }
}

function tripQuotaBreaker(): void {
  try {
    const until = nextUtcMidnightMs();
    localStorage.setItem(QUOTA_KEY, String(until));
    console.warn('[OMDB] Daily quota exhausted — disabling OMDB enrichment until', new Date(until).toISOString());
  } catch {
    /* ignore */
  }
}

/**
 * Fetch with timeout — OMDB sometimes hangs, which blocks the ratings row.
 */
async function fetchWithTimeout(url: string, timeoutMs = 6000): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { signal: controller.signal });
    return response;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Get OMDB data by IMDB ID.
 * Returns parsed ratings object with IMDB and Metacritic scores.
 * Fails open on quota exhaustion, network error, or any non-2xx.
 */
export async function getOMDBData(imdbId: string): Promise<RatingsObject> {
  if (!imdbId || !OMDB_API_KEY) return EMPTY;
  if (quotaIsBlocked()) return EMPTY;

  const url = `${OMDB_BASE_URL}/?apikey=${OMDB_API_KEY}&i=${encodeURIComponent(imdbId)}`;

  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const response = await fetchWithTimeout(url);

      // 401 = invalid key OR quota reached. Don't retry — both are sticky.
      if (response.status === 401) {
        // Best-effort body read to confirm quota vs. invalid key
        try {
          const body = (await response.clone().json()) as { Error?: string };
          if (body.Error && /limit/i.test(body.Error)) {
            tripQuotaBreaker();
          } else {
            // Invalid key — also pointless to retry, just block for the day
            tripQuotaBreaker();
            console.warn('[OMDB] 401 (likely invalid key):', body.Error);
          }
        } catch {
          tripQuotaBreaker();
        }
        return EMPTY;
      }

      if (!response.ok) {
        if (attempt === 0) { await new Promise(r => setTimeout(r, 800)); continue; }
        return EMPTY;
      }

      const data = (await response.json()) as OMDBResponse;

      if (data.Response === 'False') {
        //