/**
 * Automated IMDB-compatible CSV export
 *
 * Runs once per day on app open. Pulls rated items from Trakt, converts
 * to IMDB CSV format, and stores the result in localStorage. The Settings
 * page offers a "Download IMDB Export" button.
 *
 * IMDB CSV format:
 *   Const,Your Rating,Date Rated,Title,URL,Title Type,IMDb Rating,
 *   Runtime (mins),Year,Genres,Num Votes,Release Date,Directors
 *
 * We fill: Const (IMDB ID), Your Rating (scaled 1-10), Date Rated,
 *          Title, Year. The rest is left empty (IMDB will match on Const).
 */

import { getRatedItems, getWatchedMovies, isTraktAuthenticated } from './trakt';

const EXPORT_KEY = 'seenit_imdb_export';
const EXPORT_META_KEY = 'seenit_export_meta';
const EXPORT_INTERVAL_MS = 24 * 60 * 60 * 1000; // 24 hours

interface ExportMeta {
  lastRun: number;
  ratedCount: number;
  watchedCount: number;
}

function getExportMeta(): ExportMeta | null {
  try {
    const raw = localStorage.getItem(EXPORT_META_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return null;
}

function saveExportMeta(meta: ExportMeta): void {
  try {
    localStorage.setItem(EXPORT_META_KEY, JSON.stringify(meta));
  } catch { /* ignore */ }
}

/**
 * Check if the daily export needs to run.
 * Call this on app startup — it's a no-op if already run today.
 */
export async function runDailyExportIfNeeded(): Promise<boolean> {
  if (!isTraktAuthenticated()) return false;

  const meta = getExportMeta();
  const now = Date.now();

  // Already ran today
  if (meta && (now - meta.lastRun) < EXPORT_INTERVAL_MS) return false;

  try {
    console.log('[export] Running daily IMDB export...');
    const rated = await getRatedItems();
    const watched = await getWatchedMovies();

    // Build IMDB-compatible CSV
    const header = 'Const,Your Rating,Date Rated,Title,URL,Title Type,IMDb Rating,Runtime (mins),Year,Genres,Num Votes,Release Date,Directors';
    const rows: string[] = [];

    // Rated items (have both IMDB ID and rating)
    for (const item of rated) {
      if (!item.ids.imdb) continue;
      const imdbId = item.ids.imdb;
      const rating = item.rating;
      const dateRated = item.rated_at ? item.rated_at.slice(0, 10) : '';
      const title = csvEscape(item.title);
      const url = `https://www.imdb.com/title/${imdbId}/`;
      const titleType = item.mediaType === 'movie' ? 'movie' : 'tvSeries';
      rows.push(`${imdbId},${rating},${dateRated},${title},${url},${titleType},,,,,,`);
    }

    // Watched-but-not-rated items (no rating column)
    const ratedImdbIds = new Set(rated.filter(r => r.ids.imdb).map(r => r.ids.imdb));
    for (const item of watched) {
      if (!item.ids.imdb || ratedImdbIds.has(item.ids.imdb)) continue;
      const title = csvEscape(item.title);
      const url = `https://www.imdb.com/title/${item.ids.imdb}/`;
      rows.push(`${item.ids.imdb},,,,${url},movie,,,,,,`);
    }

    const csv = header + '\n' + rows.join('\n');

    // Store in localStorage
    try {
      localStorage.setItem(EXPORT_KEY, csv);
    } catch {
      // If too big, store just rated items
      const smallCsv = header + '\n' + rows.slice(0, rated.length).join('\n');
      localStorage.setItem(EXPORT_KEY, smallCsv);
    }

    saveExportMeta({
      lastRun: now,
      ratedCount: rated.length,
      watchedCount: watched.length,
    });

    console.log(`[export] Done — ${rated.length} rated, ${watched.length} watched`);
    return true;
  } catch (err) {
    console.error('[export] Daily export failed:', err);
    return false;
  }
}

/**
 * Get the stored CSV for download.
 */
export function getExportCSV(): string | null {
  try {
    return localStorage.getItem(EXPORT_KEY);
  } catch { return null; }
}

/**
 * Get export status for display.
 */
export function getExportStatus(): { lastRun: Date | null; ratedCount: number; watchedCount: number } {
  const meta = getExportMeta();
  return {
    lastRun: meta ? new Date(meta.lastRun) : null,
    ratedCount: meta?.ratedCount ?? 0,
    watchedCount: meta?.watchedCount ?? 0,
  };
}

/**
 * Trigger a CSV download in the browser.
 */
export function downloadExportCSV(): boolean {
  const csv = getExportCSV();
  if (!csv) return false;

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `seenit-imdb-export-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  return true;
}

/** Escape a value for CSV (handles commas and quotes) */
function csvEscape(value: string): string {
  if (value.includes(',') || value.includes('"') || value.includes('\n')) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}
