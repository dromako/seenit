/**
 * Trakt.tv API Client
 * Handles OAuth device code flow and API requests for movie/TV tracking
 */

import { getTraktToken as getStoredToken, setTraktToken as setStoredToken } from './storage';

const TRAKT_BASE_URL = 'https://api.trakt.tv';
const TRAKT_CLIENT_ID = import.meta.env.VITE_TRAKT_CLIENT_ID;
const TRAKT_CLIENT_SECRET = import.meta.env.VITE_TRAKT_CLIENT_SECRET;
const TOKEN_EXPIRY_KEY = 'seenit_trakt_token_expiry';

interface TokenResponse {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  token_type: string;
}

interface DeviceCodeResponse {
  device_code: string;
  user_code: string;
  verification_url: string;
  expires_in: number;
  interval: number;
}

interface AuthHeaders {
  [key: string]: string;
}

interface WatchItem {
  title: string;
  year: number;
  ids: {
    trakt: number;
    slug: string;
    tvdb?: number;
    imdb?: string;
    tmdb?: number;
  };
}

interface RatingData {
  rating: number;
  rated_at?: string;
}

export interface RatedItem {
  rating: number;
  rated_at: string;
  title: string;
  year: number;
  mediaType: 'movie' | 'tv';
  ids: {
    trakt: number;
    slug: string;
    tvdb?: number;
    imdb?: string;
    tmdb?: number;
  };
}

/**
 * Get authentication headers for Trakt API requests
 */
function getTraktHeaders(includeAuth = true): AuthHeaders {
  const headers: AuthHeaders = {
    'trakt-api-version': '2',
    'trakt-api-key': TRAKT_CLIENT_ID,
    'Content-Type': 'application/json',
  };

  if (includeAuth) {
    const token = getTraktToken();
    if (token?.access_token) {
      headers.Authorization = `Bearer ${token.access_token}`;
    }
  }

  return headers;
}

/**
 * Start OAuth device code flow
 * Returns user_code and verification_url for user to authorize
 */
export async function initTraktAuth(): Promise<{
  user_code: string;
  verification_url: string;
  device_code: string;
  interval: number;
} | null> {
  try {
    const response = await fetch(`${TRAKT_BASE_URL}/oauth/device/code`, {
      method: 'POST',
      headers: getTraktHeaders(false),
      body: JSON.stringify({
        client_id: TRAKT_CLIENT_ID,
      }),
    });

    if (!response.ok) {
      console.error('Failed to get device code:', response.statusText);
      return null;
    }

    const data = (await response.json()) as DeviceCodeResponse;
    return {
      user_code: data.user_code,
      verification_url: data.verification_url,
      device_code: data.device_code,
      interval: data.interval,
    };
  } catch (error) {
    console.error('Error initializing Trakt auth:', error);
    return null;
  }
}

/**
 * Poll for token after user authorizes device code
 */
export async function pollForToken(deviceCode: string): Promise<boolean> {
  try {
    const response = await fetch(`${TRAKT_BASE_URL}/oauth/device/token`, {
      method: 'POST',
      headers: getTraktHeaders(false),
      body: JSON.stringify({
        code: deviceCode,
        client_id: TRAKT_CLIENT_ID,
        client_secret: TRAKT_CLIENT_SECRET,
      }),
    });

    if (!response.ok) {
      if (response.status === 400) {
        // Device code still pending
        return false;
      }
      console.error('Failed to poll for token:', response.statusText);
      return false;
    }

    const data = (await response.json()) as TokenResponse;
    setTraktToken(data);
    return true;
  } catch (error) {
    console.error('Error polling for token:', error);
    return false;
  }
}

/**
 * Paginated Trakt fetch — keeps requesting pages until all items are returned.
 * Trakt caps each page at 1000 items; the `X-Pagination-Page-Count` header
 * tells us when we've reached the last page.
 */
async function paginatedFetch<T>(
  endpoint: string,
  extractItem: (raw: any) => T,
  limit = 1000,
): Promise<T[]> {
  const results: T[] = [];
  let page = 1;
  let totalPages = 1;

  while (page <= totalPages) {
    const separator = endpoint.includes('?') ? '&' : '?';
    const url = `${TRAKT_BASE_URL}${endpoint}${separator}page=${page}&limit=${limit}`;
    const response = await fetch(url, { headers: getTraktHeaders(true) });

    if (!response.ok) {
      console.error(`Paginated fetch failed on page ${page}:`, response.statusText);
      break;
    }

    // Trakt pagination headers
    const pageCountHeader = response.headers.get('X-Pagination-Page-Count');
    if (pageCountHeader) totalPages = parseInt(pageCountHeader, 10);

    const data = (await response.json()) as any[];
    for (const item of data) {
      results.push(extractItem(item));
    }

    // If we got fewer items than the limit, we're done regardless of headers
    if (data.length < limit) break;
    page++;
  }

  return results;
}

/**
 * Get user's watched movies (paginated — handles libraries > 1000 items)
 */
export async function getWatchedMovies(): Promise<WatchItem[]> {
  try {
    return await paginatedFetch<WatchItem>(
      '/sync/watched/movies',
      (item) => item.movie,
    );
  } catch (error) {
    console.error('Error getting watched movies:', error);
    return [];
  }
}

/**
 * Get user's watched shows (paginated — handles libraries > 1000 items)
 */
export async function getWatchedShows(): Promise<WatchItem[]> {
  try {
    return await paginatedFetch<WatchItem>(
      '/sync/watched/shows',
      (item) => item.show,
    );
  } catch (error) {
    console.error('Error getting watched shows:', error);
    return [];
  }
}

/**
 * Get hidden/never watching items (paginated)
 */
export async function getHiddenItems(
  section: 'movies' | 'shows' = 'movies'
): Promise<WatchItem[]> {
  try {
    return await paginatedFetch<WatchItem>(
      `/users/hidden/${section}`,
      (item) => (section === 'movies' ? item.movie : item.show),
    );
  } catch (error) {
    console.error('Error getting hidden items:', error);
    return [];
  }
}

/**
 * Get user's ratings for movies or shows (returns full item data)
 */
export async function getRatings(type: 'movies' | 'shows'): Promise<RatingData[]> {
  try {
    const response = await fetch(`${TRAKT_BASE_URL}/sync/ratings/${type}`, {
      headers: getTraktHeaders(true),
    });

    if (!response.ok) {
      console.error('Failed to get ratings:', response.statusText);
      return [];
    }

    return (await response.json()) as RatingData[];
  } catch (error) {
    console.error('Error getting ratings:', error);
    return [];
  }
}

/**
 * Get all rated items with full metadata (title, year, IDs, rating).
 * Combines movies and shows into a single sorted list.
 */
export async function getRatedItems(): Promise<RatedItem[]> {
  try {
    const [movieRes, showRes] = await Promise.all([
      fetch(`${TRAKT_BASE_URL}/sync/ratings/movies`, { headers: getTraktHeaders(true) }),
      fetch(`${TRAKT_BASE_URL}/sync/ratings/shows`, { headers: getTraktHeaders(true) }),
    ]);

    const items: RatedItem[] = [];

    if (movieRes.ok) {
      const movies = (await movieRes.json()) as any[];
      for (const m of movies) {
        if (!m.movie) continue;
        items.push({
          rating: m.rating,
          rated_at: m.rated_at,
          title: m.movie.title,
          year: m.movie.year,
          mediaType: 'movie',
          ids: m.movie.ids,
        });
      }
    }

    if (showRes.ok) {
      const shows = (await showRes.json()) as any[];
      for (const s of shows) {
        if (!s.show) continue;
        items.push({
          rating: s.rating,
          rated_at: s.rated_at,
          title: s.show.title,
          year: s.show.year,
          mediaType: 'tv',
          ids: s.show.ids,
        });
      }
    }

    return items;
  } catch (error) {
    console.error('Error getting rated items:', error);
    return [];
  }
}

/**
 * Get user's watchlist
 */
export async function getWatchlist(
  type: 'movies' | 'shows'
): Promise<WatchItem[]> {
  try {
    const response = await fetch(`${TRAKT_BASE_URL}/sync/watchlist/${type}`, {
      headers: getTraktHeaders(true),
    });

    if (!response.ok) {
      console.error('Failed to get watchlist:', response.statusText);
      return [];
    }

    const data = (await response.json()) as any[];
    return data.map((item) => (type === 'movies' ? item.movie : item.show));
  } catch (error) {
    console.error('Error getting watchlist:', error);
    return [];
  }
}

/**
 * Mark an item as watched
 */
export async function addToHistory(item: {
  title: string;
  year: number;
  ids: any;
  watched_at?: string;
}): Promise<boolean> {
  try {
    const mediaType = item.ids.tvdb ? 'shows' : 'movies';
    const response = await fetch(`${TRAKT_BASE_URL}/sync/history`, {
      method: 'POST',
      headers: getTraktHeaders(true),
      body: JSON.stringify({
        [mediaType]: [item],
      }),
    });

    if (!response.ok) {
      console.error('Failed to add to history:', response.statusText);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error adding to history:', error);
    return false;
  }
}

/**
 * Mark as "never watching"
 */
export async function addToHidden(
  item: { title: string; year: number; ids: any },
  section: 'movies' | 'shows' = 'movies'
): Promise<boolean> {
  try {
    const response = await fetch(`${TRAKT_BASE_URL}/users/hidden/${section}`, {
      method: 'POST',
      headers: getTraktHeaders(true),
      body: JSON.stringify({
        [section]: [item],
      }),
    });

    if (!response.ok) {
      console.error('Failed to add to hidden:', response.statusText);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error adding to hidden:', error);
    return false;
  }
}

/**
 * Add item to watchlist
 */
export async function addToWatchlist(
  item: { title: string; year: number; ids: any }
): Promise<boolean> {
  try {
    const mediaType = item.ids.tvdb ? 'shows' : 'movies';
    const response = await fetch(`${TRAKT_BASE_URL}/sync/watchlist`, {
      method: 'POST',
      headers: getTraktHeaders(true),
      body: JSON.stringify({
        [mediaType]: [item],
      }),
    });

    if (!response.ok) {
      console.error('Failed to add to watchlist:', response.statusText);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error adding to watchlist:', error);
    return false;
  }
}

/**
 * Remove item from watchlist
 */
export async function removeFromWatchlist(
  item: { title: string; year: number; ids: any }
): Promise<boolean> {
  try {
    const mediaType = item.ids.tvdb ? 'shows' : 'movies';
    const response = await fetch(`${TRAKT_BASE_URL}/sync/watchlist/remove`, {
      method: 'POST',
      headers: getTraktHeaders(true),
      body: JSON.stringify({
        [mediaType]: [item],
      }),
    });

    if (!response.ok) {
      console.error('Failed to remove from watchlist:', response.statusText);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error removing from watchlist:', error);
    return false;
  }
}

/**
 * Rate an item (1-10)
 */
export async function addRating(
  item: { title: string; year: number; ids: any },
  rating: number
): Promise<boolean> {
  if (rating < 1 || rating > 10) {
    console.error('Rating must be between 1 and 10');
    return false;
  }

  try {
    const mediaType = item.ids.tvdb ? 'shows' : 'movies';
    const response = await fetch(`${TRAKT_BASE_URL}/sync/ratings`, {
      method: 'POST',
      headers: getTraktHeaders(true),
      body: JSON.stringify({
        [mediaType]: [{ ...item, rating }],
      }),
    });

    if (!response.ok) {
      console.error('Failed to add rating:', response.statusText);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error adding rating:', error);
    return false;
  }
}

/**
 * Remove item from watched history
 */
export async function removeFromHistory(item: {
  title: string;
  year: number;
  ids: any;
}): Promise<boolean> {
  try {
    const mediaType = item.ids.tvdb ? 'shows' : 'movies';
    const response = await fetch(`${TRAKT_BASE_URL}/sync/history/remove`, {
      method: 'POST',
      headers: getTraktHeaders(true),
      body: JSON.stringify({
        [mediaType]: [item],
      }),
    });

    if (!response.ok) {
      console.error('Failed to remove from history:', response.statusText);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error removing from history:', error);
    return false;
  }
}

/**
 * Unhide an item
 */
export async function removeFromHidden(
  item: { title: string; year: number; ids: any },
  section: 'movies' | 'shows' = 'movies'
): Promise<boolean> {
  try {
    const response = await fetch(`${TRAKT_BASE_URL}/users/hidden/${section}/remove`, {
      method: 'POST',
      headers: getTraktHeaders(true) as Record<string, string>,
      body: JSON.stringify({
        [section]: [item],
      }),
    });

    if (!response.ok) {
      console.error('Failed to remove from hidden:', response.statusText);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error removing from hidden:', error);
    return false;
  }
}

/**
 * Token accessors — delegate to storage.ts for a single localStorage key.
 * Tracks expiry timestamp so we can refresh before the token goes stale.
 */
function getTraktToken(): TokenResponse | null {
  return getStoredToken() as TokenResponse | null;
}

function setTraktToken(token: TokenResponse): void {
  setStoredToken(token);
  // Store absolute expiry time (now + expires_in seconds, minus 5 min buffer)
  const expiryMs = Date.now() + (token.expires_in - 300) * 1000;
  try { localStorage.setItem(TOKEN_EXPIRY_KEY, String(expiryMs)); } catch { /* ignore */ }
}

function isTokenExpired(): boolean {
  try {
    const expiry = localStorage.getItem(TOKEN_EXPIRY_KEY);
    if (!expiry) return false; // legacy tokens without expiry — assume valid
    return Date.now() > Number(expiry);
  } catch { return false; }
}

/**
 * Refresh the Trakt token using the stored refresh_token.
 * Returns true if refresh succeeded, false otherwise.
 */
async function refreshTraktToken(): Promise<boolean> {
  const token = getTraktToken();
  if (!token?.refresh_token) return false;

  try {
    const response = await fetch(`${TRAKT_BASE_URL}/oauth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        refresh_token: token.refresh_token,
        client_id: TRAKT_CLIENT_ID,
        client_secret: TRAKT_CLIENT_SECRET,
        redirect_uri: 'urn:ietf:wg:oauth:2.0:oob',
        grant_type: 'refresh_token',
      }),
    });

    if (!response.ok) {
      console.warn('[Trakt] token refresh failed:', response.status);
      return false;
    }

    const data = (await response.json()) as TokenResponse;
    setTraktToken(data);
    return true;
  } catch (err) {
    console.error('[Trakt] token refresh error:', err);
    return false;
  }
}

/**
 * Check if user is authenticated with Trakt.
 * If the token is expired, attempts a background refresh.
 */
export function isTraktAuthenticated(): boolean {
  const token = getTraktToken();
  if (!token) return false;
  // Trigger async refresh if expired — won't block this call
  if (isTokenExpired()) {
    refreshTraktToken().catch(() => {});
  }
  return true;
}

/**
 * Get user profile from Trakt
 */
export async function getTraktProfile(): Promise<{ username: string; name: string } | null> {
  try {
    const response = await fetch(`${TRAKT_BASE_URL}/users/me`, {
      headers: getTraktHeaders(true),
    });
    if (!response.ok) return null;
    const data = await response.json();
    return { username: data.username, name: data.name || data.username };
  } catch {
    return null;
  }
}

