// This file is deprecated. The "shop life" random-text decoration system
// (handwritten patron notes, dog-ears, staff picks, well-loved marks,
// shopkeeper asides between rows) has been removed.
//
// Nothing in src/ imports from this file. It can be deleted manually from
// File Explorer; the build does not depend on it.
export {};
