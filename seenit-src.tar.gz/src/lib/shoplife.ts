/**
 * Shop Life — visual personality for the bookshop model
 *
 * Generates the small human touches that make the shop feel alive:
 *   - Handwritten patron notes on occasional posters
 *   - Shopkeeper asides between rows
 *   - Visual quirks (dog-ears, well-loved marks) on patron shelf items
 *
 * DESIGN RULE: these are not random decorative noise. Each note is
 * tied to the patron's vector or the viewer's engagement data. They
 * should feel like evidence of a real person — someone who held this
 * DVD, thought about it, and left it on the shelf with a sticky note.
 *
 * Frequency: ~1-2 notes per patron row, never on personal shelves.
 * Style: warm cream sticky note, slightly rotated, handwriting font.
 */

// ── Patron notes: things a patron might scrawl on a sticky ──
// Organized by the patron's mood pool for tonal consistency.
// Generic notes work for any patron.

const GENERIC_NOTES = [
  'This one stayed with me',
  'Watched it twice',
  'Don\'t read anything first',
  'Better than the reviews say',
  'The ending, though',
  'Trust me on this one',
  'My partner hated it. I loved it.',
  'Found this at 2am',
  'Third time this year',
  'Couldn\'t sleep after',
  'Worth the subtitles',
  'This one\'s a slow burn — stay with it',
  'I cried and I don\'t cry at movies',
  'Underrated',
  'Saw this in a theater. Still thinking about it.',
  'Not what I expected',
  'The director\'s best, honestly',
  'Lent this to three people. None returned it.',
  'I own this on DVD and I\'m not sorry',
  'This fixed a bad week',
  'My comfort rewatch',
  'Start here if you\'re new',
  'There\'s a scene at the 40-min mark. You\'ll know.',
  'Walked home in silence after this one',
  'I think about this monthly',
];

const MOOD_NOTES: Record<string, string[]> = {
  paranoia: [
    'I kept checking behind me',
    'Don\'t watch this alone',
    'My apartment felt different after',
    'I unplugged my webcam after this',
    'Slept with the hallway light on',
    'I heard a noise halfway through and paused for five minutes',
  ],
  nostalgia: [
    'Reminded me of being 12',
    'Smells like summer somehow',
    'Called my mom after watching',
    'The soundtrack alone is worth it',
    'I miss a place I\'ve never been because of this',
    'Made me want to dig out old photos',
  ],
  desire: [
    'This one is... a lot. In the best way.',
    'I blushed and I\'m alone',
    'Bold. Unapologetic. Perfect.',
    'They don\'t make them like this anymore',
    'Watched this with someone. You should too.',
    'The kind of tension you feel in your chest',
  ],
  wanderlust: [
    'Booked a trip after watching',
    'Makes you want to drive somewhere',
    'I watched this in a hostel in Lisbon',
    'The landscapes, my god',
    'I looked up flights right after the credits',
    'Best watched with the windows open',
  ],
  dread: [
    'Left the lights on all night',
    'The sound design alone...',
    'This stays with you whether you want it to or not',
    'I paused it three times. Kept coming back.',
    'Not scary. Worse. Inevitable.',
    'I was fine until the last ten minutes',
  ],
  rebellion: [
    'They tried to ban this one',
    'Still relevant. Maybe more so.',
    'This is the one they don\'t want you to see',
    'Angry in the right way',
    'Made me want to go do something about it',
    'I showed this to everyone at dinner',
  ],
  solitude: [
    'For a quiet night',
    'Best watched alone',
    'I sat in the dark for ten minutes after',
    'This one understood me',
    'No one I know has seen this. That\'s fine.',
    'The kind of movie you keep to yourself',
  ],
  spectacle: [
    'Big screen or don\'t bother',
    'Turn the volume up for this one',
    'Pure cinema',
    'I audibly gasped. Twice.',
    'You forget you\'re watching a movie',
    'My jaw literally dropped at the halfway point',
  ],
  intrigue: [
    'The second watch changes everything',
    'Pay attention to the background',
    'Everyone in this is lying',
    'I still don\'t know who was right',
    'I went down a Reddit hole after this. Worth it.',
    'Bring someone to argue about it with',
  ],
};

// ── Notes that reference the viewer's habits ──
// These are from the shopkeeper or a patron who's "noticed" the viewer.

const VIEWER_NOTES_BY_GENRE: Record<number, string[]> = {
  27: ['You\'ve been on a horror streak — this fits', 'Since you liked the scary shelf...', 'Figured you\'d end up here again', 'This one\'s meaner than your last pick'],
  18: ['For your drama nights', 'You always end up here', 'You\'re in that kind of mood again, huh', 'This one hits different after midnight'],
  80: ['More crime for your collection', 'I noticed you lingering here', 'You keep coming back to this corner', 'Darker than your last one. Ready?'],
  878: ['Another rabbit hole for you', 'This is the deep cut', 'You\'re getting further from the mainstream. Good.', 'Weird in the way you like'],
  53: ['Your kind of tension', 'You seem like you can handle this', 'Thought of you when I shelved this', 'Right up your alley — you\'ll see why'],
  35: ['You need a laugh — try this', 'Lighter than your usual', 'A break from the heavy stuff', 'You\'ve earned something fun'],
  99: ['For the curious mind', 'You\'re the type to watch docs at midnight', 'This one goes deep', 'Fair warning: you\'ll be reading about this for a week'],
  10749: ['Softer than your usual picks', 'Sometimes you just need this', 'Don\'t tell anyone I recommended this', 'Pair with wine'],
  16: ['The animation crowd swears by this one', 'Not just for kids. Not even close.', 'Trust the art style — give it ten minutes'],
  36: ['Real story. Unbelievable story.', 'History is stranger than fiction here', 'This actually happened'],
  12: ['For when you want to go somewhere', 'You look like you need an adventure'],
  9648: ['This will keep you guessing', 'Bring your brain to this one', 'The clues are there if you\'re paying attention'],
  10752: ['Heavy. Important. Worth it.', 'Not an easy watch, but you should'],
  37: ['They really don\'t make these anymore', 'Quiet and brutal'],
};

// ── Visual quirk types ──
// Assigned to ~15% of patron shelf posters. Each quirk is a visual
// hint that someone else has handled this copy.

export type ShopQuirk = 'note' | 'dog-ear' | 'staff-pick' | 'well-loved' | null;

export interface ShopNote {
  text: string;
  rotation: number;     // degrees, -4 to 4
  position: 'top' | 'bottom';  // where the note sits on the poster
}

/**
 * Decide what visual quirk (if any) a poster gets on a patron shelf.
 * Uses a deterministic seed from the item ID so quirks don't jump
 * around on re-renders, but vary per item.
 */
export function getQuirkForItem(
  itemId: number,
  patronMoodName: string,
  viewerTopGenres: number[],
  itemGenreIds: number[],
): { quirk: ShopQuirk; note: ShopNote | null } {
  // Deterministic random from item ID
  const seed = (itemId * 2654435761) >>> 0; // knuth multiplicative hash
  const r = (offset: number) => ((seed + offset * 7919) % 1000) / 1000;

  // ~18% of patron items get a quirk
  if (r(0) > 0.18) return { quirk: null, note: null };

  // 50% note, 25% dog-ear, 15% well-loved, 10% staff-pick
  const quirkRoll = r(1);
  let quirk: ShopQuirk;

  if (quirkRoll < 0.50) {
    quirk = 'note';
  } else if (quirkRoll < 0.75) {
    quirk = 'dog-ear';
  } else if (quirkRoll < 0.90) {
    quirk = 'well-loved';
  } else {
    quirk = 'staff-pick';
  }

  // Generate note text if it's a note quirk
  let note: ShopNote | null = null;
  if (quirk === 'note') {
    let text: string;

    // 30% chance it references the viewer's habits (if genre overlap)
    const viewerGenreMatch = itemGenreIds.find(g => viewerTopGenres.includes(g));
    if (viewerGenreMatch && r(2) < 0.3) {
      const options = VIEWER_NOTES_BY_GENRE[viewerGenreMatch] || GENERIC_NOTES;
      text = options[Math.floor(r(3) * options.length)];
    }
    // 40% chance mood-specific note from the patron's personality
    else if (r(4) < 0.4 && MOOD_NOTES[patronMoodName]) {
      const pool = MOOD_NOTES[patronMoodName];
      text = pool[Math.floor(r(5) * pool.length)];
    }
    // 30% generic note
    else {
      text = GENERIC_NOTES[Math.floor(r(6) * GENERIC_NOTES.length)];
    }

    note = {
      text,
      rotation: -3 + r(7) * 6, // -3 to +3 degrees
      position: r(8) < 0.65 ? 'top' : 'bottom',
    };
  }

  return { quirk, note };
}

/**
 * Pick a shopkeeper aside to show between curated rows.
 * Returns null most of the time (~75%) — these should be rare.
 * When they do appear, they reference the viewer's recent behavior
 * or the time of day.
 */
export function getShopkeeperAside(
  timeOfDay: string,
  rowIndex: number,
  totalRows: number,
): string | null {
  // Only show between rows 3-7, and only ~25% of the time
  if (rowIndex < 2 || rowIndex > totalRows - 2) return null;
  const seed = (rowIndex * 104729 + Date.now() % 86400000) >>> 0;
  if ((seed % 100) > 25) return null;

  const asides: Record<string, string[]> = {
    morning: [
      'Coffee\'s still hot. Take your time.',
      'You\'re here early.',
      'The morning light hits this shelf just right.',
      'Someone rearranged this shelf overnight.',
      'Fresh returns in the back.',
    ],
    afternoon: [
      'Quiet in here today.',
      'Someone just brought these back.',
      'The afternoon browsers always find the good ones.',
      'Take your time. No one\'s waiting.',
      'That shelf got a lot of attention this week.',
    ],
    evening: [
      'Good night for a film.',
      'Take something home — you deserve it.',
      'The evening crowd knows what they want.',
      'Perfect weather for staying in.',
      'A regular just left these. Still warm.',
    ],
    latenight: [
      'Still here? The best stuff\'s in the back.',
      'The late-night shelf is where it gets interesting.',
      'Can\'t sleep? Neither could the person who left these.',
      'The shop\'s quiet now. Just you and the shelves.',
      'This is when the real browsing happens.',
      'No judgement on this shelf. Especially not at this hour.',
    ],
  };

  const pool = asides[timeOfDay] || asides['evening'];
  return pool[seed % pool.length];
}
