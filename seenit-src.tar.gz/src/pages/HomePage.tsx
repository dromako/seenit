import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getRecentLookups } from '../lib/storage';
import { isTraktAuthenticated, getWatchedMovies, getWatchedShows, getHiddenItems, getWatchlist } from '../lib/trakt';
import { cacheGet, cacheSet } from '../lib/storage';
import CameraSearch from '../components/CameraSearch';
import type { RecentLookup } from '../types';

export default function HomePage() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [recentLookups, setRecentLookups] = useState<RecentLookup[]>([]);
  const [stats, setStats] = useState({ watched: 0, hidden: 0, watchlisted: 0 });
  const [listening, setListening] = useState(false);
  const [statsLoading, setStatsLoading] = useState(false);

  useEffect(() => {
    const recent = getRecentLookups();
    setRecentLookups(recent);

    if (isTraktAuthenticated()) {
      const cached = cacheGet<{ watched: number; hidden: number; watchlisted: number }>('home_stats');
      if (cached) {
        setStats(cached);
      }

      setStatsLoading(true);
      Promise.all([
        getWatchedMovies(),
        getWatchedShows(),
        getHiddenItems('movies'),
        getWatchlist('movies'),
        getWatchlist('shows'),
      ]).then(([watchedMovies, watchedShows, hidden, watchlistMovies, watchlistShows]) => {
        const newStats = {
          watched: watchedMovies.length + watchedShows.length,
          hidden: hidden.length,
          watchlisted: watchlistMovies.length + watchlistShows.length,
        };
        setStats(newStats);
        cacheSet('home_stats', newStats, 5);
      }).catch(err => {
        console.error('Error loading stats:', err);
      }).finally(() => {
        setStatsLoading(false);
      });
    }
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/lookup?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const handleVoiceSearch = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      const el = document.querySelector('input[type="text"]') as HTMLInputElement;
      if (el) el.focus();
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.onstart = () => setListening(true);
    recognition.onend = () => setListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setSearchQuery(transcript);
      navigate(`/lookup?q=${encodeURIComponent(transcript)}`);
    };
    recognition.onerror = () => setListening(false);
    recognition.start();
  };

  return (
    <div style={{ paddingTop: 12 }}>

      {/* ── Camera Search: the primary action ── */}
      <CameraSearch />

      {/* ── Divider ── */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 10,
        margin: '6px 0 12px',
      }}>
        <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.06)' }} />
        <span style={{ fontSize: 10, color: 'var(--text-secondary)', fontWeight: 500, letterSpacing: 0.8, textTransform: 'uppercase' }}>
          or type
        </span>
        <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.06)' }} />
      </div>

      {/* ── Text search (secondary) ── */}
      <form onSubmit={handleSearch} style={{ marginBottom: 14 }}>
        <div style={{
          display: 'flex', gap: 8, backgroundColor: 'var(--bg-card)',
          borderRadius: 8, padding: '10px 12px', border: '1px solid rgba(255,255,255,0.06)',
        }}>
          <input
            type="text"
            placeholder="Search movies & TV..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            style={{
              flex: 1, background: 'transparent', border: 'none',
              color: 'var(--text-primary)', fontSize: 15, outline: 'none',
            }}
          />
          <button type="submit" style={{
            background: 'none', border: 'none', cursor: 'pointer',
            padding: '0 4px', display: 'flex', alignItems: 'center',
          }} title="Search">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--text-secondary)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8" />
              <path d="M21 21l-4.35-4.35" />
            </svg>
          </button>
          <button
            type="button" onClick={handleVoiceSearch} disabled={listening}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              padding: '0 4px', display: 'flex', alignItems: 'center',
              opacity: listening ? 1 : 0.6,
            }}
            title="Voice search"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={listening ? 'var(--red)' : 'var(--text-secondary)'} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z" />
              <path d="M19 10v2a7 7 0 01-14 0v-2" />
              <line x1="12" y1="19" x2="12" y2="23" />
              <line x1="8" y1="23" x2="16" y2="23" />
            </svg>
          </button>
        </div>
      </form>

      {/* ── Quick actions row ── */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
        <button
          onClick={() => navigate('/history?tab=watchlist&filter=free')}
          style={{
            flex: 1, padding: '10px 0', backgroundColor: 'var(--bg-card)',
            border: '1px solid rgba(255,255,255,0.06)', borderRadius: 8,
            color: 'var(--text-primary)', fontSize: 13, fontWeight: 500,
            cursor: 'pointer',
          }}
        >
          Free Tonight
        </button>
        {!isTraktAuthenticated() && (
          <button
            onClick={() => navigate('/settings')}
            style={{
              flex: 1, padding: '10px 0',
              border: '1px solid rgba(232,97,60,0.3)', borderRadius: 8,
              cursor: 'pointer', color: 'var(--accent)', fontSize: 13,
              fontWeight: 500, backgroundColor: 'transparent',
            }}
          >
            Connect Trakt
          </button>
        )}
      </div>

      {/* ── Stats row ── */}
      {isTraktAuthenticated() && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 20 }}>
          {[
            { label: 'Watched', value: stats.watched, color: 'var(--green)', tab: 'watched' },
            { label: 'Hidden', value: stats.hidden, color: 'var(--red)', tab: 'hidden' },
            { label: 'Watchlist', value: stats.watchlisted, color: 'var(--blue)', tab: 'watchlist' },
          ].map(s => (
            <div
              key={s.tab}
              onClick={() => navigate(`/history?tab=${s.tab}`)}
              style={{
                padding: '12px 8px', textAlign: 'center', cursor: 'pointer',
                background: 'var(--bg-card)', borderRadius: 8,
                border: '1px solid rgba(255,255,255,0.04)',
              }}
            >
              <div style={{ fontSize: 20, fontWeight: 700, color: s.color, opacity: statsLoading ? 0.5 : 1 }}>
                {s.value}
              </div>
              <div style={{ fontSize: 11, color: 'var(--text-secondary)', marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* ── Recent lookups ── */}
      {recentLookups.length > 0 && (
        <>
          <div style={{ marginBottom: 10 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', letterSpacing: 0.6, textTransform: 'uppercase' }}>
              Recent
            </div>
            <div style={{ width: 16, height: 2, background: 'var(--accent)', borderRadius: 1, marginTop: 4 }} />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 20 }}>
            {recentLookups.map((item) => (
              <button
                key={`${item.tmdbId}-${item.mediaType}`}
                onClick={() => navigate(`/title/${item.tmdbId}/${item.mediaType}`)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, textAlign: 'left' }}
              >
                {item.posterPath ? (
                  <img
                    src={item.posterPath}
                    alt={item.title}
                    style={{
                      width: '100%', borderRadius: 6, aspectRatio: '2/3',
                      objectFit: 'cover', backgroundColor: 'var(--bg-card)',
                    }}
                  />
                ) : (
                  <div style={{
                    width: '100%', aspectRatio: '2/3', borderRadius: 6,
                    backgroundColor: 'var(--bg-card)', display: 'flex', alignItems: 'center',
                    justifyContent: 'center', fontSize: 24, color: 'var(--text-secondary)',
                  }}>
                    —
                  </div>
                )}
                <div style={{
                  fontSize: 11, marginTop: 4, overflow: 'hidden',
                  textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: 'var(--text-primary)',
                }}>
                  {item.title}
                </div>
              </button>
            ))}
          </div>
        </>
      )}

      {recentLookups.length === 0 && (
        <div style={{ textAlign: 'center', color: 'var(--text-secondary)', padding: '24px 16px', fontSize: 13 }}>
          Point your phone at the TV or search to get started.
        </div>
      )}
    </div>
  );
}
