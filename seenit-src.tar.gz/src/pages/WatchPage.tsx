import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';

/**
 * Embedded video sources — tried in order.
 * Each returns an iframe-friendly URL for a given IMDB ID.
 * If one fails or doesn't have the title, the user can tap "Next Source."
 */
const SOURCES = [
  {
    id: 'vidsrc-icu',
    name: 'Source 1',
    movieUrl: (imdbId: string) => `https://vidsrc.icu/embed/movie/${imdbId}`,
    tvUrl: (imdbId: string, s: number, e: number) =>
      `https://vidsrc.icu/embed/tv/${imdbId}/${s}/${e}`,
  },
  {
    id: 'vidsrc-cc',
    name: 'Source 2',
    movieUrl: (imdbId: string) => `https://vidsrc.cc/v2/embed/movie/${imdbId}`,
    tvUrl: (imdbId: string, s: number, e: number) =>
      `https://vidsrc.cc/v2/embed/tv/${imdbId}/${s}/${e}`,
  },
  {
    id: '2embed',
    name: 'Source 3',
    movieUrl: (imdbId: string) => `https://www.2embed.stream/embed/movie/${imdbId}`,
    tvUrl: (imdbId: string, s: number, e: number) =>
      `https://www.2embed.stream/embed/tv/${imdbId}/${s}/${e}`,
  },
  {
    id: 'multiembed',
    name: 'Source 4',
    movieUrl: (imdbId: string) => `https://multiembed.mov/directstream.php?video_id=${imdbId}`,
    tvUrl: (imdbId: string, s: number, e: number) =>
      `https://multiembed.mov/directstream.php?video_id=${imdbId}&s=${s}&e=${e}`,
  },
];

export default function WatchPage() {
  const { mediaType, imdbId } = useParams<{ mediaType: string; imdbId: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const season = parseInt(searchParams.get('s') || '1');
  const episode = parseInt(searchParams.get('e') || '1');

  const [sourceIndex, setSourceIndex] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [iframeError, setIframeError] = useState(false);

  // Auto-hide controls after 4 seconds
  useEffect(() => {
    if (!showControls) return;
    const timer = setTimeout(() => setShowControls(false), 4000);
    return () => clearTimeout(timer);
  }, [showControls]);

  const currentSource = SOURCES[sourceIndex];

  const getStreamUrl = useCallback(() => {
    if (!imdbId || !currentSource) return '';
    if (mediaType === 'tv') {
      return currentSource.tvUrl(imdbId, season, episode);
    }
    return currentSource.movieUrl(imdbId);
  }, [imdbId, mediaType, season, episode, currentSource]);

  const nextSource = () => {
    setIframeError(false);
    if (sourceIndex < SOURCES.length - 1) {
      setSourceIndex(sourceIndex + 1);
    } else {
      setSourceIndex(0); // wrap around
    }
    setShowControls(true);
  };

  const handleBack = () => {
    navigate(-1);
  };

  if (!imdbId) {
    return (
      <div style={{
        height: '100dvh', display: 'flex', alignItems: 'center', justifyContent: 'center',
        flexDirection: 'column', color: 'var(--text-secondary)', gap: '16px',
      }}>
        <div style={{ fontSize: '32px' }}>No IMDB ID</div>
        <button onClick={handleBack} style={backBtnStyle}>Go Back</button>
      </div>
    );
  }

  const streamUrl = getStreamUrl();

  return (
    <div
      style={{
        position: 'fixed', inset: 0, backgroundColor: '#000', zIndex: 9999,
        display: 'flex', flexDirection: 'column',
      }}
      onClick={() => setShowControls(true)}
    >
      {/* Controls overlay — back button + source switcher */}
      <div
        style={{
          position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10,
          background: showControls ? 'linear-gradient(to bottom, rgba(0,0,0,0.8), transparent)' : 'transparent',
          padding: '12px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          transition: 'opacity 0.3s', opacity: showControls ? 1 : 0,
          pointerEvents: showControls ? 'auto' : 'none',
        }}
      >
        <button onClick={handleBack} style={backBtnStyle}>
          ← Back
        </button>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <span style={{ color: 'rgba(255,255,255,0.6)', fontSize: '12px' }}>
            {currentSource.name}
          </span>
          <button onClick={nextSource} style={sourceBtnStyle}>
            Try Next ▸
          </button>
        </div>
      </div>

      {/* Error overlay */}
      {iframeError && (
        <div style={{
          position: 'absolute', inset: 0, zIndex: 5,
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          background: 'rgba(0,0,0,0.85)', gap: '16px',
        }}>
          <div style={{ fontSize: '40px' }}>😕</div>
          <div style={{ color: 'var(--text-secondary)', fontSize: '14px' }}>
            This source didn't load.
          </div>
          <button onClick={nextSource} style={sourceBtnStyle}>
            Try Next Source ▸
          </button>
        </div>
      )}

      {/* The player iframe */}
      <iframe
        key={streamUrl}
        src={streamUrl}
        style={{
          flex: 1, width: '100%', border: 'none', backgroundColor: '#000',
        }}
        allowFullScreen
        allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
        referrerPolicy="origin"
        onError={() => setIframeError(true)}
      />

      {/* Bottom source indicator — always visible as a thin bar */}
      <div style={{
        backgroundColor: 'rgba(0,0,0,0.9)', padding: '6px 16px',
        display: 'flex', justifyContent: 'center', gap: '6px',
        paddingBottom: 'calc(6px + env(safe-area-inset-bottom, 0px))',
      }}>
        {SOURCES.map((s, i) => (
          <button
            key={s.id}
            onClick={() => { setSourceIndex(i); setIframeError(false); setShowControls(true); }}
            style={{
              width: '8px', height: '8px', borderRadius: '50%', border: 'none', cursor: 'pointer',
              backgroundColor: i === sourceIndex ? 'var(--accent)' : 'rgba(255,255,255,0.3)',
              padding: 0,
            }}
            title={s.name}
          />
        ))}
      </div>
    </div>
  );
}

const backBtnStyle: React.CSSProperties = {
  background: 'rgba(255,255,255,0.15)', border: 'none', color: 'white',
  padding: '8px 16px', borderRadius: '8px', fontSize: '14px', cursor: 'pointer',
  backdropFilter: 'blur(8px)',
};

const sourceBtnStyle: React.CSSProperties = {
  background: 'var(--accent)', border: 'none', color: 'white',
  padding: '8px 16px', borderRadius: '8px', fontSize: '13px', fontWeight: '500',
  cursor: 'pointer',
};
