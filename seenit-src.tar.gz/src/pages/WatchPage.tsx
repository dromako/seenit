import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';

/**
 * Embedded video sources — tried in order.
 * Each returns an iframe-friendly URL for a given IMDB ID.
 * If one fails or doesn't have the title, the user can tap "Next Source."
 */
const SOURCES = [
  {
    id: 'vidsrc-icu',
    name: 'Source 1',
    movieUrl: (imdbId: string) => `https://vidsrc.icu/embed/movie/${imdbId}`,
    tvUrl: (imdbId: string, s: number, e: number) =>
      `https://vidsrc.icu/embed/tv/${imdbId}/${s}/${e}`,
  },
  {
    id: 'vidsrc-cc',
    name: 'Source 2',
    movieUrl: (imdbId: string) => `https://vidsrc.cc/v2/embed/movie/${imdbId}`,
    tvUrl: (imdbId: string, s: number, e: number) =>
      `https://vidsrc.cc/v2/embed/tv/${imdbId}/${s}/${e}`,
  },
  {
    id: '2embed',
    name: 'Source 3',
    movieUrl: (imdbId: string) => `https://www.2embed.stream/embed/movie/${imdbId}`,
    tvUrl: (imdbId: string, s: number, e: number) =>
      `https://www.2embed.stream/embed/tv/${imdbId}/${s}/${e}`,
  },
  {
    id: 'multiembed',
    name: 'Source 4',
    movieUrl: (imdbId: string) => `https://multiembed.mov/directstream.php?video_id=${imdbId}`,
    tvUrl: (imdbId: string, s: number, e: number) =>
      `https://multiembed.mov/directstream.php?video_id=${imdbId}&s=${s}&e=${e}`,
  },
];

export default function WatchPage() {
  const { mediaType, imdbId } = useParams<{ mediaType: string; imdbId: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const season = parseInt(searchParams.get('s') || '1');
  const episode = parseInt(searchParams.get('e') || '1');

  const [sourceIndex, setSourceIndex] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [iframeError, setIframeError] = useState(false);
  const [showTVPanel, setShowTVPanel] = useState(false);

  // Auto-hide controls after 4 seconds
  useEffect(() => {
    if (!showControls) return;
    const timer = setTimeout(() => setShowControls(false), 4000);
    return () => clearTimeout(timer);
  }, [showControls]);

  const currentSource = SOURCES[sourceIndex];

  const getStreamUrl = useCallback(() => {
    if (!imdbId || !currentSource) return '';
    if (mediaType === 'tv') {
      return currentSource.tvUrl(imdbId, season, episode);
    }
    return currentSource.movieUrl(imdbId);
  }, [imdbId, mediaType, season, episode, currentSource]);

  const nextSource = () => {
    setIframeError(false);
    if (sourceIndex < SOURCES.length - 1) {
      setSourceIndex(sourceIndex + 1);
    } else {
      setSourceIndex(0); // wrap around
    }
    setShowControls(true);
  };

  const handleBack = () => {
    navigate(-1);
  };

  if (!imdbId) {
    return (
      <div style={{
        height: '100dvh', display: 'flex', alignItems: 'center', justifyContent: 'center',
        flexDirection: 'column', color: 'var(--text-secondary)', gap: '16px',
      }}>
        <div style={{ fontSize: '32px' }}>No IMDB ID</div>
        <button onClick={handleBack} style={backBtnStyle}>Go Back</button>
      </div>
    );
  }

  const streamUrl = getStreamUrl();

  return (
    <div
      style={{
        position: 'fixed', inset: 0, backgroundColor: '#000', zIndex: 9999,
        display: 'flex', flexDirection: 'column',
      }}
      onClick={() => { if (!showTVPanel) setShowControls(true); }}
    >
      {/* Controls overlay — back button + source switcher + TV button */}
      <div
        style={{
          position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10,
          background: showControls ? 'linear-gradient(to bottom, rgba(0,0,0,0.8), transparent)' : 'transparent',
          padding: '12px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          transition: 'opacity 0.3s', opacity: showControls ? 1 : 0,
          pointerEvents: showControls ? 'auto' : 'none',
        }}
      >
        <button onClick={handleBack} style={backBtnStyle}>
          ← Back
        </button>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <button
            onClick={(e) => { e.stopPropagation(); setShowTVPanel(true); }}
            style={tvBtnStyle}
            title="Send to TV"
          >
            TV
          </button>
          <span style={{ color: 'rgba(255,255,255,0.6)', fontSize: '12px' }}>
            {currentSource.name}
          </span>
          <button onClick={nextSource} style={sourceBtnStyle}>
            Try Next ▸
          </button>
        </div>
      </div>

      {/* Error overlay */}
      {iframeError && (
        <div style={{
          position: 'absolute', inset: 0, zIndex: 5,
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          background: 'rgba(0,0,0,0.85)', gap: '16px',
        }}>
          <div style={{ fontSize: '40px' }}>😕</div>
          <div style={{ color: 'var(--text-secondary)', fontSize: '14px' }}>
            This source didn't load.
          </div>
          <button onClick={nextSource} style={sourceBtnStyle}>
            Try Next Source ▸
          </button>
        </div>
      )}

      {/* ── Send to TV Panel ── */}
      {showTVPanel && (
        <div
          style={{
            position: 'absolute', inset: 0, zIndex: 20,
            background: 'rgba(0,0,0,0.92)', backdropFilter: 'blur(12px)',
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            justifyContent: 'center', padding: '24px',
          }}
          onClick={(e) => { if (e.target === e.currentTarget) setShowTVPanel(false); }}
        >
          <div style={{ maxWidth: '360px', width: '100%' }}>
            <div style={{
              fontSize: '18px', fontWeight: '700', color: 'white',
              marginBottom: '20px', textAlign: 'center',
            }}>
              Play on Your TV
            </div>

            {/* ── Option 1: AirPlay (Apple TV) ── */}
            <div style={tvOptionStyle}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
                <div style={tvIconStyle}>▶</div>
                <div>
                  <div style={{ fontSize: '15px', fontWeight: '600', color: 'white' }}>
                    AirPlay (Best)
                  </div>
                  <div style={{ fontSize: '12px', color: 'rgba(255,255,255,0.5)' }}>
                    Apple TV input
                  </div>
                </div>
              </div>
              <div style={{ fontSize: '13px', color: 'rgba(255,255,255,0.7)', lineHeight: '1.5' }}>
                Use <strong>Screen Mirroring</strong>, not AirPlay video:
              </div>
              <ol style={{
                fontSize: '13px', color: 'rgba(255,255,255,0.7)', lineHeight: '1.7',
                margin: '6px 0 0 0', paddingLeft: '20px',
              }}>
                <li>Open <strong>Control Center</strong> (swipe down from top-right)</li>
                <li>Tap the <strong>Screen Mirroring</strong> icon (two rectangles)</li>
                <li>Select your <strong>Apple TV</strong></li>
                <li>Play the video here — your whole screen mirrors to the TV</li>
              </ol>
              <div style={{
                fontSize: '11px', color: 'rgba(255,200,100,0.8)', marginTop: '8px',
                padding: '6px 8px', background: 'rgba(255,200,100,0.08)', borderRadius: '6px',
              }}>
                Tip: Screen Mirroring sends both audio + video. The regular AirPlay button inside video players often sends audio only from embedded sources.
              </div>
            </div>

            {/* ── Option 2: Roku ── */}
            <div style={tvOptionStyle}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
                <div style={tvIconStyle}>R</div>
                <div>
                  <div style={{ fontSize: '15px', fontWeight: '600', color: 'white' }}>
                    Roku
                  </div>
                  <div style={{ fontSize: '12px', color: 'rgba(255,255,255,0.5)' }}>
                    Roku TV input
                  </div>
                </div>
              </div>
              <div style={{ fontSize: '13px', color: 'rgba(255,255,255,0.7)', lineHeight: '1.7' }}>
                The <strong>Roku app</strong> on iPhone can mirror your screen:
              </div>
              <ol style={{
                fontSize: '13px', color: 'rgba(255,255,255,0.7)', lineHeight: '1.7',
                margin: '6px 0 0 0', paddingLeft: '20px',
              }}>
                <li>Open the <strong>Roku</strong> app on your iPhone</li>
                <li>Tap <strong>Media</strong> at the bottom</li>
                <li>Choose <strong>Screen Mirroring</strong> (or use AirPlay if your Roku supports it)</li>
                <li>Come back here and play</li>
              </ol>
              <button
                onClick={() => window.location.href = 'rokulnch://'}
                style={{
                  marginTop: '8px', width: '100%', padding: '10px',
                  background: 'rgba(109,76,165,0.3)', border: '1px solid rgba(109,76,165,0.5)',
                  borderRadius: '8px', color: '#c4a8e8', fontSize: '13px',
                  fontWeight: '500', cursor: 'pointer',
                }}
              >
                Open Roku App
              </button>
            </div>

            {/* ── Option 3: Google TV (fallback) ── */}
            <div style={tvOptionStyle}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
                <div style={tvIconStyle}>G</div>
                <div>
                  <div style={{ fontSize: '15px', fontWeight: '600', color: 'white' }}>
                    Google TV
                  </div>
                  <div style={{ fontSize: '12px', color: 'rgba(255,255,255,0.5)' }}>
                    Chromecast / Google TV input
                  </div>
                </div>
              </div>
              <div style={{ fontSize: '13px', color: 'rgba(255,255,255,0.7)', lineHeight: '1.7' }}>
                Open this video directly on your Google TV browser:
              </div>
              <ol style={{
                fontSize: '13px', color: 'rgba(255,255,255,0.7)', lineHeight: '1.7',
                margin: '6px 0 0 0', paddingLeft: '20px',
              }}>
                <li>On your Google TV, open the <strong>Chrome</strong> or <strong>Web Browser</strong> app</li>
                <li>Navigate to this URL:</li>
              </ol>
              <div
                onClick={() => {
                  navigator.clipboard?.writeText(streamUrl).then(() => {
                    const el = document.getElementById('copy-confirm');
                    if (el) { el.textContent = 'Copied!'; setTimeout(() => { el.textContent = 'Tap to copy URL'; }, 2000); }
                  });
                }}
                style={{
                  marginTop: '8px', padding: '10px 12px',
                  background: 'rgba(255,255,255,0.06)', borderRadius: '8px',
                  fontSize: '11px', color: 'rgba(255,255,255,0.5)',
                  wordBreak: 'break-all', cursor: 'pointer',
                  border: '1px solid rgba(255,255,255,0.1)',
                }}
              >
                <div style={{ fontSize: '10px', color: 'var(--accent)', marginBottom: '4px', fontWeight: '500' }} id="copy-confirm">
                  Tap to copy URL
                </div>
                {streamUrl}
              </div>
              <div style={{
                fontSize: '11px', color: 'rgba(255,255,255,0.4)', marginTop: '6px',
              }}>
                Or use the <strong>Google Home</strong> app to cast your iPhone screen to Google TV.
              </div>
            </div>

            <button
              onClick={() => setShowTVPanel(false)}
              style={{
                width: '100%', padding: '14px', marginTop: '8px',
                background: 'rgba(255,255,255,0.1)', border: 'none',
                borderRadius: '10px', color: 'white', fontSize: '14px',
                fontWeight: '500', cursor: 'pointer',
              }}
            >
              Back to Player
            </button>
          </div>
        </div>
      )}

      {/* The player iframe */}
      <iframe
        key={streamUrl}
        src={streamUrl}
        style={{
          flex: 1, width: '100%', border: 'none', backgroundColor: '#000',
        }}
        allowFullScreen
        allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
        referrerPolicy="origin"
        onError={() => setIframeError(true)}
      />

      {/* Bottom source indicator — always visible as a thin bar */}
      <div style={{
        backgroundColor: 'rgba(0,0,0,0.9)', padding: '6px 16px',
        display: 'flex', justifyContent: 'center', gap: '6px',
        paddingBottom: 'calc(6px + env(safe-area-inset-bottom, 0px))',
      }}>
        {SOURCES.map((s, i) => (
          <button
            key={s.id}
            onClick={() => { setSourceIndex(i); setIframeError(false); setShowControls(true); }}
            style={{
              width: '8px', height: '8px', borderRadius: '50%', border: 'none', cursor: 'pointer',
              backgroundColor: i === sourceIndex ? 'var(--accent)' : 'rgba(255,255,255,0.3)',
              padding: 0,
            }}
            title={s.name}
          />
        ))}
      </div>
    </div>
  );
}

const backBtnStyle: React.CSSProperties = {
  background: 'rgba(255,255,255,0.15)', border: 'none', color: 'white',
  padding: '8px 16px', borderRadius: '8px', fontSize: '14px', cursor: 'pointer',
  backdropFilter: 'blur(8px)',
};

const sourceBtnStyle: React.CSSProperties = {
  background: 'var(--accent)', border: 'none', color: 'white',
  padding: '8px 16px', borderRadius: '8px', fontSize: '13px', fontWeight: '500',
  cursor: 'pointer',
};

const tvBtnStyle: React.CSSProperties = {
  background: 'rgba(255,255,255,0.2)', border: '1px solid rgba(255,255,255,0.3)',
  color: 'white', padding: '6px 12px', borderRadius: '8px', fontSize: '12px',
  fontWeight: '600', cursor: 'pointer', backdropFilter: 'blur(8px)',
  letterSpacing: '0.5px',
};

const tvOptionStyle: React.CSSProperties = {
  padding: '16px', marginBottom: '10px',
  background: 'rgba(255,255,255,0.04)',
  border: '1px solid rgba(255,255,255,0.08)',
  borderRadius: '12px',
};

const tvIconStyle: React.CSSProperties = {
  width: '36px', height: '36px', borderRadius: '8px',
  background: 'rgba(255,255,255,0.1)',
  display: 'flex', alignItems: 'center', justifyContent: 'center',
  fontSize: '14px', fontWeight: '700', color: 'white',
  flexShrink: 0,
};
