import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getTraktToken } from '../lib/storage';
import { getTraktProfile } from '../lib/trakt';
import { getExportStatus, downloadExportCSV, downloadLetterboxdCSV, runDailyExportIfNeeded } from '../lib/export';
import {
  getRelayConfig,
  setRelayConfig,
  clearRelayConfig,
  refreshRelayStatus,
  pushToRelay,
  type RelayStatus,
} from '../lib/letterboxdRelay';

interface ApiStatus {
  tmdb: boolean;
  omdb: boolean;
  youtube: boolean;
  trakt: boolean;
}

export default function SettingsPage() {
  const navigate = useNavigate();
  const [traktConnected, setTraktConnected] = useState(false);
  const [traktUsername, setTraktUsername] = useState('');
  const [apiStatus, setApiStatus] = useState<ApiStatus>({
    tmdb: false,
    omdb: false,
    youtube: false,
    trakt: false
  });
  const [libraryCard, setLibraryCard] = useState('');
  const [loading, setLoading] = useState(true);

  // Letterboxd relay state
  const [relayUrl, setRelayUrl] = useState('');
  const [relayToken, setRelayToken] = useState('');
  const [relayStatus, setRelayStatus] = useState<RelayStatus | null>(null);
  const [relayBusy, setRelayBusy] = useState(false);

  useEffect(() => {
    // Check Trakt connection
    const token = getTraktToken();
    setTraktConnected(!!token);
    if (token) {
      getTraktProfile().then(profile => {
        if (profile) setTraktUsername(profile.username);
        else setTraktUsername('Connected');
      });
    }

    // Check API keys
    const omdbKey = import.meta.env.VITE_OMDB_API_KEY;
    const youtubeKey = import.meta.env.VITE_YOUTUBE_API_KEY;

    setApiStatus({
      tmdb: true, // hardcoded Bearer token
      omdb: !!omdbKey,
      youtube: !!youtubeKey,
      trakt: traktConnected
    });

    // Load library card from localStorage
    const saved = localStorage.getItem('seenit_library_card');
    if (saved) {
      setLibraryCard(saved);
    }

    // Letterboxd relay config + status
    const cfg = getRelayConfig();
    if (cfg) {
      setRelayUrl(cfg.url);
      setRelayToken(cfg.token);
      refreshRelayStatus().then(setRelayStatus);
    }

    setLoading(false);
  }, [traktConnected]);

  const handleConnectTrakt = () => {
    navigate('/auth/trakt');
  };

  const handleDisconnectTrakt = () => {
    localStorage.removeItem('seenit_trakt_token');
    setTraktConnected(false);
  };

  const handleLibraryCardSave = () => {
    if (libraryCard.trim()) {
      localStorage.setItem('seenit_library_card', libraryCard);
    } else {
      localStorage.removeItem('seenit_library_card');
    }
  };

  const getApiStatusColor = (status: boolean) => {
    return status ? 'var(--green)' : 'var(--text-secondary)';
  };

  const getApiStatusText = (status: boolean) => {
    return status ? 'Connected' : 'Not configured';
  };

  if (loading) {
    return (
      <div style={{
        padding: '16px',
        maxWidth: '480px',
        margin: '0 auto',
        textAlign: 'center',
        paddingTop: '40px'
      }}>
        <div style={{ width: 24, height: 24, border: '2px solid var(--text-secondary)', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.6s linear infinite', margin: '0 auto 16px' }} />
        <div style={{ color: 'var(--text-secondary)' }}>Loading...</div>
        <style>{`
          @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }

  return (
    <div style={{
      padding: '16px',
      maxWidth: '480px',
      margin: '0 auto',
      paddingBottom: 'env(safe-area-inset-bottom, 16px)'
    }}>
      {/* Header */}
      <h1 style={{
        fontSize: '24px',
        fontWeight: '600',
        color: 'var(--text-primary)',
        marginBottom: '24px'
      }}>
        Settings
      </h1>

      {/* Trakt Connection Section */}
      <div style={{ marginBottom: '24px' }}>
        <h2 style={{
          fontSize: '14px',
          fontWeight: '600',
          marginBottom: '12px',
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
          color: 'var(--text-secondary)'
        }}>
          Trakt.tv Sync
        </h2>

        {traktConnected ? (
          <div className="card" style={{ padding: '16px', marginBottom: '12px' }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '12px'
            }}>
              <div>
                <div style={{ fontSize: '14px', fontWeight: '500', color: 'var(--text-primary)' }}>
                  Connected as
                </div>
                <div style={{ fontSize: '13px', color: 'var(--green)', marginTop: '4px' }}>
                  {traktUsername}
                </div>
              </div>
              <div style={{ fontSize: '20px' }}>✅</div>
            </div>
            <button
              onClick={handleDisconnectTrakt}
              style={{
                width: '100%',
                padding: '10px',
                backgroundColor: 'transparent',
                border: '1px solid var(--red)',
                color: 'var(--red)',
                borderRadius: '6px',
                cursor: 'pointer',
                fontSize: '13px',
                fontWeight: '500'
              }}
            >
              Disconnect
            </button>
          </div>
        ) : (
          <div className="card" style={{ padding: '16px' }}>
            <div style={{
              fontSize: '13px',
              color: 'var(--text-secondary)',
              marginBottom: '12px'
            }}>
              Sync your watched movies, ratings, and watchlist with Trakt.tv
            </div>
            <button
              onClick={handleConnectTrakt}
              style={{
                width: '100%',
                padding: '12px',
                backgroundColor: 'var(--accent)',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: '500'
              }}
            >
              Connect Trakt
            </button>
          </div>
        )}
      </div>

      {/* API Status Section */}
      <div style={{ marginBottom: '24px' }}>
        <h2 style={{
          fontSize: '14px',
          fontWeight: '600',
          marginBottom: '12px',
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
          color: 'var(--text-secondary)'
        }}>
          API Status
        </h2>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {[
            { name: 'TMDB', key: 'tmdb', status: apiStatus.tmdb },
            { name: 'OMDB', key: 'omdb', status: apiStatus.omdb },
            { name: 'YouTube', key: 'youtube', status: apiStatus.youtube }
          ].map((api) => (
            <div
              key={api.key}
              className="card"
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '12px'
              }}
            >
              <div>
                <div style={{ fontSize: '14px', fontWeight: '500', color: 'var(--text-primary)' }}>
                  {api.name}
                </div>
                <div style={{ fontSize: '12px', color: getApiStatusColor(api.status), marginTop: '4px' }}>
                  {getApiStatusText(api.status)}
                </div>
              </div>
              <div style={{
                fontSize: '18px',
                color: getApiStatusColor(api.status)
              }}>
                {api.status ? '●' : '○'}
              </div>
            </div>
          ))}
        </div>

        <div style={{
          fontSize: '12px',
          color: 'var(--text-secondary)',
          marginTop: '12px',
          padding: '8px',
          backgroundColor: 'rgba(152, 152, 176, 0.05)',
          borderRadius: '6px'
        }}>
          API keys are configured via environment variables. See documentation for setup.
        </div>
      </div>

      {/* Library Card Section */}
      <div style={{ marginBottom: '24px' }}>
        <h2 style={{
          fontSize: '14px',
          fontWeight: '600',
          marginBottom: '12px',
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
          color: 'var(--text-secondary)'
        }}>
          Library Card
        </h2>

        <div className="card" style={{ padding: '16px' }}>
          <label style={{
            display: 'block',
            fontSize: '13px',
            color: 'var(--text-secondary)',
            marginBottom: '8px'
          }}>
            Library name (for Kanopy & Hoopla)
          </label>
          <input
            type="text"
            placeholder="e.g., San Francisco Public Library"
            value={libraryCard}
            onChange={(e) => setLibraryCard(e.target.value)}
            style={{
              width: '100%',
              padding: '10px',
              backgroundColor: 'var(--bg-secondary)',
              border: '1px solid rgba(255,255,255,0.06)',
              borderRadius: '6px',
              color: 'var(--text-primary)',
              fontSize: '14px',
              marginBottom: '12px'
            }}
          />
          <button
            onClick={handleLibraryCardSave}
            style={{
              width: '100%',
              padding: '10px',
              backgroundColor: 'var(--blue)',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '13px',
              fontWeight: '500'
            }}
          >
            Save
          </button>
        </div>
      </div>

      {/* Import Section */}
      <div style={{ marginBottom: '24px' }}>
        <h2 style={{
          fontSize: '14px',
          fontWeight: '600',
          marginBottom: '12px',
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
          color: 'var(--text-secondary)'
        }}>
          Import
        </h2>

        <div className="card" style={{ padding: '16px' }}>
          <div style={{ marginBottom: '12px' }}>
            <div style={{ fontSize: '14px', fontWeight: '500', color: 'var(--text-primary)', marginBottom: '8px' }}>
              IMDB Ratings
            </div>
            <div style={{ fontSize: '13px', color: 'var(--text-secondary)', marginBottom: '12px', lineHeight: '1.5' }}>
              Import your IMDB ratings and watchlist via Trakt. Ratings are synced automatically when Trakt is connected.
            </div>
            <a
              href="https://trakt.tv/users/settings/connections"
              target="_blank"
              rel="noopener noreferrer"
              style={{
                display: 'inline-block',
                padding: '10px 16px',
                backgroundColor: 'transparent',
                border: '1px solid var(--accent)',
                color: 'var(--accent)',
                borderRadius: '6px',
                cursor: 'pointer',
                fontSize: '13px',
                fontWeight: '500',
                textDecoration: 'none'
              }}
            >
              Open Trakt Import
            </a>
          </div>
        </div>
      </div>

      {/* About Section */}
      <div style={{ marginBottom: '24px' }}>
        <h2 style={{
          fontSize: '14px',
          fontWeight: '600',
          marginBottom: '12px',
          textTransform: 'uppercase',
          letterSpacing: '0.5px',
          color: 'var(--text-secondary)'
        }}>
          About
        </h2>

        <div className="card" style={{ padding: '16px' }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '16px'
          }}>
            <div style={{ fontSize: '14px', color: 'var(--text-primary)' }}>
              SeenIt
            </div>
            <div style={{ fontSize: '14px', fontWeight: '600', color: 'var(--text-secondary)' }}>
              v0.1.0
            </div>
          </div>

          <div style={{ fontSize: '12px', color: 'var(--text-secondary)', lineHeight: '1.6' }}>
            A movie and TV tracking app with Trakt.tv integration. Find free viewing options and manage your watchlist.
          </div>

          <div style={{
            display: 'flex',
            gap: '8px',
            marginTop: '12px'
          }}>
            <a
              href="https://github.com/dromako/seenit"
              target="_blank"
              rel="noopener noreferrer"
              style={{
                flex: 1,
                padding: '8px',
                backgroundColor: 'var(--bg-secondary)',
                border: '1px solid rgba(255,255,255,0.06)',
                borderRadius: '6px',
                color: 'var(--text-secondary)',
                textAlign: 'center',
                fontSize: '12px',
                textDecoration: 'none',
                cursor: 'pointer'
              }}
            >
              GitHub
            </a>
            <a
              href="https://trakt.tv"
              target="_blank"
              rel="noopener noreferrer"
              style={{
                flex: 1,
                padding: '8px',
                backgroundColor: 'var(--bg-secondary)',
                border: '1px solid rgba(255,255,255,0.06)',
                borderRadius: '6px',
                color: 'var(--text-secondary)',
                textAlign: 'center',
                fontSize: '12px',
                textDecoration: 'none',
                cursor: 'pointer'
              }}
            >
              Trakt
            </a>
          </div>
        </div>
      </div>

      {/* IMDB Export */}
      <div style={{
        borderTop: '1px solid rgba(255,255,255,0.06)',
        paddingTop: '24px',
        marginBottom: '24px',
      }}>
        <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-primary)', marginBottom: 8, letterSpacing: 0.5 }}>
          IMDB EXPORT
        </div>
        <div style={{ fontSize: '12px', color: 'var(--text-secondary)', marginBottom: 12 }}>
          {(() => {
            const status = getExportStatus();
            if (status.lastRun) {
              const ago = Math.round((Date.now() - status.lastRun.getTime()) / 3600000);
              return `Last export: ${ago < 1 ? 'just now' : `${ago}h ago`} · ${status.ratedCount} rated, ${status.watchedCount} watched`;
            }
            return 'Auto-exports daily on app open. Download anytime.';
          })()}
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={() => {
              if (!downloadExportCSV()) {
                // No export yet — run one now
                runDailyExportIfNeeded().then(ok => {
                  if (ok) downloadExportCSV();
                  else alert('Connect Trakt first to enable exports.');
                });
              }
            }}
            style={{
              flex: 1, padding: '10px', borderRadius: 6,
              border: '1px solid var(--accent-warm, #c4956a)',
              background: 'transparent', color: 'var(--accent-warm, #c4956a)',
              fontSize: 13, fontWeight: 500, cursor: 'pointer',
            }}
          >
            Download IMDB CSV
          </button>
          <button
            onClick={() => {
              runDailyExportIfNeeded().then(ok => {
                if (ok) alert('Export refreshed!');
                else alert('Already up to date (or Trakt not connected).');
              });
            }}
            style={{
              padding: '10px 16px', borderRadius: 6,
              border: '1px solid rgba(255,255,255,0.1)',
              background: 'transparent', color: 'var(--text-secondary)',
              fontSize: 13, cursor: 'pointer',
            }}
          >
            Refresh
          </button>
        </div>
      </div>

      {/* Letterboxd sync — relay-based, invisible until cookie expires */}
      <div style={{
        borderTop: '1px solid rgba(255,255,255,0.06)',
        paddingTop: '24px',
        marginBottom: '24px',
      }}>
        <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-primary)', marginBottom: 8, letterSpacing: 0.5 }}>
          LETTERBOXD SYNC
        </div>
        <div style={{ fontSize: '12px', color: 'var(--text-secondary)', marginBottom: 12, lineHeight: 1.5 }}>
          Pushes ratings to Letterboxd through a private Cloudflare Worker.
          Paste the relay URL and auth token — once set, sync is silent.
        </div>

        <input
          type="text"
          value={relayUrl}
          onChange={(e) => setRelayUrl(e.target.value)}
          placeholder="https://your-worker.workers.dev"
          style={{
            width: '100%', padding: '10px', borderRadius: 6,
            border: '1px solid rgba(255,255,255,0.1)',
            background: 'var(--bg-card)', color: 'var(--text-primary)',
            fontSize: 13, marginBottom: 8, boxSizing: 'border-box',
          }}
        />
        <input
          type="password"
          value={relayToken}
          onChange={(e) => setRelayToken(e.target.value)}
          placeholder="Auth token (X-Auth-Token)"
          style={{
            width: '100%', padding: '10px', borderRadius: 6,
            border: '1px solid rgba(255,255,255,0.1)',
            background: 'var(--bg-card)', color: 'var(--text-primary)',
            fontSize: 13, marginBottom: 8, boxSizing: 'border-box',
          }}
        />

        <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
          <button
            onClick={async () => {
              if (!relayUrl.trim() || !relayToken.trim()) {
                alert('Both URL and auth token are required.');
                return;
              }
              setRelayConfig(relayUrl, relayToken);
              setRelayBusy(true);
              await pushToRelay(true);
              const status = await refreshRelayStatus();
              setRelayStatus(status);
              setRelayBusy(false);
            }}
            disabled={relayBusy}
            style={{
              flex: 1, padding: '10px', borderRadius: 6,
              border: '1px solid var(--accent)',
              background: 'transparent', color: 'var(--accent)',
              fontSize: 13, fontWeight: 500, cursor: relayBusy ? 'wait' : 'pointer',
              opacity: relayBusy ? 0.6 : 1,
            }}
          >
            {relayBusy ? 'Syncing…' : 'Save & sync now'}
          </button>
          {getRelayConfig() && (
            <button
              onClick={() => {
                if (confirm('Disconnect the Letterboxd relay? Local config will be cleared.')) {
                  clearRelayConfig();
                  setRelayUrl('');
                  setRelayToken('');
                  setRelayStatus(null);
                }
              }}
              style={{
                padding: '10px 16px', borderRadius: 6,
                border: '1px solid rgba(255,255,255,0.1)',
                background: 'transparent', color: 'var(--text-secondary)',
                fontSize: 13, cursor: 'pointer',
              }}
            >
              Disconnect
            </button>
          )}
        </div>

        {relayStatus && (
          <div style={{ fontSize: 11, color: 'var(--text-secondary)', lineHeight: 1.7 }}>
            {relayStatus.lastSuccess && (
              <div>Last PWA push: {new Date(relayStatus.lastSuccess).toLocaleString()} ({relayStatus.rowsPushed} rows)</div>
            )}
            {relayStatus.workerLastLetterboxdSync && (
              <div>Last Letterboxd push: {new Date(relayStatus.workerLastLetterboxdSync).toLocaleString()}</div>
            )}
            {relayStatus.workerLastError && (
              <div style={{ color: 'var(--red)' }}>
                {relayStatus.workerLastError.message}
              </div>
            )}
            {relayStatus.lastError && !relayStatus.workerLastError && (
              <div style={{ color: 'var(--red)' }}>{relayStatus.lastError}</div>
            )}
          </div>
        )}

        <div style={{ marginTop: 12, fontSize: 11, color: 'var(--text-secondary)' }}>
          Or download the Letterboxd CSV and upload manually at letterboxd.com/import:
        </div>
        <button
          onClick={() => {
            if (!downloadLetterboxdCSV()) {
              runDailyExportIfNeeded().then(ok => {
                if (ok) downloadLetterboxdCSV();
                else alert('Connect Trakt first to enable exports.');
              });
            }
          }}
          style={{
            marginTop: 6,
            width: '100%', padding: '10px', borderRadius: 6,
            border: '1px solid var(--accent-warm, #c4956a)',
            background: 'transparent', color: 'var(--accent-warm, #c4956a)',
            fontSize: 13, fontWeight: 500, cursor: 'pointer',
          }}
        >
          Download Letterboxd CSV
        </button>
      </div>

      {/* Danger Zone */}
      <div style={{
        borderTop: '1px solid rgba(255,255,255,0.06)',
        paddingTop: '24px'
      }}>
        <button
          onClick={() => {
            if (confirm('Clear all local data? This cannot be undone.')) {
              localStorage.clear();
              alert('All data cleared.');
            }
          }}
          style={{
            width: '100%',
            padding: '12px',
            backgroundColor: 'transparent',
            border: '1px solid var(--red)',
            color: 'var(--red)',
            borderRadius: '6px',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: '500'
          }}
        >
          Clear All Local Data
        </button>
      </div>
    </div>
  );
}
