/**
 * BrowsePage — the primary discovery feed
 * Poster-heavy grid with ratings, genre tabs, infinite scroll,
 * and Trakt hidden-item suppression.
 */
import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  discoverContent,
  BROWSE_GENRES,
} from '../lib/discover';
import type { DiscoverItem, MediaFilter, SourceFilter } from '../lib/discover';
import {
  isTraktAuthenticated,
  getHiddenItems,
  getWatchedMovies,
  getWatchedShows,
  getWatchlist,
} from '../lib/trakt';
import { cacheGet, cacheSet } from '../lib/storage';

const POSTER_BASE = 'https://image.tmdb.org/t/p/w342';

/** Color for TMDB rating badge */
function ratingColor(score: number): string {
  if (score >= 7) return 'var(--green)';
  if (score >= 5) return 'var(--yellow)';
  if (score >= 3) return 'var(--orange)';
  return 'var(--red)';
}

/** Tiny pill component */
function Badge({ text, bg }: { text: string; bg: string }) {
  return (
    <span
      style={{
        display: 'inline-block',
        fontSize: 9,
        fontWeight: 700,
        padding: '2px 5px',
        borderRadius: 4,
        background: bg,
        color: '#fff',
        lineHeight: 1.2,
      }}
    >
      {text}
    </span>
  );
}

type TraktStatus = 'watched' | 'watchlisted' | null;

export default function BrowsePage() {
  const navigate = useNavigate();

  // --- filter state ---
  const [mediaFilter, setMediaFilter] = useState<MediaFilter>('all');
  const [sourceFilter, setSourceFilter] = useState<SourceFilter>('all');
  const [activeGenre, setActiveGenre] = useState(0); // 0 = Trending

  // --- content state ---
  const [items, setItems] = useState<DiscoverItem[]>([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const [initialLoad, setInitialLoad] = useState(true);

  // --- Trakt state ---
  const [hiddenSet, setHiddenSet] = useState<Set<string>>(new Set());
  const [watchedSet, setWatchedSet] = useState<Set<string>>(new Set());
  const [watchlistSet, setWatchlistSet] = useState<Set<string>>(new Set());

  const scrollRef = useRef<HTMLDivElement>(null);
  const sentinelRef = useRef<HTMLDivElement>(null);

  // ---- Load Trakt sets (cached 5 min) ----
  useEffect(() => {
    if (!isTraktAuthenticated()) return;

    async function loadTrakt() {
      try {
        // hidden
        const cHidden = cacheGet<string[]>('browse_hidden');
        if (cHidden) {
          setHiddenSet(new Set(cHidden));
        } else {
          const [hm, hs] = await Promise.all([
            getHiddenItems('movies'),
            getHiddenItems('shows'),
          ]);
          const keys = [
            ...hm.map((i) => `movie-${i.ids?.tmdb}`),
            ...hs.map((i) => `tv-${i.ids?.tmdb}`),
          ];
          cacheSet('browse_hidden', keys, 5);
          setHiddenSet(new Set(keys));
        }

        // watched
        const cWatched = cacheGet<string[]>('browse_watched');
        if (cWatched) {
          setWatchedSet(new Set(cWatched));
        } else {
          const [wm, ws] = await Promise.all([
            getWatchedMovies(),
            getWatchedShows(),
          ]);
          const keys = [
            ...wm.map((i) => `movie-${i.ids?.tmdb}`),
            ...ws.map((i) => `tv-${i.ids?.tmdb}`),
          ];
          cacheSet('browse_watched', keys, 5);
          setWatchedSet(new Set(keys));
        }

        // watchlist
        const cWL = cacheGet<string[]>('browse_watchlist');
        if (cWL) {
          setWatchlistSet(new Set(cWL));
        } else {
          const [wlm, wls] = await Promise.all([
            getWatchlist('movies'),
            getWatchlist('shows'),
          ]);
          const keys = [
            ...wlm.map((i) => `movie-${i.ids?.tmdb}`),
            ...wls.map((i) => `tv-${i.ids?.tmdb}`),
          ];
          cacheSet('browse_watchlist', keys, 5);
          setWatchlistSet(new Set(keys));
        }
      } catch (err) {
        console.warn('[Browse] Trakt load error:', err);
      }
    }

    loadTrakt();
  }, []);

  // ---- Fetch content when filters change ----
  const fetchPage = useCallback(
    async (pageNum: number, append: boolean) => {
      setLoading(true);
      try {
        const res = await discoverContent({
          mediaType: mediaFilter,
          genre: activeGenre,
          sourceFilter,
          page: pageNum,
        });

        // Filter out hidden items
        const filtered = res.results.filter((item) => {
          const key = `${item.media_type}-${item.id}`;
          return !hiddenSet.has(key);
        });

        setItems((prev) => (append ? [...prev, ...filtered] : filtered));
        setTotalPages(res.total_pages);
        setPage(pageNum);
      } catch (err) {
        console.error('[Browse] Discover error:', err);
      } finally {
        setLoading(false);
        setInitialLoad(false);
      }
    },
    [mediaFilter, activeGenre, sourceFilter, hiddenSet]
  );

  // Reset + fetch when filters change
  useEffect(() => {
    setItems([]);
    setPage(1);
    setInitialLoad(true);
    fetchPage(1, false);
  }, [mediaFilter, activeGenre, sourceFilter, hiddenSet]);

  // ---- Infinite scroll via IntersectionObserver ----
  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !loading && page < totalPages) {
          fetchPage(page + 1, true);
        }
      },
      { rootMargin: '400px' }
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [loading, page, totalPages, fetchPage]);

  // ---- Helpers ----
  function traktStatus(item: DiscoverItem): TraktStatus {
    const key = `${item.media_type}-${item.id}`;
    if (watchedSet.has(key)) return 'watched';
    if (watchlistSet.has(key)) return 'watchlisted';
    return null;
  }

  // ---- Render ----
  return (
    <div ref={scrollRef} style={{ paddingTop: 12 }}>
      {/* ── Header ── */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 12,
        }}
      >
        <h1
          style={{
            fontSize: 22,
            fontWeight: 700,
            color: 'var(--text-primary)',
            display: 'flex',
            alignItems: 'center',
            gap: 8,
          }}
        >
          <span style={{ fontSize: 26 }}>⚡</span> Browse
        </h1>

        {/* Media type toggle */}
        <div style={{ display: 'flex', gap: 4 }}>
          {(['all', 'movie', 'tv'] as MediaFilter[]).map((m) => (
            <button
              key={m}
              onClick={() => setMediaFilter(m)}
              style={{
                padding: '4px 10px',
                borderRadius: 8,
                border: 'none',
                fontSize: 12,
                fontWeight: 600,
                cursor: 'pointer',
                background:
                  mediaFilter === m ? 'var(--accent)' : 'var(--bg-card)',
                color:
                  mediaFilter === m ? '#fff' : 'var(--text-secondary)',
                transition: 'all 0.15s',
              }}
            >
              {m === 'all' ? 'All' : m === 'movie' ? 'Movies' : 'TV'}
            </button>
          ))}
        </div>
      </div>

      {/* ── Free toggle ── */}
      <button
        onClick={() =>
          setSourceFilter((s) => (s === 'free' ? 'all' : 'free'))
        }
        style={{
          width: '100%',
          padding: '8px 12px',
          marginBottom: 10,
          borderRadius: 10,
          border:
            sourceFilter === 'free'
              ? '1px solid var(--green)'
              : '1px solid rgba(255,255,255,0.08)',
          background:
            sourceFilter === 'free'
              ? 'rgba(34,197,94,0.12)'
              : 'var(--bg-card)',
          color:
            sourceFilter === 'free'
              ? 'var(--green)'
              : 'var(--text-secondary)',
          fontSize: 13,
          fontWeight: 600,
          cursor: 'pointer',
          transition: 'all 0.2s',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 6,
        }}
      >
        {sourceFilter === 'free' ? '✅' : '🆓'}{' '}
        {sourceFilter === 'free'
          ? 'Showing Free / Ad-Supported Only'
          : 'Show Free Sources Only'}
      </button>

      {/* ── Genre chips (horizontal scroll) ── */}
      <div
        style={{
          display: 'flex',
          gap: 6,
          overflowX: 'auto',
          paddingBottom: 10,
          marginBottom: 8,
          scrollbarWidth: 'none',
          WebkitOverflowScrolling: 'touch',
        }}
      >
        {BROWSE_GENRES.map((g) => (
          <button
            key={g.id}
            onClick={() => setActiveGenre(g.id)}
            style={{
              flexShrink: 0,
              padding: '6px 14px',
              borderRadius: 20,
              border: 'none',
              fontSize: 12,
              fontWeight: 600,
              cursor: 'pointer',
              background:
                activeGenre === g.id ? 'var(--accent)' : 'var(--bg-card)',
              color:
                activeGenre === g.id ? '#fff' : 'var(--text-secondary)',
              transition: 'all 0.15s',
            }}
          >
            {g.id === -1 ? '💀 ' : ''}
            {g.name}
          </button>
        ))}
      </div>

      {/* ── Poster grid ── */}
      {initialLoad ? (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: 10,
          }}
        >
          {Array.from({ length: 9 }).map((_, i) => (
            <div
              key={i}
              style={{
                aspectRatio: '2/3',
                borderRadius: 10,
                background: 'var(--bg-card)',
                animation: 'pulse 1.5s ease-in-out infinite',
              }}
            />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div
          style={{
            textAlign: 'center',
            padding: '40px 20px',
            color: 'var(--text-secondary)',
          }}
        >
          <div style={{ fontSize: 40, marginBottom: 12 }}>🎬</div>
          <div style={{ fontSize: 15, fontWeight: 600 }}>Nothing found</div>
          <div style={{ fontSize: 13, marginTop: 4 }}>
            Try a different genre or turn off the free filter
          </div>
        </div>
      ) : (
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: 10,
          }}
        >
          {items.map((item) => {
            const status = traktStatus(item);
            return (
              <div
                key={`${item.media_type}-${item.id}`}
                onClick={() =>
                  navigate(`/title/${item.id}/${item.media_type}`)
                }
                className="fade-in"
                style={{
                  position: 'relative',
                  cursor: 'pointer',
                  borderRadius: 10,
                  overflow: 'hidden',
                  background: 'var(--bg-card)',
                  transition: 'transform 0.15s',
                }}
              >
                {/* Poster */}
                <img
                  src={`${POSTER_BASE}${item.poster_path}`}
                  alt={item.title}
                  loading="lazy"
                  style={{
                    width: '100%',
                    aspectRatio: '2/3',
                    objectFit: 'cover',
                    display: 'block',
                  }}
                />

                {/* Rating badge (top-left) */}
                <div
                  style={{
                    position: 'absolute',
                    top: 6,
                    left: 6,
                    background: 'rgba(0,0,0,0.75)',
                    borderRadius: 6,
                    padding: '2px 6px',
                    display: 'flex',
                    alignItems: 'center',
                    gap: 3,
                  }}
                >
                  <span style={{ fontSize: 10, color: '#fbbf24' }}>★</span>
                  <span
                    style={{
                      fontSize: 11,
                      fontWeight: 700,
                      color: ratingColor(item.vote_average),
                    }}
                  >
                    {item.vote_average.toFixed(1)}
                  </span>
                </div>

                {/* Media type badge (top-right) */}
                <div
                  style={{
                    position: 'absolute',
                    top: 6,
                    right: 6,
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 3,
                    alignItems: 'flex-end',
                  }}
                >
                  {item.media_type === 'tv' && (
                    <Badge text="TV" bg="var(--blue)" />
                  )}
                  {status === 'watched' && (
                    <Badge text="✓ Seen" bg="var(--green)" />
                  )}
                  {status === 'watchlisted' && (
                    <Badge text="📋" bg="var(--accent)" />
                  )}
                </div>

                {/* Bottom gradient with title */}
                <div
                  style={{
                    position: 'absolute',
                    bottom: 0,
                    left: 0,
                    right: 0,
                    padding: '24px 8px 8px',
                    background:
                      'linear-gradient(transparent, rgba(0,0,0,0.85))',
                  }}
                >
                  <div
                    style={{
                      fontSize: 11,
                      fontWeight: 600,
                      color: '#fff',
                      lineHeight: 1.3,
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {item.title}
                  </div>
                  {item.year && (
                    <div
                      style={{
                        fontSize: 9,
                        color: 'rgba(255,255,255,0.6)',
                        marginTop: 1,
                      }}
                    >
                      {item.year}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── Infinite scroll sentinel ── */}
      <div ref={sentinelRef} style={{ height: 1 }} />

      {/* Loading indicator */}
      {loading && !initialLoad && (
        <div
          style={{
            textAlign: 'center',
            padding: '20px 0',
            color: 'var(--text-secondary)',
            fontSize: 13,
          }}
        >
          Loading more…
        </div>
      )}

      {/* End of results */}
      {!loading && page >= totalPages && items.length > 0 && (
        <div
          style={{
            textAlign: 'center',
            padding: '16px 0 8px',
            color: 'var(--text-secondary)',
            fontSize: 12,
          }}
        >
          You've seen it all — try another genre
        </div>
      )}
    </div>
  );
}
