import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { cacheGet, cacheSet, trackOmdbRequest } from '../lib/storage';
import { getRatedItems, isTraktAuthenticated } from '../lib/trakt';
import { getOMDBData } from '../lib/omdb';
import type { RatedItem } from '../lib/trakt';

/* ─── constants ─── */

const TMDB_POSTER = 'https://image.tmdb.org/t/p/w200';
const TMDB_API_KEY = import.meta.env.VITE_TMDB_API_KEY;
const DEFAULT_THRESHOLD = 6;     // expanded — catches interesting divisive films
const CACHE_KEY_FULL = 'library_full';    // all rated items + TMDB data
const CACHE_KEY_CRITICS = 'library_critics'; // OMDB critic data for 7+ items
const CACHE_TTL = 10080;         // 7 days in minutes

/* ─── genre map (TMDB IDs → human labels) ─── */

const GENRE_LABELS: Record<number, string> = {
  28: 'Action', 12: 'Adventure', 16: 'Animation', 35: 'Comedy',
  80: 'Crime', 99: 'Documentary', 18: 'Drama', 10751: 'Family',
  14: 'Fantasy', 36: 'History', 27: 'Horror', 10402: 'Music',
  9648: 'Mystery', 10749: 'Romance', 878: 'Sci-Fi', 10770: 'TV Movie',
  53: 'Thriller', 10752: 'War', 37: 'Western',
  10759: 'Action & Adventure', 10765: 'Sci-Fi & Fantasy',
  10768: 'War & Politics', 10767: 'Talk', 10766: 'Soap',
  10764: 'Reality', 10763: 'News',
};

// Merge TV-specific genres into their movie equivalents for cleaner rows
const GENRE_MERGE: Record<number, number> = {
  10759: 28, 10765: 878, 10768: 10752,
};

/* ─── types ─── */

interface CriticData {
  metacritic: number | null;   // 0-100
  rottenTomatoes: number | null; // 0-100 (parsed from "93%")
  imdbRating: number | null;   // 0-10
}

interface PickItem {
  tmdbId: number;
  title: string;
  year: number;
  mediaType: 'movie' | 'tv';
  rating: number;         // user's 1-10
  ratedAt: string;
  posterPath: string | null;
  tmdbScore: number;      // general audience (0-10)
  genreIds: number[];
  imdbId?: string;
  // Real critic data (only for 7+ items, fetched from OMDB)
  metacritic: number | null;
  rottenTomatoes: number | null;
  imdbRating: number | null;
}

interface GenreRow {
  id: number;
  label: string;
  items: PickItem[];
}

/* ─── critic score computation ─── */

/**
 * Compute a single 0-10 "critic confidence" score.
 * Prioritizes: Metacritic (professional critics) > Rotten Tomatoes
 * (critic consensus) > TMDB (general audience fallback).
 *
 * When multiple sources agree, the score is boosted slightly.
 */
function criticScore(item: PickItem): number {
  const sources: number[] = [];

  if (item.metacritic != null && item.metacritic > 0) {
    sources.push(item.metacritic / 10); // 0-100 → 0-10
  }
  if (item.rottenTomatoes != null && item.rottenTomatoes > 0) {
    sources.push(item.rottenTomatoes / 10); // 0-100 → 0-10
  }
  if (item.imdbRating != null && item.imdbRating > 0) {
    sources.push(item.imdbRating); // already 0-10
  }

  // If we have real critic data, weight Metacritic highest
  if (sources.length > 0) {
    // Weighted average: first source (MC) gets 50%, rest split evenly
    if (sources.length === 1) return sources[0];
    const mcWeight = 0.5;
    const restWeight = 0.5 / (sources.length - 1);
    return sources[0] * mcWeight + sources.slice(1).reduce((s, v) => s + v * restWeight, 0);
  }

  // Fallback to TMDB general audience
  return item.tmdbScore > 0 ? item.tmdbScore : 0;
}

/**
 * Blended sort score: critic opinion weighted more than user stars.
 * A film you rated 7 that Metacritic calls 92 will outrank a film
 * you rated 9 that critics are lukewarm on.
 *
 * When NO critic data exists, we discount the score slightly so that
 * unknown-to-critics titles don't float above critically celebrated ones.
 * This prevents random Trakt artifacts from sitting at the top.
 */
function sortScore(item: PickItem): number {
  const cs = criticScore(item);
  // No critic data: discount user rating so these sink below critic-validated items
  if (cs === 0) return item.rating * 0.7;
  return item.rating * 0.35 + cs * 0.65;
}

/**
 * Best critic badge to display on a poster.
 * Returns label + color, preferring Metacritic → RT → IMDB → TMDB.
 */
function criticBadge(item: PickItem): { label: string; color: string } | null {
  if (item.metacritic != null && item.metacritic > 0) {
    return {
      label: `MC ${item.metacritic}`,
      color: item.metacritic >= 70 ? '#4ade80' : item.metacritic >= 50 ? '#facc15' : '#f87171',
    };
  }
  if (item.rottenTomatoes != null && item.rottenTomatoes > 0) {
    return {
      label: `RT ${item.rottenTomatoes}%`,
      color: item.rottenTomatoes >= 70 ? '#4ade80' : item.rottenTomatoes >= 50 ? '#facc15' : '#f87171',
    };
  }
  if (item.imdbRating != null && item.imdbRating > 0) {
    return {
      label: `IMDb ${item.imdbRating.toFixed(1)}`,
      color: item.imdbRating >= 7 ? '#4ade80' : item.imdbRating >= 5.5 ? '#facc15' : '#f87171',
    };
  }
  if (item.tmdbScore > 0) {
    return {
      label: item.tmdbScore.toFixed(1),
      color: item.tmdbScore >= 7 ? '#4ade80' : item.tmdbScore >= 5.5 ? '#facc15' : '#f87171',
    };
  }
  return null;
}

/* ─── data fetching ─── */

/** Enrich items with TMDB poster + genres + vote_average */
async function enrichWithTMDB(items: RatedItem[]): Promise<PickItem[]> {
  const picks: PickItem[] = [];

  for (let i = 0; i < items.length; i += 8) {
    const batch = items.slice(i, i + 8);
    const results = await Promise.allSettled(
      batch.map(async (item) => {
        if (!item.ids.tmdb) return null;
        const type = item.mediaType === 'tv' ? 'tv' : 'movie';
        const res = await fetch(
          `https://api.themoviedb.org/3/${type}/${item.ids.tmdb}?api_key=${TMDB_API_KEY}&language=en-US`
        );
        if (!res.ok) return null;
        const data = await res.json();
        return {
          tmdbId: item.ids.tmdb,
          title: item.title,
          year: item.year,
          mediaType: item.mediaType,
          rating: item.rating,
          ratedAt: item.rated_at,
          posterPath: data.poster_path || null,
          tmdbScore: Math.round((data.vote_average || 0) * 10) / 10,
          genreIds: (data.genres || []).map((g: any) => g.id),
          imdbId: item.ids.imdb || data.imdb_id || undefined,
          metacritic: null,
          rottenTomatoes: null,
          imdbRating: null,
        } as PickItem;
      })
    );

    for (const r of results) {
      if (r.status === 'fulfilled' && r.value) picks.push(r.value);
    }
  }

  return picks;
}

/** Fetch OMDB critic data for items rated at threshold or above */
async function enrichWithCritics(
  picks: PickItem[],
  threshold: number
): Promise<Map<number, CriticData>> {
  const criticMap = new Map<number, CriticData>();
  const eligible = picks.filter(p => p.rating >= threshold && p.imdbId);

  for (let i = 0; i < eligible.length; i += 5) {
    // Stop if OMDB daily quota (1000 requests/day) is exhausted
    if (!trackOmdbRequest()) {
      console.warn('[Library] OMDB daily quota reached — stopping critic enrichment');
      break;
    }
    const batch = eligible.slice(i, i + 5);
    const results = await Promise.allSettled(
      batch.map(async (item) => {
        const data = await getOMDBData(item.imdbId!);
        // Parse RT percentage string: "93%" → 93
        let rtNum: number | null = null;
        if (data.rottenTomatoes) {
          const m = data.rottenTomatoes.match(/(\d+)/);
          if (m) rtNum = parseInt(m[1]);
        }
        return {
          tmdbId: item.tmdbId,
          critics: {
            metacritic: data.metacritic,
            rottenTomatoes: rtNum,
            imdbRating: data.imdb,
          } as CriticData,
        };
      })
    );

    for (const r of results) {
      if (r.status === 'fulfilled' && r.value) {
        criticMap.set(r.value.tmdbId, r.value.critics);
      }
    }
  }

  return criticMap;
}

/* ─── row builders ─── */

function buildRows(picks: PickItem[], mediaFilter: 'all' | 'movie' | 'tv', threshold: number): {
  special: GenreRow[];
  genres: GenreRow[];
} {
  const filtered = picks
    .filter(p => p.rating >= threshold)
    .filter(p => mediaFilter === 'all' || p.mediaType === mediaFilter)
    // Filter out likely Trakt sync artifacts: items with no TMDB score AND
    // no critic data at all. Real films David rated have at least a TMDB score.
    .filter(p => p.tmdbScore > 0 || p.metacritic != null || p.rottenTomatoes != null || p.imdbRating != null);

  // Sort by blended score (critic-weighted)
  const sorted = [...filtered].sort((a, b) => sortScore(b) - sortScore(a));

  // Special rows
  const now = new Date();
  const thisYear = now.getFullYear();
  const lastYear = thisYear - 1;

  const recent = sorted.filter(p => p.year >= lastYear);
  const allTime = sorted.filter(p => p.rating >= 9);

  const special: GenreRow[] = [];
  // Track titles claimed by special rows so they don't repeat in genre rows
  const specialClaimed = new Set<number>();
  if (recent.length > 0) {
    special.push({ id: -1, label: `Recent (${lastYear}\u2013${thisYear})`, items: recent });
    recent.forEach(p => specialClaimed.add(p.tmdbId));
  }
  if (allTime.length > 0) {
    special.push({ id: -2, label: 'All-Time Favorites', items: allTime });
    allTime.forEach(p => specialClaimed.add(p.tmdbId));
  }

  // Genre rows — each title appears in exactly ONE genre row (its rarest
  // genre). Titles already claimed by special rows are excluded entirely
  // so nothing repeats across the page.
  const genreEligible = sorted.filter(p => !specialClaimed.has(p.tmdbId));
  const genreMap = new Map<number, PickItem[]>();
  const genreCounts = new Map<number, number>();
  for (const item of genreEligible) {
    for (let gid of item.genreIds) {
      gid = GENRE_MERGE[gid] ?? gid;
      if (!GENRE_LABELS[gid]) continue;
      genreCounts.set(gid, (genreCounts.get(gid) || 0) + 1);
    }
  }

  for (const item of genreEligible) {
    const merged = item.genreIds.map(g => GENRE_MERGE[g] ?? g).filter(g => GENRE_LABELS[g]);
    const byRarity = [...new Set(merged)].sort((a, b) => (genreCounts.get(a) || 0) - (genreCounts.get(b) || 0));
    if (byRarity.length > 0) {
      const primary = byRarity[0];
      if (!genreMap.has(primary)) genreMap.set(primary, []);
      genreMap.get(primary)!.push(item);
    }
  }

  const genres: GenreRow[] = [];
  for (const [gid, items] of genreMap.entries()) {
    if (items.length >= 2) {
      genres.push({ id: gid, label: GENRE_LABELS[gid], items });
    }
  }
  genres.sort((a, b) => b.items.length - a.items.length);

  return { special, genres };
}

/* ─── poster row component ─── */

function PosterRow({ row, onTap }: {
  row: GenreRow;
  onTap: (item: PickItem) => void;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);

  return (
    <div style={{ marginBottom: 28 }}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'baseline',
        padding: '0 16px',
        marginBottom: 10,
      }}>
        <h2 style={{
          fontSize: 16, fontWeight: 600,
          color: 'var(--text-primary)', margin: 0,
        }}>
          {row.label}
        </h2>
        <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>
          {row.items.length}
        </span>
      </div>

      <div
        ref={scrollRef}
        style={{
          display: 'flex',
          gap: 10,
          overflowX: 'auto',
          paddingLeft: 16, paddingRight: 16, paddingBottom: 4,
          scrollSnapType: 'x mandatory',
          WebkitOverflowScrolling: 'touch',
          msOverflowStyle: 'none',
          scrollbarWidth: 'none',
        }}
      >
        {row.items.map((item) => (
          <PosterCard key={`${item.tmdbId}-${item.mediaType}`} item={item} onTap={onTap} />
        ))}
      </div>
    </div>
  );
}

/* ─── poster card component ─── */

function PosterCard({ item, onTap, gridMode }: {
  item: PickItem;
  onTap: (item: PickItem) => void;
  gridMode?: boolean;
}) {
  const badge = criticBadge(item);

  return (
    <button
      onClick={() => onTap(item)}
      style={{
        flex: gridMode ? undefined : '0 0 auto',
        width: gridMode ? '100%' : 105,
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        padding: 0,
        textAlign: 'left',
        scrollSnapAlign: gridMode ? undefined : 'start',
      }}
    >
      <div style={{ position: 'relative', marginBottom: 6 }}>
        {item.posterPath ? (
          <img
            src={`${TMDB_POSTER}${item.posterPath}`}
            alt={item.title}
            loading="lazy"
            style={{
              width: '100%',
              aspectRatio: '2/3',
              borderRadius: 8,
              objectFit: 'cover',
              backgroundColor: 'var(--bg-card)',
              display: 'block',
            }}
          />
        ) : (
          <div style={{
            width: '100%', aspectRatio: '2/3', borderRadius: 8,
            backgroundColor: 'var(--bg-card)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 28, color: 'var(--text-secondary)',
          }}>
            {item.title.charAt(0).toUpperCase()}
          </div>
        )}

        {/* User rating — top-right */}
        <div style={{
          position: 'absolute', top: 4, right: 4,
          minWidth: 26, height: 26, borderRadius: 6,
          backgroundColor: item.rating >= 9 ? 'var(--accent)' : 'rgba(0,0,0,0.75)',
          color: item.rating >= 9 ? '#fff' : 'var(--yellow)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 12, fontWeight: 700, padding: '0 5px',
        }}>
          {item.rating}
        </div>

        {/* Critic badge — bottom-left (MC > RT > IMDb > TMDB) */}
        {badge && (
          <div style={{
            position: 'absolute', bottom: 4, left: 4,
            height: 20, borderRadius: 4,
            backgroundColor: 'rgba(0,0,0,0.7)',
            color: badge.color,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 9, fontWeight: 700, padding: '0 5px',
            letterSpacing: 0.3,
          }}>
            {badge.label}
          </div>
        )}

        {/* TV badge — top-left */}
        {item.mediaType === 'tv' && (
          <div style={{
            position: 'absolute', top: 4, left: 4,
            height: 18, borderRadius: 3,
            backgroundColor: 'rgba(99,102,241,0.85)',
            color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 9, fontWeight: 700, padding: '0 5px',
            letterSpacing: 0.5, textTransform: 'uppercase',
          }}>
            TV
          </div>
        )}
      </div>

      <div style={{
        fontSize: 11, color: 'var(--text-primary)',
        overflow: 'hidden', textOverflow: 'ellipsis',
        whiteSpace: 'nowrap', lineHeight: 1.3,
      }}>
        {item.title}
      </div>
    </button>
  );
}

/* ─── main page ─── */

export default function HistoryPage() {
  const navigate = useNavigate();
  const [picks, setPicks] = useState<PickItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingPhase, setLoadingPhase] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [mediaFilter, setMediaFilter] = useState<'all' | 'movie' | 'tv'>('all');
  const [threshold, setThreshold] = useState(DEFAULT_THRESHOLD);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => {
    if (!isTraktAuthenticated()) {
      setLoading(false);
      setError('Connect Trakt in Settings to see your picks.');
      return;
    }

    const load = async () => {
      setLoading(true);
      setError(null);

      try {
        // ── Step 1: Check weekly cache for full library ──
        const cachedFull = cacheGet<PickItem[]>(CACHE_KEY_FULL);
        if (cachedFull && cachedFull.length > 0) {
          // Also apply cached critic data
          const cachedCritics = cacheGet<Record<number, CriticData>>(CACHE_KEY_CRITICS);
          if (cachedCritics) {
            for (const p of cachedFull) {
              const cd = cachedCritics[p.tmdbId];
              if (cd) {
                p.metacritic = cd.metacritic;
                p.rottenTomatoes = cd.rottenTomatoes;
                p.imdbRating = cd.imdbRating;
              }
            }
          }
          setPicks(cachedFull);
          setLoading(false);
          return;
        }

        // ── Step 2: Fetch ALL rated items from Trakt ──
        setLoadingPhase('Fetching your ratings from Trakt...');
        const allRated = await getRatedItems();

        if (allRated.length === 0) {
          setPicks([]);
          setLoading(false);
          return;
        }

        // ── Step 3: Enrich ALL items with TMDB (poster, genres, audience score) ──
        setLoadingPhase(`Loading posters & genres for ${allRated.length} titles...`);
        const enriched = await enrichWithTMDB(allRated);

        // Save the full library to cache immediately so it renders
        setPicks(enriched);
        cacheSet(CACHE_KEY_FULL, enriched, CACHE_TTL);

        // ── Step 4: Fetch real critic data for 7+ items (OMDB: Metacritic, RT) ──
        const recommended = enriched.filter(p => p.rating >= DEFAULT_THRESHOLD);
        if (recommended.length > 0) {
          setLoadingPhase(`Checking critics for ${recommended.length} picks...`);
          const criticMap = await enrichWithCritics(enriched, DEFAULT_THRESHOLD);

          // Apply critic data to items
          const criticCache: Record<number, CriticData> = {};
          for (const p of enriched) {
            const cd = criticMap.get(p.tmdbId);
            if (cd) {
              p.metacritic = cd.metacritic;
              p.rottenTomatoes = cd.rottenTomatoes;
              p.imdbRating = cd.imdbRating;
              criticCache[p.tmdbId] = cd;
            }
          }

          // Update cache with critic data
          cacheSet(CACHE_KEY_FULL, enriched, CACHE_TTL);
          cacheSet(CACHE_KEY_CRITICS, criticCache, CACHE_TTL);
          setPicks([...enriched]); // trigger re-render with critic data
        }
      } catch (err) {
        console.error('Error loading library:', err);
        setError('Failed to load your library. Check your Trakt connection.');
      } finally {
        setLoading(false);
      }
    };

    load();
  }, []);

  const handleTap = (item: PickItem) => {
    navigate(`/title/${item.tmdbId}/${item.mediaType}`);
  };

  // Build genre rows
  const { special, genres } = buildRows(picks, mediaFilter, threshold);
  const allRows = [...special, ...genres];

  // Search results — flat grid
  const searchResults = searchQuery.trim()
    ? picks
        .filter(p => p.rating >= threshold)
        .filter(p => mediaFilter === 'all' || p.mediaType === mediaFilter)
        .filter(p => p.title.toLowerCase().includes(searchQuery.toLowerCase()))
        .sort((a, b) => sortScore(b) - sortScore(a))
    : null;

  const totalAboveThreshold = picks
    .filter(p => p.rating >= threshold)
    .filter(p => mediaFilter === 'all' || p.mediaType === mediaFilter)
    .length;

  return (
    <div style={{ paddingTop: 16, paddingBottom: 'env(safe-area-inset-bottom, 16px)' }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '0 16px',
        marginBottom: 6,
      }}>
        <h1 style={{
          fontSize: 22, fontWeight: 700,
          color: 'var(--text-primary)', margin: 0, lineHeight: 1.2,
        }}>
          My Picks
        </h1>

        {/* Search toggle */}
        {!loading && picks.length > 0 && (
          <button
            onClick={() => { setSearchOpen(!searchOpen); setSearchQuery(''); }}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              padding: 6,
              color: searchOpen ? 'var(--accent)' : 'var(--text-secondary)',
            }}
            aria-label="Search picks"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="7" /><line x1="16.5" y1="16.5" x2="21" y2="21" />
            </svg>
          </button>
        )}
      </div>

      {/* Subtitle line */}
      {!loading && picks.length > 0 && (
        <div style={{
          padding: '0 16px',
          marginBottom: 14,
          fontSize: 12,
          color: 'var(--text-secondary)',
          display: 'flex',
          alignItems: 'center',
          gap: 6,
        }}>
          <span>{totalAboveThreshold} picks</span>
          <span style={{ opacity: 0.4 }}>·</span>
          <span>{picks.length} total in library</span>
          <span style={{ opacity: 0.4 }}>·</span>
          <span>sorted by critic consensus</span>
        </div>
      )}

      {/* Search bar (collapsible) */}
      {searchOpen && (
        <div style={{ padding: '0 16px', marginBottom: 12 }}>
          <label htmlFor="library-search" className="sr-only" style={{ position: 'absolute', width: 1, height: 1, padding: 0, margin: -1, overflow: 'hidden', clip: 'rect(0,0,0,0)', whiteSpace: 'nowrap', border: 0 }}>Search your picks</label>
          <input
            id="library-search"
            type="text"
            placeholder="Find a pick..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            autoFocus
            style={{
              width: '100%', padding: '10px 12px',
              backgroundColor: 'var(--bg-card)',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: 8, color: 'var(--text-primary)',
              fontSize: 14, outline: 'none', boxSizing: 'border-box',
            }}
          />
        </div>
      )}

      {/* Filter row: media chips + threshold toggle */}
      {!loading && picks.length > 0 && (
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: '0 16px',
          marginBottom: 20,
          gap: 8,
        }}>
          {/* Media filter chips */}
          <div style={{ display: 'flex', gap: 8 }}>
            {([['all', 'All'], ['movie', 'Movies'], ['tv', 'Shows']] as const).map(([key, label]) => (
              <button
                key={key}
                onClick={() => setMediaFilter(key)}
                style={{
                  padding: '6px 14px',
                  backgroundColor: mediaFilter === key ? 'var(--accent)' : 'var(--bg-card)',
                  color: mediaFilter === key ? '#fff' : 'var(--text-secondary)',
                  border: '1px solid rgba(255,255,255,0.06)',
                  borderRadius: 20, cursor: 'pointer',
                  fontSize: 13, fontWeight: 500,
                  transition: 'background 0.15s',
                }}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Threshold toggle */}
          <button
            onClick={() => setThreshold(threshold === DEFAULT_THRESHOLD ? 1 : DEFAULT_THRESHOLD)}
            style={{
              padding: '6px 10px',
              backgroundColor: threshold === 1 ? 'rgba(255,255,255,0.1)' : 'var(--bg-card)',
              color: threshold === 1 ? 'var(--accent)' : 'var(--text-secondary)',
              border: '1px solid rgba(255,255,255,0.06)',
              borderRadius: 20, cursor: 'pointer',
              fontSize: 12, fontWeight: 500,
              whiteSpace: 'nowrap',
            }}
          >
            {threshold === 1 ? 'Full Library' : `Recommended (${DEFAULT_THRESHOLD}+)`}
          </button>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div role="status" aria-live="polite" style={{ textAlign: 'center', padding: '60px 16px', color: 'var(--text-secondary)' }}>
          <div style={{
            width: 24, height: 24,
            border: '2px solid var(--text-secondary)',
            borderTopColor: 'transparent',
            borderRadius: '50%',
            animation: 'spin 0.6s linear infinite',
            margin: '0 auto 16px',
          }} />
          <div style={{ fontSize: 14, marginBottom: 6 }}>Building your library...</div>
          {loadingPhase && (
            <div style={{ fontSize: 12, opacity: 0.6 }}>{loadingPhase}</div>
          )}
          <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
        </div>
      )}

      {/* Error */}
      {error && !loading && (
        <div style={{ textAlign: 'center', padding: '60px 16px', color: 'var(--text-secondary)' }}>
          <div style={{ fontSize: 14, marginBottom: 16 }}>{error}</div>
          <button
            onClick={() => navigate('/settings')}
            style={{
              padding: '12px 24px', backgroundColor: 'var(--accent)', color: '#fff',
              border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13,
            }}
          >
            Go to Settings
          </button>
        </div>
      )}

      {/* Empty */}
      {!loading && !error && picks.length === 0 && (
        <div style={{ textAlign: 'center', padding: '60px 16px', color: 'var(--text-secondary)' }}>
          <div style={{ fontSize: 14, lineHeight: 1.6 }}>
            No rated titles yet. Rate movies and shows on the title page and they'll build your library here.
          </div>
        </div>
      )}

      {/* Search results — flat grid */}
      {searchResults && (
        <div style={{ padding: '0 16px' }}>
          {searchResults.length === 0 ? (
            <div style={{
              textAlign: 'center', padding: '40px 0',
              color: 'var(--text-secondary)', fontSize: 14,
            }}>
              No picks match "{searchQuery}"
            </div>
          ) : (
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              gap: 10,
            }}>
              {searchResults.map((item) => (
                <PosterCard
                  key={`${item.tmdbId}-${item.mediaType}`}
                  item={item}
                  onTap={handleTap}
                  gridMode
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Genre rows */}
      {!loading && !searchResults && allRows.length > 0 && (
        <div>
          {allRows.map((row) => (
            <PosterRow key={row.id} row={row} onTap={handleTap} />
          ))}
        </div>
      )}

      {/* Empty above threshold but has lower-rated items */}
      {!loading && !error && !searchResults && allRows.length === 0 && picks.length > 0 && (
        <div style={{ textAlign: 'center', padding: '40px 16px', color: 'var(--text-secondary)' }}>
          <div style={{ fontSize: 14, marginBottom: 12 }}>
            No titles rated {threshold}+ yet.
          </div>
          {threshold > 1 && (
            <button
              onClick={() => setThreshold(1)}
              style={{
                padding: '10px 20px',
                backgroundColor: 'var(--bg-card)',
                color: 'var(--accent)',
                border: '1px solid rgba(255,255,255,0.08)',
                borderRadius: 8, cursor: 'pointer', fontSize: 13,
              }}
            >
              Show full library
            </button>
          )}
        </div>
      )}
    </div>
  );
}
