import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { cacheGet, cacheSet } from '../lib/storage';
import { getRatedItems, isTraktAuthenticated } from '../lib/trakt';
import type { RatedItem } from '../lib/trakt';

/* ─── constants ─── */

const TMDB_POSTER = 'https://image.tmdb.org/t/p/w200';
const TMDB_API_KEY = import.meta.env.VITE_TMDB_API_KEY;
const MIN_RATING = 7;           // "I'd recommend this" threshold
const CACHE_KEY = 'library_picks';
const CACHE_TTL = 1440;         // 24 hours

/* ─── genre map (TMDB IDs → human labels) ─── */

const GENRE_LABELS: Record<number, string> = {
  28: 'Action', 12: 'Adventure', 16: 'Animation', 35: 'Comedy',
  80: 'Crime', 99: 'Documentary', 18: 'Drama', 10751: 'Family',
  14: 'Fantasy', 36: 'History', 27: 'Horror', 10402: 'Music',
  9648: 'Mystery', 10749: 'Romance', 878: 'Sci-Fi', 10770: 'TV Movie',
  53: 'Thriller', 10752: 'War', 37: 'Western',
  // TV-specific
  10759: 'Action & Adventure', 10765: 'Sci-Fi & Fantasy',
  10768: 'War & Politics', 10767: 'Talk', 10766: 'Soap',
  10764: 'Reality', 10763: 'News',
};

// Merge TV genre IDs into their movie equivalents for cleaner grouping
const GENRE_MERGE: Record<number, number> = {
  10759: 28,   // Action & Adventure → Action
  10765: 878,  // Sci-Fi & Fantasy → Sci-Fi
  10768: 10752, // War & Politics → War
};

/* ─── types ─── */

interface PickItem {
  tmdbId: number;
  title: string;
  year: number;
  mediaType: 'movie' | 'tv';
  rating: number;        // user's 1-10
  ratedAt: string;
  posterPath: string | null;
  tmdbScore: number;     // critic signal (0-10)
  genreIds: number[];
  imdbId?: string;
}

interface GenreRow {
  id: number;
  label: string;
  items: PickItem[];
}

/* ─── TMDB batch fetch ─── */

async function enrichWithTMDB(items: RatedItem[]): Promise<PickItem[]> {
  const picks: PickItem[] = [];

  // Batch in groups of 8 to stay polite with TMDB
  for (let i = 0; i < items.length; i += 8) {
    const batch = items.slice(i, i + 8);
    const results = await Promise.allSettled(
      batch.map(async (item) => {
        if (!item.ids.tmdb) return null;
        const type = item.mediaType === 'tv' ? 'tv' : 'movie';
        const res = await fetch(
          `https://api.themoviedb.org/3/${type}/${item.ids.tmdb}?api_key=${TMDB_API_KEY}&language=en-US`
        );
        if (!res.ok) return null;
        const data = await res.json();
        return {
          tmdbId: item.ids.tmdb,
          title: item.title,
          year: item.year,
          mediaType: item.mediaType,
          rating: item.rating,
          ratedAt: item.rated_at,
          posterPath: data.poster_path || null,
          tmdbScore: Math.round((data.vote_average || 0) * 10) / 10,
          genreIds: (data.genres || []).map((g: any) => g.id),
          imdbId: item.ids.imdb || data.imdb_id || undefined,
        } as PickItem;
      })
    );

    for (const r of results) {
      if (r.status === 'fulfilled' && r.value) picks.push(r.value);
    }
  }

  return picks;
}

/* ─── row builders ─── */

function buildRows(picks: PickItem[], mediaFilter: 'all' | 'movie' | 'tv'): {
  special: GenreRow[];
  genres: GenreRow[];
} {
  const filtered = mediaFilter === 'all'
    ? picks
    : picks.filter(p => p.mediaType === mediaFilter);

  // Sort everything by user rating desc, then TMDB score desc as tiebreaker
  const sorted = [...filtered].sort((a, b) =>
    b.rating - a.rating || b.tmdbScore - a.tmdbScore
  );

  // Special rows
  const now = new Date();
  const thisYear = now.getFullYear();
  const lastYear = thisYear - 1;

  const recent = sorted.filter(p => p.year >= lastYear);
  const allTime = sorted.filter(p => p.rating >= 9);

  const special: GenreRow[] = [];
  if (recent.length > 0) {
    special.push({ id: -1, label: `Recent (${lastYear}–${thisYear})`, items: recent });
  }
  if (allTime.length > 0) {
    special.push({ id: -2, label: 'All-Time Favorites', items: allTime });
  }

  // Genre rows — each title can appear in multiple rows
  const genreMap = new Map<number, PickItem[]>();
  for (const item of sorted) {
    for (let gid of item.genreIds) {
      gid = GENRE_MERGE[gid] ?? gid;
      if (!GENRE_LABELS[gid]) continue;
      if (!genreMap.has(gid)) genreMap.set(gid, []);
      // Avoid duplicates within a genre row
      const arr = genreMap.get(gid)!;
      if (!arr.some(x => x.tmdbId === item.tmdbId)) arr.push(item);
    }
  }

  // Only show genres with 2+ titles, sorted by count desc
  const genres: GenreRow[] = [];
  for (const [gid, items] of genreMap.entries()) {
    if (items.length >= 2) {
      genres.push({ id: gid, label: GENRE_LABELS[gid], items });
    }
  }
  genres.sort((a, b) => b.items.length - a.items.length);

  return { special, genres };
}

/* ─── horizontal scroll row component ─── */

function PosterRow({ row, onTap }: {
  row: GenreRow;
  onTap: (item: PickItem) => void;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);

  return (
    <div style={{ marginBottom: 28 }}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'baseline',
        padding: '0 16px',
        marginBottom: 10,
      }}>
        <h2 style={{
          fontSize: 16,
          fontWeight: 600,
          color: 'var(--text-primary)',
          margin: 0,
        }}>
          {row.label}
        </h2>
        <span style={{
          fontSize: 12,
          color: 'var(--text-secondary)',
          fontWeight: 400,
        }}>
          {row.items.length}
        </span>
      </div>

      <div
        ref={scrollRef}
        style={{
          display: 'flex',
          gap: 10,
          overflowX: 'auto',
          paddingLeft: 16,
          paddingRight: 16,
          paddingBottom: 4,
          scrollSnapType: 'x mandatory',
          WebkitOverflowScrolling: 'touch',
          msOverflowStyle: 'none',
          scrollbarWidth: 'none',
        }}
      >
        {row.items.map((item) => (
          <button
            key={`${item.tmdbId}-${item.mediaType}`}
            onClick={() => onTap(item)}
            style={{
              flex: '0 0 auto',
              width: 105,
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: 0,
              textAlign: 'left',
              scrollSnapAlign: 'start',
            }}
          >
            <div style={{ position: 'relative', marginBottom: 6 }}>
              {item.posterPath ? (
                <img
                  src={`${TMDB_POSTER}${item.posterPath}`}
                  alt={item.title}
                  loading="lazy"
                  style={{
                    width: '100%',
                    aspectRatio: '2/3',
                    borderRadius: 8,
                    objectFit: 'cover',
                    backgroundColor: 'var(--bg-card)',
                    display: 'block',
                  }}
                />
              ) : (
                <div style={{
                  width: '100%',
                  aspectRatio: '2/3',
                  borderRadius: 8,
                  backgroundColor: 'var(--bg-card)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 28,
                  fontWeight: 300,
                  color: 'var(--text-secondary)',
                }}>
                  {item.title.charAt(0).toUpperCase()}
                </div>
              )}

              {/* User rating — top-right, accent */}
              <div style={{
                position: 'absolute',
                top: 4,
                right: 4,
                minWidth: 26,
                height: 26,
                borderRadius: 6,
                backgroundColor: item.rating >= 9 ? 'var(--accent)' : 'rgba(0,0,0,0.7)',
                color: item.rating >= 9 ? '#fff' : 'var(--yellow)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 12,
                fontWeight: 700,
                padding: '0 5px',
              }}>
                {item.rating}
              </div>

              {/* TMDB critic score — bottom-left, subtle */}
              {item.tmdbScore > 0 && (
                <div style={{
                  position: 'absolute',
                  bottom: 4,
                  left: 4,
                  minWidth: 26,
                  height: 20,
                  borderRadius: 4,
                  backgroundColor: 'rgba(0,0,0,0.6)',
                  color: item.tmdbScore >= 7 ? '#4ade80' : item.tmdbScore >= 5.5 ? '#facc15' : '#f87171',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 10,
                  fontWeight: 600,
                  padding: '0 4px',
                  letterSpacing: 0.2,
                }}>
                  {item.tmdbScore.toFixed(1)}
                </div>
              )}

              {/* TV badge */}
              {item.mediaType === 'tv' && (
                <div style={{
                  position: 'absolute',
                  top: 4,
                  left: 4,
                  height: 18,
                  borderRadius: 3,
                  backgroundColor: 'rgba(99,102,241,0.85)',
                  color: '#fff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 9,
                  fontWeight: 700,
                  padding: '0 5px',
                  letterSpacing: 0.5,
                  textTransform: 'uppercase',
                }}>
                  TV
                </div>
              )}
            </div>

            {/* Title */}
            <div style={{
              fontSize: 11,
              color: 'var(--text-primary)',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
              lineHeight: 1.3,
            }}>
              {item.title}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ─── main page ─── */

export default function HistoryPage() {
  const navigate = useNavigate();
  const [picks, setPicks] = useState<PickItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [mediaFilter, setMediaFilter] = useState<'all' | 'movie' | 'tv'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => {
    if (!isTraktAuthenticated()) {
      setLoading(false);
      setError('Connect Trakt in Settings to see your picks.');
      return;
    }

    const load = async () => {
      setLoading(true);
      setError(null);

      try {
        // Check 24h cache first
        const cached = cacheGet<PickItem[]>(CACHE_KEY);
        if (cached && cached.length > 0) {
          setPicks(cached);
          setLoading(false);
          return;
        }

        // Fetch all rated items from Trakt
        const rated = await getRatedItems();
        const recommended = rated.filter(r => r.rating >= MIN_RATING);

        if (recommended.length === 0) {
          setPicks([]);
          setLoading(false);
          return;
        }

        // Enrich with TMDB data (poster, genres, critic score)
        const enriched = await enrichWithTMDB(recommended);

        setPicks(enriched);
        cacheSet(CACHE_KEY, enriched, CACHE_TTL);
      } catch (err) {
        console.error('Error loading library:', err);
        setError('Failed to load your picks. Check your Trakt connection.');
      } finally {
        setLoading(false);
      }
    };

    load();
  }, []);

  const handleTap = (item: PickItem) => {
    navigate(`/title/${item.tmdbId}/${item.mediaType}`);
  };

  // Build genre rows from picks
  const { special, genres } = buildRows(picks, mediaFilter);
  const allRows = [...special, ...genres];

  // If search is active, show a flat filtered grid instead of rows
  const searchResults = searchQuery.trim()
    ? picks
        .filter(p => mediaFilter === 'all' || p.mediaType === mediaFilter)
        .filter(p => p.title.toLowerCase().includes(searchQuery.toLowerCase()))
        .sort((a, b) => b.rating - a.rating || b.tmdbScore - a.tmdbScore)
    : null;

  const totalCount = mediaFilter === 'all'
    ? picks.length
    : picks.filter(p => p.mediaType === mediaFilter).length;

  return (
    <div style={{ paddingTop: 16, paddingBottom: 'env(safe-area-inset-bottom, 16px)' }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '0 16px',
        marginBottom: 14,
      }}>
        <div>
          <h1 style={{
            fontSize: 22,
            fontWeight: 700,
            color: 'var(--text-primary)',
            margin: 0,
            lineHeight: 1.2,
          }}>
            My Picks
          </h1>
          {!loading && picks.length > 0 && (
            <span style={{
              fontSize: 12,
              color: 'var(--text-secondary)',
              fontWeight: 400,
            }}>
              {totalCount} titles rated {MIN_RATING}+
            </span>
          )}
        </div>

        {/* Search toggle */}
        {!loading && picks.length > 0 && (
          <button
            onClick={() => { setSearchOpen(!searchOpen); setSearchQuery(''); }}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: 6,
              color: searchOpen ? 'var(--accent)' : 'var(--text-secondary)',
              fontSize: 18,
            }}
            aria-label="Search picks"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="7" /><line x1="16.5" y1="16.5" x2="21" y2="21" />
            </svg>
          </button>
        )}
      </div>

      {/* Search bar (collapsible) */}
      {searchOpen && (
        <div style={{
          padding: '0 16px',
          marginBottom: 12,
        }}>
          <input
            type="text"
            placeholder="Find a pick..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            autoFocus
            style={{
              width: '100%',
              padding: '10px 12px',
              backgroundColor: 'var(--bg-card)',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: 8,
              color: 'var(--text-primary)',
              fontSize: 14,
              outline: 'none',
              boxSizing: 'border-box',
            }}
          />
        </div>
      )}

      {/* Media filter chips */}
      {!loading && picks.length > 0 && (
        <div style={{
          display: 'flex',
          gap: 8,
          padding: '0 16px',
          marginBottom: 20,
        }}>
          {([['all', 'All'], ['movie', 'Movies'], ['tv', 'Shows']] as const).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setMediaFilter(key)}
              style={{
                padding: '6px 14px',
                backgroundColor: mediaFilter === key ? 'var(--accent)' : 'var(--bg-card)',
                color: mediaFilter === key ? '#fff' : 'var(--text-secondary)',
                border: '1px solid rgba(255,255,255,0.06)',
                borderRadius: 20,
                cursor: 'pointer',
                fontSize: 13,
                fontWeight: 500,
                transition: 'background 0.15s',
              }}
            >
              {label}
            </button>
          ))}
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div style={{ textAlign: 'center', padding: '60px 16px', color: 'var(--text-secondary)' }}>
          <div style={{
            width: 24, height: 24,
            border: '2px solid var(--text-secondary)',
            borderTopColor: 'transparent',
            borderRadius: '50%',
            animation: 'spin 0.6s linear infinite',
            margin: '0 auto 16px',
          }} />
          <div style={{ fontSize: 14 }}>Loading your picks...</div>
          <div style={{ fontSize: 12, marginTop: 8, opacity: 0.6 }}>
            First load fetches posters &amp; genres
          </div>
          <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
        </div>
      )}

      {/* Error */}
      {error && !loading && (
        <div style={{ textAlign: 'center', padding: '60px 16px', color: 'var(--text-secondary)' }}>
          <div style={{ fontSize: 14, marginBottom: 16 }}>{error}</div>
          <button
            onClick={() => navigate('/settings')}
            style={{
              padding: '12px 24px', backgroundColor: 'var(--accent)', color: '#fff',
              border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13,
            }}
          >
            Go to Settings
          </button>
        </div>
      )}

      {/* Empty state */}
      {!loading && !error && picks.length === 0 && (
        <div style={{ textAlign: 'center', padding: '60px 16px', color: 'var(--text-secondary)' }}>
          <div style={{ fontSize: 14, lineHeight: 1.6 }}>
            No picks yet. Rate movies and shows {MIN_RATING}+ on the title page and they'll appear here as your recommendations.
          </div>
        </div>
      )}

      {/* Search results — flat grid */}
      {searchResults && (
        <div style={{ padding: '0 16px' }}>
          {searchResults.length === 0 ? (
            <div style={{
              textAlign: 'center',
              padding: '40px 0',
              color: 'var(--text-secondary)',
              fontSize: 14,
            }}>
              No picks match "{searchQuery}"
            </div>
          ) : (
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              gap: 10,
            }}>
              {searchResults.map((item) => (
                <button
                  key={`${item.tmdbId}-${item.mediaType}`}
                  onClick={() => handleTap(item)}
                  style={{
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    padding: 0,
                    textAlign: 'left',
                  }}
                >
                  <div style={{ position: 'relative', marginBottom: 6 }}>
                    {item.posterPath ? (
                      <img
                        src={`${TMDB_POSTER}${item.posterPath}`}
                        alt={item.title}
                        loading="lazy"
                        style={{
                          width: '100%',
                          aspectRatio: '2/3',
                          borderRadius: 8,
                          objectFit: 'cover',
                          backgroundColor: 'var(--bg-card)',
                          display: 'block',
                        }}
                      />
                    ) : (
                      <div style={{
                        width: '100%',
                        aspectRatio: '2/3',
                        borderRadius: 8,
                        backgroundColor: 'var(--bg-card)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 28,
                        color: 'var(--text-secondary)',
                      }}>
                        {item.title.charAt(0)}
                      </div>
                    )}
                    <div style={{
                      position: 'absolute',
                      top: 4,
                      right: 4,
                      minWidth: 26,
                      height: 26,
                      borderRadius: 6,
                      backgroundColor: item.rating >= 9 ? 'var(--accent)' : 'rgba(0,0,0,0.7)',
                      color: item.rating >= 9 ? '#fff' : 'var(--yellow)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: 12,
                      fontWeight: 700,
                      padding: '0 5px',
                    }}>
                      {item.rating}
                    </div>
                  </div>
                  <div style={{
                    fontSize: 11,
                    color: 'var(--text-primary)',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}>
                    {item.title}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Genre rows */}
      {!loading && !searchResults && allRows.length > 0 && (
        <div>
          {allRows.map((row) => (
            <PosterRow key={row.id} row={row} onTap={handleTap} />
          ))}
        </div>
      )}
    </div>
  );
}
