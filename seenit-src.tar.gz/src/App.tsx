import { Component, type ReactNode, lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import NavBar from './components/NavBar';

// Route-based code splitting — each page loads on demand
const BrowsePage = lazy(() => import('./pages/BrowsePage'));
const HomePage = lazy(() => import('./pages/HomePage'));
const LookupPage = lazy(() => import('./pages/LookupPage'));
const TitlePage = lazy(() => import('./pages/TitlePage'));
const HistoryPage = lazy(() => import('./pages/HistoryPage'));
const SettingsPage = lazy(() => import('./pages/SettingsPage'));
const TraktAuthPage = lazy(() => import('./pages/TraktAuthPage'));
const WatchPage = lazy(() => import('./pages/WatchPage'));

/** Catches render errors so the whole app doesn't go blank */
class ErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch(error: Error) {
    console.error('[ErrorBoundary]', error);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-secondary)' }}>
          <p style={{ fontSize: 14, fontWeight: 600, marginBottom: 8 }}>Something went wrong.</p>
          <button
            onClick={() => {
              this.setState({ hasError: false });
              window.location.href = '/seenit/';
            }}
            style={{
              padding: '10px 20px', background: 'var(--accent)', color: '#fff',
              border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 13,
            }}
          >
            Go Home
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
  return (
    <BrowserRouter basename="/seenit">
      <ErrorBoundary>
        <div style={{
          minHeight: '100dvh',
          display: 'flex',
          flexDirection: 'column',
          background: 'var(--bg-primary)',
        }}>
          <main style={{
            flex: 1,
            maxWidth: 480,
            width: '100%',
            margin: '0 auto',
            padding: '0 16px 80px',
          }}>
            <Suspense fallback={
              <div role="status" aria-live="polite" style={{ textAlign: 'center', padding: '60px 0', color: 'var(--text-secondary)' }}>
                <div style={{ width: 24, height: 24, border: '2px solid var(--text-secondary)', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 0.6s linear infinite', margin: '0 auto 12px' }} />
                <span>Loading…</span>
              </div>
            }>
              <Routes>
                <Route path="/" element={<BrowsePage />} />
                <Route path="/search" element={<HomePage />} />
                <Route path="/lookup" element={<LookupPage />} />
                <Route path="/title/:tmdbId/:mediaType" element={<TitlePage />} />
                <Route path="/history" element={<HistoryPage />} />
                <Route path="/settings" element={<SettingsPage />} />
                <Route path="/auth/trakt" element={<TraktAuthPage />} />
                <Route path="/auth/callback" element={<TraktAuthPage />} />
                <Route path="/watch/:mediaType/:imdbId" element={<WatchPage />} />
                {/* Catch-all: redirect unknown routes home */}
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </Suspense>
          </main>
          <NavBar />
        </div>
      </ErrorBoundary>
    </BrowserRouter>
  );
}

export default App;
