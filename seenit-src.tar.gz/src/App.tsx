import { Component, type ReactNode } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import BrowsePage from './pages/BrowsePage';
import HomePage from './pages/HomePage';
import LookupPage from './pages/LookupPage';
import TitlePage from './pages/TitlePage';
import HistoryPage from './pages/HistoryPage';
import SettingsPage from './pages/SettingsPage';
import TraktAuthPage from './pages/TraktAuthPage';
import WatchPage from './pages/WatchPage';
import NavBar from './components/NavBar';

/** Catches render errors so the whole app doesn't go blank */
class ErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch(error: Error) {
    console.error('[ErrorBoundary]', error);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-secondary)' }}>
          <p style={{ fontSize: 14, fontWeight: 600, marginBottom: 8 }}>Something went wrong.</p>
          <button
            onClick={() => {
              this.setState({ hasError: false });
              window.location.href = '/seenit/';
            }}
            style={{
              padding: '10px 20px', background: 'var(--accent)', color: '#fff',
              border: 'none', borderRadius: 6, cursor: 'pointer', fontSize: 13,
            }}
          >
            Go Home
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
  return (
    <BrowserRouter basename="/seenit">
      <ErrorBoundary>
        <div style={{
          minHeight: '100dvh',
          display: 'flex',
          flexDirection: 'column',
          background: 'var(--bg-primary)',
        }}>
          <div style={{
            flex: 1,
            maxWidth: 480,
            width: '100%',
            margin: '0 auto',
            padding: '0 16px 80px',
          }}>
            <Routes>
              <Route path="/" element={<BrowsePage />} />
              <Route path="/search" element={<HomePage />} />
              <Route path="/lookup" element={<LookupPage />} />
              <Route path="/title/:tmdbId/:mediaType" element={<TitlePage />} />
              <Route path="/history" element={<HistoryPage />} />
              <Route path="/settings" element={<SettingsPage />} />
              <Route path="/auth/trakt" element={<TraktAuthPage />} />
              <Route path="/auth/callback" element={<TraktAuthPage />} />
              <Route path="/watch/:mediaType/:imdbId" element={<WatchPage />} />
              {/* Catch-all: redirect unknown routes home */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </div>
          <NavBar />
        </div>
      </ErrorBoundary>
    </BrowserRouter>
  );
}

export default App;
