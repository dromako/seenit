import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import { pruneExpiredCache } from './lib/storage'
import { runDailyExportIfNeeded } from './lib/export'
import { pushToRelay } from './lib/letterboxdRelay'

// Clean up expired cache entries on startup to prevent localStorage bloat
pruneExpiredCache();

// Run daily IMDB+Letterboxd export in the background, then silently push
// to the Letterboxd relay if configured.
setTimeout(async () => {
  await runDailyExportIfNeeded();
  pushToRelay();
}, 3000);

// Register service worker — update immediately on new versions
if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    try {
      const reg = await navigator.serviceWorker.register('/seenit/sw.js');
      // Force update check on every page load
      reg.update();
      console.log('[SW] registered:', reg.scope);
    } catch (err) {
      console.warn('[SW] registration failed:', err);
    }
  });
}

// Mount app with fallback for catastrophic failure
const root = document.getElementById('root');
if (root) {
  try {
    createRoot(root).render(
      <StrictMode>
        <App />
      </StrictMode>,
    );
  } catch (err) {
    console.error('[App] Failed to mount:', err);
    root.innerHTML = `
      <div style="padding:40px;text-align:center;color:#7d8590;font-family:system-ui">
        <p>Something went wrong loading SeenIt.</p>
        <p style="margin-top:8px"><a href="/seenit/" style="color:#e8613c" onclick="caches.delete('seenit-v1');caches.delete('seenit-v2');">Reload</a></p>
      </div>
    `;
  }
}
